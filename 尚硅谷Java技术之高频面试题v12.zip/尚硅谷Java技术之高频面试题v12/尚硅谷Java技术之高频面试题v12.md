#                                          Java基础

## JAVASE

### 1、写出Java的四类八种基本数据类

整数                      byte short int long

小数(浮点)             float double

布尔                      boolean

字符                      char

### 2、& 和 && 的区别&#x20;

&  符号的左右两边,无论真或假都要执行

&& 符号的左边如果为假,符号的右边不再执行,提高了代码的执行效率

### 3、switch的参数可以是什么类型

byte，short，int，char，String，枚举

### 4、说出实例变量和局部变量的区别

1, 物理位置

成员变量: 类中方法外

局部变量: 方法中或方法定义的小括号里面

2, 内存位置

成员变量: 在堆内存中

局部变量: 通常在栈内存中（栈帧）

3, 生命周期

成员变量: 随着对象创建而产生,随着对象的消失而消失

局部变量: 随着方法的调用而产生,随着方法调用结束而消失

4,有无默认值&#x20;

成员变量: 有默认值, 整数0,小数0.0 字符 ‘\u0000’ 布尔 false 引用数据类型 null

局部变量: 没有默认值,使用的时候,必须先赋值

### 5、static关键字都能修饰什么？ 都有什么特点

1, 修饰成员变量, 叫静态变量 具有共享性,节省内存空间；

2, 修饰方法: 静态方法: 可以直接使用类名.进行调用；

3, 修饰代码块: 静态代码块 ,给静态变量进行赋值；

4, 修饰类: 静态内部类；

### 6、overload和override的区别

overload 是重载  要求在同一个类中,方法名相同,参数列表不同与返回值类型无关 。

参数列表不同表现在: 个数不同, 数据类型顺序不同,数据类型不同。

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\Java基础\JAVASE\image\Snipaste_2023-09-11_23-44-15_cGOhfc8JMK.png)

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\Java基础\JAVASE\image\image_NbyMFXIzrq.png)

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\Java基础\JAVASE\image\image_3LFML38aGN.png)

override是重写 要求发生在子父级的继承关系中,方法名相同,参数列表相同,返回值类型是父类返回值类型本身或其子类, 异常等于父类本身异常类型或小于父类本身异常。

**把控细节**：构造方法不能被重写,因为构造方法要求,方法名与类名保持一致 **.**

**返回值**：

**父类：**

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\Java基础\JAVASE\image\image_XQ_B_s49j8.png)

**子类：**

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\Java基础\JAVASE\image\image_p0XDdRo9Hk.png)

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\Java基础\JAVASE\image\image_xE91sIqVK4.png)

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\Java基础\JAVASE\image\image_b5KwsPrYqU.png)

&#x20;**异常**：

**父类：**

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\Java基础\JAVASE\image\image_BWfXGqUFdK.png)

**子类：**

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\Java基础\JAVASE\image\image_CtFyF82WFI.png)

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\Java基础\JAVASE\image\image_0cNkUkp_CP.png)

### 7、 final 和 finally的区别

**final 是权限修饰符, 表示最终的, 能修饰 变量, 方法,和类**。

修饰变量: 变成了常量。

修饰方法: 变成了最终的方法,不能被重写,但是可以被正常调用。

修饰类: 变成的最终的类,不能有子类,但是可以被正常创建对象。

**finally 是一个代码块,只能与我们的 try代码块连用,表示无论代码是否发生异常,finally里面的代码都要执行**。

finally强制退出两种方式：System.exit()、

**Finally把控细节：**

```java
package se.finals;


public class FinallyDemo {
    public static void main(String[] args) {


        FinallyDemo finallyDemo = new FinallyDemo();
        // finallyDemo.finallyTestTryNoResult(); 
        // System.out.println(finallyDemo.finallyTestTryResult()); 
        / /System.out.println(finallyDemo.finallyTestCatchResult()); 

         System.out.println(finallyDemo.finallyTestFinallyResult()); 
    }

    // 1.都没有返回值
    public void finallyTestTryNoResult() {
        try {
            System.out.println("try code block invoked");
            //int i = 1 / 0;
            throw new Exception();
        } catch (Exception e) {
            System.out.println("catch code block invoked");
        } finally {
            System.out.println("finally code block invoked");
        }
    }

    // 2.try有返回值
    public String finallyTestTryResult() {
        try {
            System.out.println("try code block invoked");
            return "no result";
            //throw new Exception();
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("catch code block invoked");
        } finally {
            System.out.println("finally code block invoked");
        }
        return "result";

    }

    // 3.catch有返回值
    public String finallyTestCatchResult() {

        try {
            System.out.println("try code block invoked");
            //throw new Exception();
            int i = 1 / 0;
            return "no result";
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("catch code block invoked");
            return "error";
        } finally {
            System.out.println("finally code block invoked");
        }

    }

    // 4.finally有返回值
    public String finallyTestFinallyResult() {

        try {
            System.out.println("try code block invoked");
            //throw new Exception();
            int i = 1 / 0;
            return "no result";
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("catch code block invoked");
            return "error";
        } finally {
            System.out.println("finally code block invoked");
            return "success";
        }

    }


}
```

### 8、 this和super都能用到哪些地方

1、访问成员变量

this：可以区分成员变量与局部变量重名问题,如果本类没有这个成员变量,也可以调用父类的成员变量。

super：可以区分本类成员变量与父类成员变量重名问题，只能调用父类的成员变量。

2、访问成员方法                             &#x20;

this：可以调用本类的成员方法,如果本类没有这个成员方法,也可以调用父类的成员方法。

super：只能调用父类的成员方法。

3、访问构造器

this：可以通过this() 或 this(参数) 让其本类的构造方法直接相互调用。

super：子类通过super() 或 super(参数) 调用父类的构造方法。

### 9、 接口与抽象类的区别

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\Java基础\JAVASE\image\image_-q4Ewc-z0q.png)

**把控细节**：

**抽象类：**

**例子（example）：**

```java
package se.abstracts;


public abstract class AbstractDemo {

    // 抽象类和普通类基本没有区别（只是多了一个可以定义抽象方法）
    private int a;// 成员变量
    private static int b;//静态变量
    private static final int c = 1;//常量

    // 1.抽象类中静态方法--有方法的实现
    public static void a() {

    }

    // 2.抽象类中构造方法
    public AbstractDemo(int a) {
        this.a = a;
    }

    // 3.抽象类中实例方法
    public void b() {

    }

    // 4.抽象类中定义一个抽象方法，注意没有方法实现体。
    //public abstract void c(){ //fail
    //
    //}
    public abstract void c();// ok

}

```

**接口**：

**例子（example）：**

```java
package se.abstracts;


public interface InterfaceDemo extends InterfaceDemo1, InterfaceDemo2 {
    // 1.接口中不能定义静态方法--但是可以有静态方法的实现
    public static void a() {

    }
    //public static void b();//fail
    
    // 2.接口中不可以定义构造方法
    //public InterfaceDemo(){//fail
    //
    //}

    // 3.接口中不可以定义实例方法（没有static  也没有abstract关键字）
    //public void c();//fail
    // 4.接口中不能定义变量--只能有常量
    public static final int d = 1;
    //public int x;//fail

    // 5.接口中所有的默认方法都是public abstract修饰  且访问修饰符必须要是public或者不写，不写则使用默认(注意：默认指的不是default)
    // 抽象类中的访问修饰符四种都可以（public protected private 不写）
    void world();// public abstract

    // 1.8允许接口中有方法的实现，但是必须用关键字default修饰
    default String hello() {
        return "hello";
    }


}

```

### 10、 静态变量与实例变量的区别

内存位置 : 静态变量在方法区中,实例变量在堆内存中。

生命周期 : 静态变量随着.class文件加载而产生,随着.class文件结束而结束; 实例变量随着对象的创建而产生,随着对象的结束而结束。

调用方式: 静态变量既可以通过 类名.直接进行调用, 也可以通过对象名.进行调用; 实例变量只能通过 对象名.进行访问。

### 11、throw和throws 的区别

throw 是具体抛出一个异常对象,在方法的内部, 后面有且只能有一个异常对象,代码一旦遇到了throw证明出现了问题,代码就会停止,线程会异常退出。

throws 是异常的声明, 在方法定义的小括号后面,后面可以跟多个异常的类型,方法有throws,代码不一定发生异常。

### 12、String,StringBuilder 与 StringBuffer 的区别

String、StringBuilder、StringBuffer是不可变的字符串序列,因此该类不可以被继承，也即没有子类。

**相同点**：

**String类**：

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\Java基础\JAVASE\image\1_jv4gzKqvxS.png)

**StringBuilder类：**

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\Java基础\JAVASE\image\image_CT1w2movtT.png)

**StringBuffer类：**

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\Java基础\JAVASE\image\image_o9-91DL0VR.png)

**不同点：**

StringBuilder类中的大多数方法没有加Synchronized关键字修饰。而StringBuffer类中的大多数方法都是加了Synchronized关键字修饰，正因为如此，在多线程操作的时候，StringBuffer会比StringBuilder安全，但是其效率会偏低。

### 13、 == 和 equals的区别

\== 既可以比较基本数据类型,也可以比较引用数据类型,比较基本数据类型,比较的是具体的值,比较引用数据类型比较是地址值。

equals只能比较引用数据类型,重写之前比较的是引用数据类型的地址值,重写之后,根据重自定义写的规则，比较的是引用数据类型的内容。

### 14、包装类拆箱装箱

**装箱：** 将基本类型转换成包装类对象。

**拆箱：** 将包装类对象转换成基本类型的值。

**区别：** 以int和Integer为例。

（1）Integer是int的包装类，int则是java的一种基本数据类型；

（2）Integer变量必须实例化后才能使用，而int变量不需要；

（3）Integer实际是对象的引用，当new一个Integer时，实际上是生成一个指针指向此对象；而int则是直接存储数据值；

（4）Integer的默认值是null，int的默认值是0。

java为什么要引入自动装箱和拆箱的功能？主要是用于java集合中，List\<Inteter>list=new ArrayList\<Integer>();

list集合如果要放整数的话，只能放对象，不能放基本类型，因此需要将整数自动装箱成对象。

**例子（example）：**

```java
package se.packing;

/**
 * @Author huzhongkui
 * @Date 2023--08--31:14:45
 * 聪明出于勤奋,天才在于积累
 **/
public class IntAndIntegerDemo {
    public static void main(String[] args) {

        // 一组：两个Integer对象比较
        // 结论：两个对象比较 地址一定不等，则结果为false
        Integer integer = new Integer(66);
        Integer integer1 = new Integer(66);
        System.out.println(integer == integer1);
        
        // 二组：Integer类型属性值和int属性值比较
        // 结论：包装类Integer和基本数据类型比较的时候，将包装类自动拆箱为int，然后进行比较，本质就是两个int变量进行比较，只要两个变量的值相等，则结果就为true
        Integer integer2 = new Integer(88);
        //Integer a = 88;
        int i = 88;
        System.out.println(integer2 == i);
        
        // 三组：new Integer()类型变量值和Integer类型的变量值比较
        // 结论：new Integer() 堆中地址 Integer 常量池中地址，地址不等
        Integer integer3 = new Integer(88);
        Integer j = 88;
        System.out.println(integer3 == j);

        // 四组：Integer类型的变量值和Integer类型的变量值(范围在：[-128~127]相等,)
        // 其它则不相等会创建新的Integer对象
        Integer k = -129;
        Integer l = -129;
        System.out.println(k == l);
    }
}

```

### 15、异常结构图

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\Java基础\JAVASE\image\image_n65MRvxzxu.png)

### 16、 HashSet 的去重原理

如果两个对象的hashCode值不同，直接插入成功。
如果两个对象的hashCode值相同，再比较两个对象的地址值。如果地址值相同，即同一个对象，插入失败（无需继续判断）反之，则会继续调用equals方法比较，如果equals方法返回true，插入失败；如果equals方法返回false，插入成功。

### 17、集合与数组的区别

集合与数组都是容器

数组既可以存基本数据类型也可以存引用数据类型,数组的长度固定不能发生改变

集合只能存引用数据类型,可以存任意的引用数据类型,长度可变

### 18、多线程的五种实现方式

1, 继承Thread,重写run方法,最后创建Thread 的子类对象,调用start()方法开启线程任务

**例子（example）：**

```java
package se.thread.create;


public class CreateThread_1 {
    public static void main(String[] args) {

        Thread thread = new Thread(new MyThread());
        thread.start();
    }
}


class MyThread extends Thread {
    @Override
    public void run() {
        System.out.println("do some  thing");
    }
}

```

2, 实现Runnable接口,重写run方法,创建Runnable 的实现类对象,通过Thread 的构造传递,调用start() 方法开启线程任务

**例子（example）：**

```java
package se.thread.create;


public class CreateThread_2 {
    public static void main(String[] args) {

        Thread thread = new Thread(new MyRunnable());
        thread.start();
    }
}

class MyRunnable implements Runnable {
    @Override
    public void run() {
        System.out.println("do some thing");
    }
}
```

3, 实现Callable接口,重写call方法,创建Callable的实现类对象,将Callable 的实现类对象,传递到FutureTask的构造方法中,最后将FutureTask传递到Thread 的构造方法中,通过start()方法开启线程任务

**例子（example）：**

```java
package se.thread.create;

import java.util.concurrent.Callable;
import java.util.concurrent.FutureTask;


public class CreateThread_3 {
    public static void main(String[] args) {
        FutureTask<Integer> futureTask = new FutureTask<Integer>(new MyCallable());
        Thread thread = new Thread(futureTask);
    }
}

/**
 * Callable 和Runnable接口有什么区别
 * 1、Callable接口中也是一个函数式接口 里面拥有一个call方法
 * 2、Callable接口的call方法可以有返回值。
 * 3、Callable接口中的call方法可以抛异常（run()方法和call()方法都能抓异常）
 */
class MyCallable implements Callable<Integer> {
    // 抛异常
    @Override
    public Integer call() throws Exception {
        // 抓异常
        try {
            System.out.println("do some thing");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 100;
    }
}

class MyRunnable implements Runnable {

    @Override
    public void run() {
        // 抓异常
        try {
            int i = 1 / 0;
        } catch (Exception e) {
            System.out.println("do some thing");
            e.printStackTrace();
        }
    }
}
```

4、使用线程池创建

**例子（example）：**

```java
package se.thread.create;

import java.util.concurrent.*;


public class CreateThread_4 {
    public static void main(String[] args) {

        // 比如使用线程池工具类
        ExecutorService executorService = Executors.newFixedThreadPool(1);
        executorService.submit(() -> {
            System.out.println("do some thing");
        });


        // 比如自定义线程池
        ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(10,20,30,TimeUnit.MINUTES,new LinkedBlockingQueue<>());

        threadPoolExecutor.execute(new Runnable() {
            @Override
            public void run() {
                System.out.println("do some thing");
            }
        });
    }
}




```

5、使用jdk1.8自带的异步编排方式

**例子（example）：**

```java
package se.thread.create;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


public class CreateThread_5 {
    public static void main(String[] args) {
        // 使用异步编排
        CompletableFuture.runAsync(() -> {
            System.out.println("开始执行一个任务");
        });
    }
}




```

**把控细节**：其实不管是哪种方式创建，底层都是通过实现Runnable接口方式创建线程。

### 19、多线程的生命周期

源码中一共定义了6钟状态。

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\Java基础\JAVASE\image\image_YqoM7Um4ux.png)

（1）新建（*NEW*）：线程对象刚给创建，但未启动（start）

**例子（example）：**

```java
package se.thread.life;


public class Thread_New {
    public static void main(String[] args) {

        Thread thread = new Thread();// 只要线程new出来
        System.out.println("线程的名字"+thread.getName()+"线程的状态:"+thread.getState());

    }
}

```

（2）可运行（*RUNNABLE*）：线程已被启动，可以被调度或正在被调度。

**例子（example）：**

```java
package se.thread.life;


public class Thread_Runnable {
    public static void main(String[] args) {

        Thread thread = new Thread(()->{
            System.out.println("1111");
            System.out.println("线程的状态"+Thread.currentThread().getState());
        });
        thread.start();
        System.out.println("线程的状态"+thread.getState());
    }
}

```

（3）锁阻塞（*BLOCKED*）：当前线程要获取的锁对象正在被其他线程占用，此时该线程处于Blocked状态。

**例子（example）：**

```java
package se.thread.life;


public class Thread_Blocked {
    public static void main(String[] args) {

        Object o = new Object();
        Thread threadA = new Thread(()->{
            synchronized (o){
                System.out.println("11111");
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        },"A");

        threadA.start();
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        Thread threadB = new Thread(()->{
          synchronized (o){

          }
        },"B");
        threadB.start();
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("线程"+threadB.getName()+"状态"+threadB.getState());

    }
}

```

（4）等待阻塞（*WAITING*）：当前线程遇到了wait()，join()等方法。

**例子（example）：**

```java
package se.thread.life;


public class Thread_Waiting {

    // 使用wait、notify或者notifyAll的时候必须要要结合synchronized使用
    public static void main(String[] args) throws InterruptedException {
        Object o = new Object();
        Thread thread = new Thread(() -> {
            synchronized (o) {
                try {
                    for (int i = 1; i <10 ; i++) {
                        System.out.println("i---"+i);
                        if(i==5){
                            o.wait();// 使用对象的wait方法时 必要要有一个对象和synchronized
                            // 如若不结合synchronized  那么就会出现一个监视器对象状态异常IllegalMonitorStateException。
                            // 任何一个对象中都有一个ObjectMonitor对象。监视器锁。管程技术。
                        }
                    }

                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

        });
        thread.start();
        Thread.sleep(2000);
        System.out.println(thread.getState());


        Thread thread1 = new Thread(()->{
          //  o.notify();//使用notify或者notifyAll()都要结合synchronized使用，不然就会出现监视器异常IllegalMonitorStateException
           synchronized (o){
               System.out.println("do some thing");
            o.notify();
           }
        });
        thread1.start();

        System.out.println("end");
    }
}

```

（5）限时等待（*TIMED\_WAITING*）：当前线程调用了sleep(时间)，wait(时间)，join(时间)等方法。

**例子（example）：**

```java
package se.thread.life;
public class Thread_TimeWaiting {

    public static void main(String[] args) throws InterruptedException {

        Object o = new Object();
        Thread thread = new Thread(()->{
          synchronized (o){
              try {
                  // 线程调用wait(5000)方法
                  o.wait(5000);
              } catch (InterruptedException e) {
                  e.printStackTrace();
              }
          }
        });
        thread.start();
        // 线程调用sleep(5000)方法
        Thread.sleep(5000);
        // 线程调用join(5000)方法
        thread.join(5000);
        System.out.println(thread.getState());
    }
}

```

（6）终止（*TERMINATED*）：线程正常结束或异常提前退出。

**例子（example）：**

```java
package se.thread.life;
public class Thread_Terminated {
    public static void main(String[] args) throws InterruptedException {
        Thread thread = new Thread(() -> {
            int i = 0;
            System.out.println("1111");
            try {
                i = 10 / 0;
            } catch (Exception e) {
                e.printStackTrace();
            }
            System.out.println(i);
        });
        thread.start();
        Thread.sleep(100);
        System.out.println(thread.getState());
    }
}

```

### 20、TreeSet和HashSet的区别

**1、速度和内部实现**：

HashSet 内部使用哈希表来存储元素，因此它的查找、插入和删除操作的[时间复杂度](https://www.zhihu.com/search?q=时间复杂度\&search_source=Entity\&hybrid_search_source=Entity\&hybrid_search_extra={"sourceType":"answer","sourceId":3049364903} "时间复杂度")都是 O(1)。而 TreeSet 内部使用的是红黑树，因此它的时间复杂度为 O(log n)。

**2、排序方式：**

HashSet 不保证元素的顺序，因为它是根据哈希值来存储和检索元素的。而 TreeSet 则可以保证元素的顺序，因为它是根据元素的自然顺序或者比较器来进行排序的

**3、接口：**

HashSet 实现了 Set 接口，而 TreeSet 实现了 SortedSet 接口。

**4 使用场景**：

如果需要快速地插入、删除和查找元素，并且不关心它们的顺序，那么可以使用 HashSet。如果需要对元素进行比较、排序，那么可以使用 TreeSet。

### 21、所学习的io流一共分为几类

IO流根据流向 有输入流和输出流两种

IO流根据类型分类有 字节输入输出流 和 字符输入输出流 &#x20;

字节输入流  InputStream

字节输出流 OutputStream

字符输入流 Reader

字符输出流 Writer

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\Java基础\JAVASE\image\image_IavBSdntFt.png)

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\Java基础\JAVASE\image\image_8OVV7Wdg-K.png)

**把控细节：**

字节流是万能流,可以处理任意的文件。

字符流不是万能流,基本上用来处理纯文本文件。

### 22、map的三种遍历方式

方式一：增强for

方式二：EntrySet迭代

方式三：KeySet迭代

**例子（example）：**

```java
package se.collect.map;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 * @Author huzhongkui
 * @Date 2023--09--19:09:03
 * 聪明出于勤奋,天才在于积累
 **/
public class MapForDemo {
    public static void main(String[] args) {
        HashMap<String, String> map = new HashMap<>();
        map.put("name", "zs");
        map.put("age", "18");
        map.put("sex", "男");
        map.put("address", "武汉市");

        // 方式一：增强for
        //for (Map.Entry<String, String> entry : map.entrySet()) {
            //System.out.println("map的key:"+entry.getKey()+",map的value:"+entry.getValue());
        //}
        // 方式二：EntrySet迭代
        //Set<Map.Entry<String, String>> entries = map.entrySet();
        //Iterator<Map.Entry<String, String>> iterator = entries.iterator();
        //while (iterator.hasNext()) {
        //    Map.Entry<String, String> next = iterator.next();
        //    System.out.println("map的key:" + next.getKey() + ",map的value:" + next.getValue());
        //}

        //方式三：keySet迭代
        Iterator<String> keySetIterator = map.keySet().iterator();
        while (keySetIterator.hasNext()) {
            String key = keySetIterator.next();
            String value = map.get(key);
            System.out.println("map的key:"+key+",map的value:"+value);
        }
    }
}

```

### 23、HashMap与HashTable 的区别

**（1**）线程安全性不同

HashMap是线程不安全的，HashTable是线程安全的，其中的方法大多数是Synchronize的，在多线程并发的情况下，可以直接使用HashTable，但是使用HashMap时必须自己增加同步处理。

**HashMap:**

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\Java基础\JAVASE\image\image_jmI6y9tfgf.png)

**HashTable:**

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\Java基础\JAVASE\image\image_xgx1scpo4a.png)

**（2**）是否提供**contains**方法

HashMap只有containsValue和containsKey方法；HashTable有contains、containsKey和containsValue三个方法，其中contains和containsValue方法功能相同。

**HashMap:**

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\Java基础\JAVASE\image\image_HEQ6q3lmDi.png)

**HashTable:**

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\Java基础\JAVASE\image\image_T-9szbF4sx.png)

**（3**）**key**和**value**是否允许**null**值

Hashtable中，key和value都不允许出现null值。HashMap中，null可以作为键，这样的键只有一个；可以有一个或多个键所对应的值为null。

**HashMap:**

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\Java基础\JAVASE\image\image_vTc6NXU7xi.png)

**HashTable:**

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\Java基础\JAVASE\image\image_8F_nj6g8JV.png)

**（4**）数组初始化和扩容机制

**初始化**：HashTable在不指定容量的情况下的默认容量为11；而HashMap在不指定容量的时候，并不会提前构建指定长度大小的数组。而是当第一次put元素的时候才会去创建一个容量大小为16的数组，这点一定要注意！！！

**HashTable:**

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\Java基础\JAVASE\image\image_DWoR0_oGl7.png)

**HashMap:**

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\Java基础\JAVASE\image\image_aSPhBh5OM1.png)

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\Java基础\JAVASE\image\2__ZlUqi0oMp.png)

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\Java基础\JAVASE\image\3_DGOJNxeBsm.png)

**扩容**：Hashtable扩容时，将容量变为原来的2倍加1，而HashMap扩容时，将容量变为原来的2倍。

**HashMap:**

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\Java基础\JAVASE\image\image_DvqppfWZih.png)

**HashTable:**

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\Java基础\JAVASE\image\4_nsQ8c6bYq6.png)

### 24、ArrayList和LinkedList的区别

**ArrayList**：基于动态数组，连续内存存储，适合下标访问（随机访问），扩容机制：因为数组长度固定，超出长度存数据时需要新建数组，然后将老数组的数据拷贝到新数组，如果不是尾部插入数据还会涉及到元素的移动（往后复制一份，插入新元素），使用尾插法并指定初始容量可以极大提升性能、甚至超过linkedList（需要创建大量的node对象）。

**LinkedList**：基于链表，可以存储在分散的内存中，适合做数据插入及删除操作，不适合查询：需要逐一遍历。遍历LinkedList必须使用iterator不能使用for循环，因为每次for循环体内通get(i)取得某一元素时都需要对list重新进行遍历，性能消耗极大。另外不要试图使用indexOf等返回元素索引，并利用其进行遍历，使用indexlOf对list进行了遍历，当结果为空时会遍历整个列表。

### 25、什么是反射

**什么是Java反射机制：**

反射就是在程序运行时期，动态的获取类信息并操作该类成员（构造方法，成员变量，成员方法）的过程，这种动态获取类的信息以及动态调用对象的方法的功能来自于Java 语言的反射。

Java的反射机制的实现要借助于4个类Class，Constructor，Field，Method;

其中Class代表的时类对象，Constructor－类的构造器对象，Field－类的属性对象，Method－类的方法对象。通过这四个对象我们可以粗略的看到一个类的各个组成部分。

**Java** **反射机制提供功能**

在运行时判断任意一个对象所属的类。

在运行时构造任意一个类的对象。

在运行时判断任意一个类所具有的成员变量和方法。

在运行时调用任意一个对象的方法。

**例子（example）：**

```java
package se.reflective;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * @Author huzhongkui
 * @Date 2023--09--19:10:30
 * 聪明出于勤奋,天才在于积累
 **/
public class ReflectiveDemo {

    public static void main(String[] args) {

        try {
            //1.获取任意一个对象所属的类
            Student student = new Student();
            Class<? extends Student> aClass1 = student.getClass();
            System.out.println(aClass1);
            //2.构造任意一个类对象
            Student student1 = aClass1.newInstance();
            System.out.println(student1);
            //3.获取任意一个类中的构造方法
            Class<?> aClass = Class.forName("se.reflective.Student");
            for (Constructor<?> declaredConstructor : aClass.getDeclaredConstructors()) {
                Object instance = declaredConstructor.newInstance();
                System.out.println(instance);
            }
            //4. 获取任意一个类中的方法
            for (Method declaredMethod : aClass.getDeclaredMethods()) {
                System.out.println("Student类中的方法:" + declaredMethod.getName());
            }
            //5. 获取任意一个类中的成员变量
            for (Field declaredField : aClass.getDeclaredFields()) {
                System.out.println("Student类中的成员变量" + declaredField.getName());
            }
            //6.调用任意一个对象的方法
            System.out.println(student1.getAge());
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}


```

### 26、深拷贝和浅拷贝

深拷贝和浅拷贝就是指对象的拷贝，一个对象中存在两种类型的属性，一种是基本数据类型，一种是实例对象的引用。

1.浅拷贝是指，对基本数据类型进行值传递，对引用数据类型进行引用传递般的拷贝。

2.深拷贝是指，对基本数据类型进行值传递，对引用数据类型，创建一个新的对象，并复制其内容，此为深拷贝。

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\Java基础\JAVASE\image\image_306ijJ6YzJ.png)

**浅拷贝例子：**

```java
package se.copy;

import lombok.Data;

/**
 * @Author huzhongkui
 * @Date 2023--08--31:13:59
 * 聪明出于勤奋,天才在于积累
 **/

class Person implements Cloneable {
    private String name;
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public Phone getPhone() {
        return phone;
    }
    public void setPhone(Phone phone) {
        this.phone = phone;
    }
    private Phone phone;
    @Override
    protected Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}

class Phone implements Cloneable {
    private String name;

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    @Override
    protected Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}
public class ShallowCopy {
    // 浅拷贝
    public static void main(String[] args) throws CloneNotSupportedException {
        Phone phone = new Phone();
        phone.setName("小米");

        // 创建一个Person对象（原对象）
        Person person = new Person();
        person.setName("hzk");
        // 设置引用类型属性
        person.setPhone(phone);
        // 打印原对象的属性值
        System.out.println(person);
        System.out.println(person.getName());
        System.out.println(person.getPhone());
        System.out.println(person.getPhone().getName());

        System.out.println("-----------------");
        // 克隆一个Person对象(克隆对象)
        Person copyPerson = (Person) person.clone();
        // 打印克隆对象的属性值
        System.out.println(copyPerson);
        System.out.println(copyPerson.getName());
        System.out.println(copyPerson.getPhone());
        System.out.println(copyPerson.getPhone().getName());


        // 浅拷贝由于会拷贝引用数据类型的地址，因此修改拷贝对象的值，其被拷贝对象的值也会跟着变化。反之，同理。
        copyPerson.getPhone().setName("华为");

        System.out.println("原对象的引用类型Phone值" + person.getPhone().getName());
        System.out.println("克隆对象的引用类型Phone值" + copyPerson.getPhone().getName());

    }

}

```

**运行结果：**

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\Java基础\JAVASE\image\image_voIXPNScw5.png)

**深拷贝例子：**

```java
package se.copy;

/**
 * @Author huzhongkui
 * @Date 2023--08--31:13:59
 * 聪明出于勤奋,天才在于积累
 **/
class Person1 implements Cloneable {
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Phone1 getPhone() {
        return phone;
    }

    public void setPhone(Phone1 phone) {
        this.phone = phone;
    }

    private Phone1 phone;

    @Override
    protected Object clone() throws CloneNotSupportedException {
//        return super.clone();
        //继续利用clone()方法，对该对象的引用类型变量再实现一次clone()方法。
        // 要想深克隆 要不就是序列化和反序列化 要不就是继续clone
        Person1 person = (Person1) super.clone();
        person.setPhone((Phone1) person.getPhone().clone());
        return person;
    }
}


class Phone1 implements Cloneable {
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    protected Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}

public class DeepCopy {

    // 深拷贝
    public static void main(String[] args) throws CloneNotSupportedException {
        Phone1 phone1 = new Phone1();
        phone1.setName("小米");

        Person1 person1 = new Person1();
        person1.setName("hzk");
        person1.setPhone(phone1);

        System.out.println(person1);
        System.out.println(person1.getName());
        System.out.println(person1.getPhone());
        System.out.println(person1.getPhone().getName());

        System.out.println("-----------------");
        Person1 copyPerson1 = (Person1) person1.clone();
        System.out.println(copyPerson1);
        System.out.println(copyPerson1.getName());
        System.out.println(copyPerson1.getPhone());
        System.out.println(copyPerson1.getPhone().getName());


        System.out.println("-----------------");
        // 深拷贝不会拷贝引用数据类型的地址（而是会创建一个新对象空间），因此修改拷贝对象的值，其被拷贝对象的值不会跟着变化。反之，同理。
        copyPerson1.getPhone().setName("华为");

        System.out.println("原对象的引用类型Phone值---" + person1.getPhone().getName());
        System.out.println("克隆对象的引用类型Phone值---" + copyPerson1.getPhone().getName());
    }
}

```

**运行结果**

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\Java基础\JAVASE\image\图片_HMK6d_wm1r.png)



## 集合类

### 1、Java集合框架是什么?说出集合框架的一些优点?

答：每种编程语言中都有集合，最初的Java版本包含几种集合类：Vector、Stack、HashTable和Arrays。随着集合的广泛使用，Java1.2提出了囊括所有集合接口和实现类、算法的集合框架。

在保证线程安全的情况下使用泛型和并发集合类，Java已经经历了很久。集合框架的部分优点如下：

(1)使用核心集合类降低开发成本，而非实现我们自己的集合类。

(2)使用经过严格测试的集合框架类，代码质量会得到提高。

(3)通过使用JDK附带的集合类，可以降低代码维护成本。

(4)复用性和可操作性。

### 2、集合接口的常见实现类

1、**List接口的实现类**

List接口的实现类最常用的有ArrayList和LinkedList、Vector

ArrayList类实现了可变的数组，可以根据索引位置对集合进行快速的随机访问。

LinkedList类采用链表结构保存对象，便于向集合中插入和删除对象，但是如果将元素插入到集合的尾部，其实ArrayList原比LinkedList快。

Vector:也是List的一个常见实现类，但是在该类中的大多数方法都加了synchronized关键字，因此相比ArrayList、LinkedList集合在多线程访问时是线程的安全的。

2 **、Set接口的实现类**

Set接口的实现类常用的有HashSet和TreeSet、LinkedHashSet。它们的元素都不可重复。

HashSet：底层是哈希表，遍历元素和添加顺序、大小顺序无关。

TreeSet：底层是红黑树，元素按照大小顺序存储和遍历。

LinkedHashSet：底层是哈希表+双链表，遍历元素可以体现添加时顺序。顺序性是体现和HashSet不同之处。

**3、Map接口的实现类**

Map接口的实现类常用的有HashMap、LinkedHashMap和TreeMap。它们的key都不可重复。这里面的key不可重复 **，指的是容器中对于同一个Key只会存在一个。**

HashMap：哈希表，底层是数组+链表+红黑树。遍历元素和添加顺序、大小顺序无关。

LinkedHashMap：哈希表+双链表，遍历元素可以体现添加顺序。

TreeMap：红黑树，元素按照key大小顺序存储和遍历。

**例子（example）：**

```java
package se.collect.map;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @Author huzhongkui
 * @Date 2023--09--19:14:22
 * 聪明出于勤奋,天才在于积累
 **/
public class MapDemo1 {

    public static void main(String[] args) {
        System.out.println("input          1 : 1     3 : 3     2 : 2     4 : 4     5 : 5");
        //HashMap
        Map<String, String> hashMap = new HashMap<String, String>();
        hashMap.put("1", "1");
        hashMap.put("3", "3");
        hashMap.put("2", "2");
        hashMap.put("4", "4");
        hashMap.put("5", "5");
        System.out.print("HashMap        ");
        for (String key : hashMap.keySet()) {
            System.out.print(key + " : " + hashMap.get(key) + "     ");
        }
        System.out.println();
        
        //LinkedHashMap
        Map<String, String> linkedHashMap = new LinkedHashMap<String, String>();
        linkedHashMap.put("1", "1");
        linkedHashMap.put("3", "3");
        linkedHashMap.put("2", "2");
        linkedHashMap.put("4", "4");
        linkedHashMap.put("5", "5");
        System.out.print("LinkedHashMap  ");
        for (String key : linkedHashMap.keySet()) {
            System.out.print(key + " : " + linkedHashMap.get(key) + "     ");
        }
        System.out.println();


        //TreeMap
        Map<String, String> treeMap = new TreeMap<String, String>();
        treeMap.put("1", "1");
        treeMap.put("3", "3");
        treeMap.put("2", "2");
        treeMap.put("4", "4");
        treeMap.put("5", "5");
        System.out.print("TreeMap        ");
        for (String key : treeMap.keySet()) {
            System.out.print(key + " : " + treeMap.get(key) + "     ");
        }
        System.out.println();

    }
}

```

### 3、List和Map区别?

答：在数据结构方面，List存储的是单列数据的集合，而Map存储的是key、value类型的数据集合。在数据存储方面，List存储的数据是有序且可以重复的，而Map中存储的数据是无序（不同的子类也可以保证有序）且key值不会重复(value值可以重复)。

### 4、List、Map、Set三个接口，存取元素时，各有什么特点?

List与Set具有相似性，它们都是单列元素的集合，所以，它们有一个共同的父接口，叫Collection。

Set里面不允许有重复（即相等）的元素。Set取元素时，没法说取第几个，只能通过for循环或者迭代器逐一遍历各个元素。

List表示有先后顺序的集合， 注意，不是那种按年龄、按大小、按价格之类的排序。当我们多次调用add(Object e)方法时，每次加入的对象就像火车站买票有排队顺序一样，按先来后到的顺序排序。有时候，也可以插队，即调用add(int index,Object e)方法，就可以指定当前对象在集合中的存放位置。一个对象可以被反复存储进List中，每调用一次add方法，这个对象就被插入进集合中一次，其实，并不是把这个对象本身存储进了集合中，而是在集合中用一个索引变量指向这个对象，当这个对象被add多次时，即相当于集合中有多个索引指向了这个对象。List除了通过迭代器逐一遍历各个元素，还可以调用get(index i)来明确说明取第几个。

Map与List和Set不同，它是双列的集合，用put方法存储一对key/value，不能存储重复的key。取则可以根据key获得相应的value，即get(Object key)返回值为key 所对应的value。另外，也可以获得所有的key的集合(map.keySet())，还可以获得所有的value的结合(map.values())，还可以获得key和value组合成的Map.Entry对象的集合(map.entrySet())。

### 5、为什么Map接口不继承Collection接口?

首先Map提供的是键值对映射（即Key和value的映射），而collection提供的是一组数据（并不是键值对映射）。

其次如果map继承了collection接口，那么所有实现了map接口的类到底是用map的键值对映射数据还是用collection的一组数据呢（就我们平常所用的hashMap、hashTable、treeMap等都是键值对，所以它继承collection完全没意义），而且map如果继承了collection接口的话还违反了面向对象的**接口分离原则**。

### 6、Iterator和ListIterator之间有什么区别?

(1)我们可以使用Iterator来遍历Set和List集合，而ListIterator只能遍历List;

(2)Iterator只可以向前遍历，而LIstIterator可以双向遍历;

(3)ListIterator从Iterator接口继承，然后添加了一些额外的功能，比如添加一个元素、替换一个元素、获取前面或后面元素的索引位置。

```java
package se.collect.list;

import java.util.ArrayList;
import java.util.ListIterator;

/**
 * @Author huzhongkui
 * @Date 2023--09--19:15:04
 * 聪明出于勤奋,天才在于积累
 **/
public class ListIteratorDemo {

    public static void main(String[] args) {

        ArrayList<String> list = new ArrayList<>();
        list.add("1");
        list.add("3");
        list.add("2");
        list.add("4");
        list.add("5");
        System.out.println("正向遍历结果:");
        // 正向遍历
        ListIterator<String> listIterator = list.listIterator();
        while (listIterator.hasNext()) {
            System.out.println(listIterator.next());

        }
        System.out.println("反向遍历结果:");
        // 反向遍历
        while (listIterator.hasPrevious()) {
            System.out.println(listIterator.previous());
        }

        System.out.println("插入元素：");
        //插入元素
        ListIterator<String> listIterator1 = list.listIterator();
        listIterator1.add("7");
        while (listIterator1.hasPrevious()) {
            System.out.println(listIterator1.previous());

        }
        System.out.println(list);
        System.out.println();

        ListIterator<String> listIterator2 = list.listIterator();

        System.out.println("替换元素:");
        // 替换元素
        while (listIterator2.hasNext()) {
            String next = listIterator2.next();
            if ("5".equals(next)) {
                listIterator2.set("155");
            }
        }
        System.out.println(list);
      
    
    }
}

```

### 7、集合框架中的泛型有什么优点?

**类型安全：**

通过知道使用泛型定义的变量的类型限制，编译器可以在非常高的层次上验证类型假设。没有泛型，这些假设就只能在于程序员编码时候去考虑了。

**消除**[**强制类型转换**](https://so.csdn.net/so/search?q=强制类型转换\&spm=1001.2101.3001.7020 "强制类型转换")**：**

消除源代码中的许多强制类型转换。这使得代码更加可读，并且减少了出错机会。

**更高的效率：**

在非泛型编程中，将筒单类型作为引用类型传递时会引起（装箱）和（拆箱）操作，这两个过程都是具有很大开销的。引入泛型后，就不必进行装箱和拆箱操作了，所以运行效率相对较高。

### 8、Map接口提供了哪些不同的集合视图?

Map接口提供三个集合视图：

(1)Set keyset()：返回map中包含的所有key的一个Set视图。此Set集合是受map支持的，map的变化会在集合中反映出来，反之亦然。当一个迭代器正在遍历一个此Set集合时，若map被修改了(除迭代器自身的移除操作以外)，迭代器的结果会变为不确定。此Set集合支持元素查找和删除，从此Set中删除元素会从map中移除对应的映射，它不支持add和addAll添加操作。

(2)Collection values()：返回一个map中包含的所有value的一个Collection视图。这个collection受map支持的，map的变化会在collection中反映出来，反之亦然。当一个迭代器正在遍历此collection时，若map被修改了(除迭代器自身的移除操作以外)，迭代器的结果会变为不确定。此Collection集合支持元素查找和删除，从此Collection中删除元素会从map中移除对应的映射，它不支持add和addAll添加操作。

(3)Set entrySet()：返回一个map钟包含的所有映射的一个Set集合视图。这个Set集合受map支持的，map的变化会在collection中反映出来，反之亦然。当一个迭代器正在遍历此Set集合时，若map被修改了(除迭代器自身的移除操作，以及对迭代器返回的entry进行setValue外)，迭代器的结果会变为未定义。此Set集合支持元素查找和删除，从此Set中删除元素会从map中移除对应的映射，它不支持add和addAll添加操作。

### 9、jdk1.7HashMap

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\Java基础\集合类\image\图片_iJH6LY605q.png)

**数据结构：数组+链表**

**put方法的流程**

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\Java基础\集合类\image\图片_soZg5MHbr3.png)

### **10、jdk1.8HashMap**

**数据结构：数组+链表+（红黑树）**

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\Java基础\集合类\image\图片_CWy0BsWOt3.png)

**put方法流程：**

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\Java基础\集合类\image\图片_Reb-1ZPS9o.png)

**注意细节：**

HashMap基于哈希表的Map接口实现，是以key-value存储形式存在，即主要用来存放键值对。HashMap 的实现不是同步的，这意味着它不是线程安全的。它的key、value都可以为null。此外，HashMap中的映射不是有序的。

JDK1.8 之前 HashMap 由 数组+链表 组成的，数组是 HashMap 的主体，链表则是主要为了解决哈希冲突(两个对象调用的hashCode方法计算的哈希码值一致导致计算的数组索引值相同)而存在的（“拉链法”解决冲突）。JDK1.8 以后在解决哈希冲突时有了较大的变化，当链表长度大于阈值（或者红黑树的边界值，默认为 8）并且当前数组的长度大于64时，此时此索引位置上的所有数据改为使用红黑树存储。

补充：将链表转换成红黑树前会判断，即使阈值大于8，但是数组长度小于64，此时并不会将链表变为红黑树。而是选择进行数组扩容。

这样做的目的是因为数组比较小，尽量避开红黑树结构，这种情况下变为红黑树结构，反而会降低效率，因为红黑树需要进行左旋，右旋，变色这些操作来保持平衡 。同时数组长度小于64时，搜索时间相对要快些。所以综上所述为了提高性能和减少搜索时间，底层在阈值大于8并且数组长度大于64时，链表才转换为红黑树。具体可以参考 treeifyBin方法。

当然虽然增了红黑树作为底层数据结构，结构变得复杂了，但是阈值大于8并且数组长度大于64时，链表转换为红黑树时，效率也变的更高效。

### 11、JDK8中的HashMap为什么要使用红黑树？

当元素个数小于一个阈值时，链表整体的插入查询效率要高于红黑树，当元素个数大于此阈值时，链表整体的插入查询效率要低于红黑树。此阈值在HashMap中为8。

### 12、JDK8中的HashMap什么时候将链表转化为红黑树？

这个题很容易答错，大部分答案就是：当链表中的元素个数大于8时就会把链表转化为红黑树。但是其实还有另外一个限制：当发现链表中的元素个数大于8之后，还会判断一下当前数组的长度，如果数组长度小于64时，此时并不会转化为红黑树，而是进行扩容。只有**当链表中的元素个数大于8，并且数组的长度大于等于64**时才会将链表转为红黑树。

上面扩容的原因是，如果数组长度还比较小，就先利用扩容来缩小链表的长度。

### 13、JDK7与JDK8中HashMap的不同点？

1.  JDK8中使用了红黑树
2.  JDK7中链表的插入使用的**头插法**（扩容转移元素的时候也是使用的头插法，头插法速度更快，无需遍历链表，但是在多线程扩容的情况下使用头插法会出现循环链表的问题，导致CPU飙升），JDK8中链表使用的**尾插法**（JDK8中反正要去计算链表当前结点的个数，反正要遍历的链表的，所以直接使用尾插法）
3.  JDK7的Hash算法比JDK8中的更复杂，Hash算法越复杂，生成的hashcode则更散列，那么hashmap中的元素则更散列，更散列则hashmap的查询性能更好，JDK7中没有红黑树，所以只能优化Hash算法使得元素更散列，而JDK8中增加了红黑树，查询性能得到了保障，所以可以简化一下Hash算法，毕竟Hash算法越复杂就越消耗CPU。
4.  扩容的过程中JDK7中有可能会重新对key进行哈希（重新Hash跟哈希种子有关系），而JDK8中没有这部分逻辑。
5.  JDK8中扩容的条件和JDK7中不一样，除开判断size是否大于阈值之外，JDK7中还判断了table\[i]是否为空，不为空的时候才会进行扩容，而JDK8中则没有该条件了。
6.  JDK8中还多了一个API：putIfAbsent(key,value)
7.  JDK7和JDK8扩容过程中转移元素的逻辑不一样，JDK7是每次转移一个元素，JDK8是先算出来当前位置上哪些元素在新数组的低位上，哪些在新数组的高位上，然后在一次性转移。

### 14、jdk1.7ConcurrentHashMap

jdk1.7ConcurrentHashMap底层是由两层嵌套数组来实现的：

1.  ConcurrentHashMap对象中有一个属性segments，类型为Segment\[];
2.  Segment对象中有一个属性table，类型为HashEntry\[];

**put流程：**

1、当调用ConcurrentHashMap的put方法时，先根据key计算出对应的Segment\[]的数组下标j，确定好当前key,value应该插入到哪个Segment对象中，如果segments\[j]为空，则利用自旋锁的方式在j位置生成一个Segment对象。

2、然后调用Segment对象的put方法。

&#x20;  2.1 Segment对象的put方法会先加锁，然后也根据key计算出对应的HashEntry\[]的数组下标i，然后将key,value封装为HashEntry对象放入该位置，此过程和JDK7的HashMap的put方法一样，然后解锁。

&#x20;  2.2 在加锁的过程中逻辑比较复杂，先通过自旋加锁，如果超过一定次数就会直接阻塞等等加锁。

### 15、jdk1.8ConcurrentHashMap

**put流程：**

1、当向ConcurrentHashMap中put一个key,value时，首先根据key计算对应的数组下标i，如果该位置没有元素，则通过自旋的方法去向该位置赋值。如果该位置有元素，则synchronized会加锁

2、加锁成功之后，在判断该元素的类型。

2.1 如果是链表节点则进行添加节点到链表中

2.2 如果是红黑树则添加节点到红黑树

3、添加成功后，判断是否需要进行树化

4、addCount，这个方法的意思是ConcurrentHashMap的元素个数加1，但是这个操作也是需要并发安全的，并且元素个数加1成功后，会继续判断是否要进行扩容，如果需要，则会进行扩容，所以这个方法很重要。

5、同时一个线程在put时如果发现当前ConcurrentHashMap正在进行扩容则会去帮助扩容。

### 16、jdk1.7ConcurrentHashMap如何保证并发

主要利用Unsafe操作+ReentrantLock+分段思想。

主要使用了Unsafe操作中的：

1.  compareAndSwapObject：通过cas的方式修改对象的属性
2.  putOrderedObject：并发安全的给数组的某个位置赋值
3.  getObjectVolatile：并发安全的获取数组某个位置的元素

分段思想是为了提高ConcurrentHashMap的并发量，分段数越高则支持的最大并发量越高，程序员可以通过concurrencyLevel参数来指定并发量。ConcurrentHashMap的内部类Segment就是用来表示某一个段的。

每个Segment就是一个小型的HashMap的，当调用ConcurrentHashMap的put方法是，最终会调用到Segment的put方法，而Segment类继承了ReentrantLock，所以Segment自带可重入锁，当调用到Segment的put方法时，会先利用可重入锁加锁，加锁成功后再将待插入的key,value插入到小型HashMap中，插入完成后解锁。

### 17、jdk1.8ConcurrentHashMap如何保证并发

主要利用Unsafe操作+synchronized关键字。

Unsafe操作的使用仍然和JDK7中的类似，主要负责并发安全的修改对象的属性或数组某个位置的值。

synchronized主要负责在需要操作某个位置时进行加锁（该位置不为空），比如向某个位置的链表进行插入结点，向某个位置的红黑树插入结点。

JDK8中其实仍然有分段锁的思想，只不过JDK7中段数是可以控制的，而JDK8中是数组的每一个位置都有一把锁。





#                                         Java高级

## JVM

### １、说一下JVM的主要组成部分？及其作用？

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\Java高级\JVM\image\1562481030796_jT_cKkOBdI.png)

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\Java高级\JVM\image\图片_mM-c2odRAV.png)

\*\*类加载器 (Class Loader) \*\*：将.class字节码文件加载到内存中。类加载器只管加载，不管运行。只要符合文件结构就会加载。

\*\*执行引擎（Execution Engine) \*\* ：也叫解释器，负责解释命令，其任务就是将[字节码](https://so.csdn.net/so/search?q=字节码\&spm=1001.2101.3001.7020 "字节码")指令解释/编译为对应平台上的本地机器指令。

**本地接口（Native Interface）**：本地接口。本地接口的作用是融合不同的语言为java所用。

**栈（Stack）**：也叫栈内存，是java程序的运行区，用于存储**局部变量表**、**操作栈**、**动态链接(即引用，比如方法区的成员变量)**、**方法出口等信息**。**它随着线程的创建而创建，随着线程结束而释放，只要线程一结束，该栈就结束；** 对于栈来说不存在垃圾回收的问题(垃圾回收只针对于堆和方法区)。**栈中的数据以栈帧的形式存在**，是一个数据集，是一个有关方法和运行期数据的集合，当方法A被调用时就产生了一个栈帧F1，并被压入到栈中，A方法又调用了B方法，于是产生栈帧F2也被压入栈，执行完毕后，先弹出F2栈帧，再弹出F1栈帧，遵循“**先进后出**”原则。

**堆（Heap）** **：** 存放的是实例对象。**一个JVM实例只存在一个堆内存，堆内存的大小是可以调节的**。\*\*堆内存分三部分：****永久区**（即存储的是运行环境必须的类信息，被装载至此区域的数据是不会被垃圾回收掉的，只有关闭jvm释放此区域所占用的内存）、**新生区****、\*\***老年代**

**方法区（Method Area）**：方法区只是**JVM规范**中定义的一个概念，它用于存储已被虚拟机加载的类的信息（类的名称、方法信息、字段信息）、常量、静态变量、即时编译器编译后的代码缓存等。

**程序计数器（PC Register）**：每个线程都有一个程序计数器，就是一个指针，指向方法区中的方法字节码（**用来存储下一条将要执行的字节码指令的地址**），由执行引擎读取下一条指令

### 2、说一下JVM运行时数据区？

不同虚拟机的运行时数据区可能略微有所不同，但都会遵从 Java 虚拟机规范， Java 虚拟机规范规定的区域分为以下 5 个部分：

程序计数器（Program Counter Register）：当前线程所执行的字节码的行号指示器，字节码解析器的工作是通过改变这个计数器的值，来选取下一条需要执行的字节码指令，分支、循环、跳转、异常处理、线程恢复等基础功能，都需要依赖这个计数器来完成；

Java 虚拟机栈（Java Virtual Machine Stacks）：用于存储局部变量表、操作数栈、动态链接、方法出口等信息；

本地方法栈（Native Method Stack）：与虚拟机栈的作用是一样的，只不过虚拟机栈是服务 Java 方法的，而本地方法栈是为虚拟机调用 Native 方法服务的；

Java 堆（Java Heap）：Java 虚拟机中内存最大的一块，是被所有线程共享的，存放对象实例

方法区（Methed Area）：用于存储已被虚拟机加载的类信息、常量、静态变量、即时编译后的代码等数据。

### 3、什么是类加载器？

对于任意一个类，都需要由加载它的类加载器和这个类本身一同确立在 JVM 中的唯一性，每一个类加载器，都有一个独立的类名称空间。类加载器就是根据指定全限定名称将 class 文件加载到 JVM 内存，然后再转化为 class 对象。

类加载器分类：

- 启动类加载器（Bootstrap）C++

  负责加载\$JAVA\_HOME中jre/lib/下的某些jre包中的类【比如rt.jar】，该类加载器由C++实现，不是ClassLoader子类。

- 扩展类加载器（Extension）Java

  负责加载java平台中**扩展功能**的一些jar包，包括\$JAVA\_HOME中jre/lib/ext/ \*.jar或-Djava.ext.dirs指定目录下的jar包

- 应用程序类加载器（AppClassLoader）

  也叫系统类加载器，负责加载**classpath**中指定的jar包及目录中class。或-Djava.class.path目录下的jar包或者.class文件。

- 用户自定义加载器  Java.lang.ClassLoader的子类，用户可以定制类的加载方式

注意：各种类加载器之间存在着逻辑上的父子关系，但不是真正意义上的父子关系，因为它们直接没有从属关系。

### 4、双亲委派模型

双亲委派机制是 Java 虚拟机加载一个类时为该类确定类加载器的一种机制。

简单的来说：如果一个类加载器收到了加载某个类的请求,则该类加载器并不会去加载该类,而是把这个请求委派给父类加载器,每一个层次的类加载器都是如此,因此所有的类加载请求最终都会传送到顶端的启动类加载器;只有当父类加载器在其搜索范围内无法找到所需的类,并将该结果反馈给子类加载器,子类加载器会尝试去自己加载。

具体的来说：例如有一个类 com.atguigu.classloader.Math需要加载，在双亲委派机制下流程是怎么样的呢？

-   首先 **应用类加载器** 会判断之前是否加载过这个类，如果加载过则返回，如果没有加载过，则会**向上**委托给**扩展类加载器**；
-   **扩展类加载器**同样会去判断之前是否加载过这个类，如果加载过则返回，如果没有加载过，则继续**向上**委托给 **引导类加载器**；
-   **引导类加载器**则会去 jre/lib 目录下去查询是否有这个类（注意：不会在问是否加载过），如果有这个类则加载，如果没有就**向下回传**给扩展类加载器加载； &#x20;
-   **扩展类加载器**去 jre/lib/ext 目录下去查询是否有这个类，如果有这个类则加载，如果没有这个类就**向下**回传给应用类加载器；
-   **应用类加载器**会去项目的类路径下 （classPath） 下去查询是否有这个类，如果有这个类则加载，如果没有这个类就会抛出经典的 **ClassNotFoundException**。

流程：

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\Java高级\JVM\image\图片_Bm7nNYaxpd.png)

### ５、说一下类装载的执行过程？

类装载简单分为以下 5 个步骤：

**加载**：根据查找路径找到相应的 class 文件然后导入；

**验证**：检查加载的 class 文件的正确性；

**准备**：给类中的静态变量分配内存空间；

**解析**：虚拟机将常量池中的符号引用替换成直接引用的过程。符号引用就理解为一个标示，而在直接引用直接指向内存中的地址；

**初始化**：对静态变量和静态代码块执行初始化工作。

### ６、怎么判断对象是否可以被回收？

一般有两种方法来判断：

引用计数器：为每个对象创建一个引用计数，有对象引用时计数器 +1，引用被释放时计数 -1，当计数器为 0 时就可以被回收。它有一个缺点**不能解决循环引用的问题**；

```java
public class ReferenceCount {

    private  Object instance=null;

    private static final int _1MB = 1024 * 1024;
    private byte[] bigObject= new byte[2*_1MB];

    public static void main(String[] args) {

        ReferenceCount objA = new ReferenceCount();
        ReferenceCount objB = new ReferenceCount();
        objA.instance = objB;
        objB.instance = objA;

        objA = null;
        objB = null;

        System.gc();

    }
}
```

**可达性分析：** 这个算法的基本思想就是通过一系列的称为**“GC Roots”** 的对象作为起点，从这些节点开始向下搜索，节点所走过的路径称为引用链，当一个对象到 GC Roots 没有任何引用链相连的话，则证明此对象是不可用的。

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\Java高级\JVM\image\图片_X6HeANyTQ-.png)

### 7、哪些对象可以作为GC-Roots

在Java语言中，可以作为GC Roots的对象包括下面几种：

-   虚拟机栈（栈帧中的本地变量表）中的引用对象。
-   方法区中的类静态属性引用的对象。
-   方法区中的常量引用的对象。
-   本地方法栈中JNI（Native方法）的引用对象

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\Java高级\JVM\image\图片_i-kPsui5EZ.png)

小技巧：

由于Root 采用栈方式存放指针，所以如果一个指针，它保存了堆里面的对象，但是自己又不存放在堆里面，那他就可以作为一个Root.

### 8、Java中都有哪些引用类型？

强引用：发生 gc 的时候不会被回收。

软引用：有用但不是必须的对象，在发生内存溢出之前会被回收。

弱引用：有用但不是必须的对象，在下一次GC时会被回收。

虚引用（幽灵引用/幻影引用）：无法通过虚引用获得对象，用 PhantomReference 实现虚引用，虚引用的用途是在 gc 时返回一个通知。（临死之前收到一个通知）

```java
package com.atguigu.jvm;
import java.lang.ref.PhantomReference;
import java.lang.ref.ReferenceQueue;
import java.lang.ref.SoftReference;
import java.lang.ref.WeakReference;

/**
 * @Author huzhongkui
 * @Date 2022--07--25:22:55
 * 聪明出于勤奋,天才在于积累
 **/
public class WeakReferenceDemo {
    public static void main(String[] args) {
        softReference();// 软引用
        weakReferenceTest();// 弱引用
        phantomReference();// 虚引用

    }
    
    /**
     * 软引用测试
     * 会发现gc后，软引用对象的值获仍然能够获取到
     */
    private static void softReference() {
        String str = new String("hzk 666!!!");
        SoftReference<String> stringSoftReference = new SoftReference<>(str);
        System.out.println("软引用的值" + stringSoftReference.get());//没有进行gc前软引用能得到对象
        str = null;
        System.gc();
        stringSoftReference.get();
        System.out.println("软引用对象被垃圾回收了,软引用对象的值" + stringSoftReference.get());
    }

    /**
     * 弱引用测试
     * 会发现gc后，弱引用对象的值获取不到
     */
    private static void weakReferenceTest() {
        String str = new String("hzk 666!!!");
        WeakReference<String> stringWeakReference = new WeakReference<>(str);
        str = null;
        System.out.println("软引用的值" + stringWeakReference.get());//没有进行gc前软引用能得到对象
        System.gc();//进行垃圾回收
        stringWeakReference.get();
        System.out.println("软引用对象被垃圾回收了,软引用对象的值" + stringWeakReference.get());
    }

    /**
     * 虚引用测试
     * 会发现gc前，弱引用对象的值都获取不到
     */
    private static void phantomReference() {
        String helloWorldString = new String("hzk 666!!!");
        ReferenceQueue queue = new ReferenceQueue();
        PhantomReference ref = new PhantomReference(helloWorldString, queue);
        System.out.println(ref.get());
        System.gc();//进行垃圾回收
        System.out.println(ref.get());

    }

}

```

### 9、说一下JVM有哪些垃圾回收算法？

**标记复制算法：****该算法将内存****平均分成两部分****，然后每次只使用其中的一部分，当这部分内存满的时候，会将内存中所有存活的对象复制到另一个内存中，然后将之前的内存清空，只使用这部分内存，循环下去。** ​

**标记-清除算法：** 1、使用可达性算法标记出需要回收的对象，且有根可达的就不会被标记清理。

&#x20;                        2、回收被标记的对象

**标记-整理算法：** ​**标记无用对象，让所有存活的对象都向一端移动，然后直接清除掉端边界以外的内存。**

**分代算法：根据对象存活周期的不同将内存划分为几块，一般是新生代和老年代，新生代基本采用复制算法，老年代采用标记整理算法。**

分代回收算法实际上是把复制算法和标记整理法的结合，并不是真正一个新的算法，一般分为：老年代（Old Generation）和新生代（Young Generation），老年代就是很少垃圾需要进行回收的，新生代就是有很多的内存空间需要回收，所以不同代就采用不同的回收算法，以此来达到高效的回收算法。

### 10、说一下JVM有哪些垃圾回收器？

垃圾回收器总体分为三大类:

**串行：**

Serial、Serial Old、

**并行**：

ParNew、Parallel、Parallel Old

**并发：**

CMS、G1

Serial：最早的单线程串行垃圾回收器。

Serial Old：Serial 垃圾回收器的老年版本，同样也是单线程的。

ParNew：是 Serial 的多线程版本。

Parallel 和 ParNew 收集器类似是多线程的，但 Parallel 是吞吐量优先的收集器，可以牺牲等待时间换取系统的吞吐量。Parallel Old 是 Parallel 老生代版本，Parallel 使用的是复制的内存回收算法，Parallel Old 使用的是标记-整理的内存回收算法。

CMS：一种以获得最短停顿时间为目标的收集器，非常适用 B/S 系统。

G1：一种兼顾吞吐量和停顿时间的 GC 实现。

### 11、详细介绍一下CMS垃圾回收器？

**CMS（Concurrent Mark Sweep）收集器是一种以获取最短回收停顿时间为目标的收集器。它非常符合在注重用户体验的应用上使用，它是HotSpot虚拟机第一款真正意义上的并发收集器，它第一次实现了让垃圾收集线程与用户线程（基本上）同时工作。**

从名字中的**Mark Sweep**这两个词可以看出，CMS收集器是一种 **“标记-清除”算法**实现的，它的运作过程相比于前面几种垃圾收集器来说更加复杂一些。整个过程分为四个步骤：

- 初始标记（CMS initial mark）

- 并发标记（CMS concurrent mark）

- 重新标记（CMS remark）

- 并发清理（CMS concurrent sweep）

- 其中初始标记、重新标记这两个步骤仍然需要“Stop The World”。初始标记仅仅只是枚举全部的GC Roots对象，速度很快，并发标记阶段就是进行GC Roots Tracing的过程【采用三色标记算法】，**这个过程耗时较长但是不需要停顿用户线程， 可以与垃圾收集线程一起并发运行**。因为用户程序继续运行，可能会有导致已经**标记过的对象状态发生改变**。而重新标记阶段则是为了修正并发标记期间，因用户程序继续运作而导致标记产生变动的那一部分对象的标记记录，这个阶段的停顿时间一般会比初始标记阶段稍长一些，但远比并发标记的时间短。并发清理这个阶段、清理删除掉标记阶段判断已经死亡的对象，由于不需要移动存活对象，因此这个阶段可以与用户线程同时发生。

  初始标记：迄今为止在进行根节点枚举这一步骤都是需要暂停用户线程的，必须要保证在一个能够保证一致性的快照中得以进行。这里的一致性指的是，不会出现在分析过程中，根节点集合的对象的引用关系还在不断地变化。因为如果这点不能满足，那么分析结果就不能保证。

  那么对于目前的Java应用来说，光是方法区的大小就有数百上千兆，里面的类或者常量更是恒河数沙，若是检查这里为起源的引用就需要消耗很多的时间，所以虚拟机自当是有办法直接得到哪些地方存在着对象的引用。在HotSpot虚拟机中，是使用的一组称为OopMap的数据结构来达存放这些引用。一旦类加载完成的时候，虚拟机就会把对象的偏移量数据计算出来。并且在JIT即时编译中也会在特定的位置记录下栈里的寄存器中存放哪些位置是引用。这样收集器在扫描的时候就可以得知这些信息了。并不需要真正的一个不漏的从方法区等GCROOT开始查找。

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\Java高级\JVM\image\图片_HiGQG5FGqo.png)

从它的名字就可以看出它是一款优秀的垃圾收集器，主要优点：**并发收集、低停顿**。但是它有下面几个明显的缺点：

-   对CPU资源敏感（会和服务抢资源，降低吞吐量）；当然，这是所有并发收集器的缺点
-   无法处理**浮动垃圾**(在并发标记和并发清理阶段又产生垃圾，这种浮动垃圾在本次收集中无法干掉他们，只能等到下一次gc再清理了，这一部分垃圾成为浮动垃圾)；
-   它使用的回收算法-**“标记-清除”算法**会导致收集结束时会有**大量空间碎片**产生

同样由于垃圾收集阶段用户程序还需要持续运行，那就还需要预留足够的空间给用户线程使用，因此CMS垃圾回收器不能像其他的收集器那样等待老年代几乎完全被填满在进行垃圾收集。如果CMS运行期间预留的内存无法满足程序分配新对象的空间，就会出现并发失败。这时候虚拟机就启动默认的备预案，冻结用户线程，临时启用·重新对老年代的垃圾收集。这样就导致停顿时间很长了，性能反而降低。

### 12、新生代垃圾回收器和老年代垃圾回收器都有哪些？有什么区别？

新生代回收器：Serial、ParNew、Parallel Scavenge

老年代回收器：Serial Old、Parallel Old、CMS整堆回收器：

G1新生代垃圾回收器一般采用的是复制算法，复制算法的优点是效率高，缺点是内存利用率低；

老年代回收器一般采用的是标记-整理的算法进行垃圾回收。

### 13、简述分代垃圾回收器是怎么工作的？

分代回收器有两个分区：老年代和新生代，新生代默认的空间占比总空间的 1/3，老年代的默认占比是 2/3。

新生代使用的是复制算法，新生代里有 3 个分区：Eden、To Survivor、From Survivor，它们的默认占比是 8:1:1，它的执行流程如下：

把 Eden + From Survivor 存活的对象放入 To Survivor 区；清空 Eden 和 From Survivor 分区；From Survivor 和 To Survivor 分区交换，From Survivor 变 To Survivor，To Survivor 变 From Survivor。每次在 From Survivor 到 To Survivor 移动时都存活的对象，年龄就 +1，当年龄到达 15（默认配置是 15）时，升级为老年代。大对象也会直接进入老年代。

老年代当空间占用到达某个值之后就会触发全局垃圾收回，一般使用标记整理的执行算法。以上这些循环往复就构成了整个分代垃圾回收的整体执行流程。

### 14、垃圾回收器的比较

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\Java高级\JVM\image\图片_ccfAgNEr1S.png)

### 15、三色标记

所有的垃圾回收算法都要经历标记阶段。如果GC线程在标记的时候暂停所有用户线程（STW），那就没三色标记什么事了。但是这样会有一个问题，用户线程需要等到GC线程标记完才能运行，给用户的感觉就是很卡，用户体验很差。

现在主流的垃圾收集器都支持并发标记。什么是并发标记呢？就是标记的时候不暂停或少暂停用户线程，一起运行。这势必会带来三个问题：多标、漏标。垃圾收集器是如何解决这个问题的呢：三色标记+读写屏障。

把遍历对象过程中遇到的对象，按照“是否访问过”这个条件标记成三种颜色：

-   **白色**：尚未访问过。
-   **黑色**：本对象已访问过，而且本对象 引用到 的其他对象 也全部访问过了。
-   **灰色**：本对象已访问过，但是本对象 引用到 的其他对象 尚未全部访问完。全部访问后，会转换为黑色。

**多标浮动垃圾：**

GC线程正在标记B，此时用户代码中A断开了对B的引用，但此时B已经被标记成了灰色，本轮GC不会被回收，这就是所谓的多标，多标的对象即成为浮动垃圾，躲过了本次GC。

多标对程序逻辑是没有影响的，唯一的影响是该回收的对象躲过了一次GC，造成了些许的内存浪费。

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\Java高级\JVM\image\图片_0E4Q8ypraR.png)

**漏标 程序会出错**：

漏标是如何产生的呢？GC把B标记完，准备标记B引用的对象，这时用户线程执行代码，代码中断开了B对D的引用，改为A对D的引用。但是A已经被标记成黑色，不会再次扫描A，而D还是白色，执行垃圾回收逻辑的时候D会被回收，程序就会出错了。

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\Java高级\JVM\image\图片_3dnznkLoPV.png)

**如何解决漏标问题：**

先分析下漏标问题是如何产生的：

条件一：灰色对象 断开了 白色对象的引用；即灰色对象 原来成员变量的引用 发生了变化。

条件二：黑色对象 重新引用了 该白色对象；即黑色对象 成员变量增加了 新的引用。

知道了问题所在就知道如何解决了。

#### 写屏障 + 增量更新（IU）

这种方式解决的是条件二，即通过写后屏障记录下更新，具体做法如下：

对象A对D的引用关系建立时，将D加入带扫描的集合中等待扫描

当对象A的成员变量的引用发生变化时，比如新增引用（a.d = d），我们可以利用写屏障，将A新的成员变量引用对象D 记录下来：

```java
#写后
void post_write_barrier(oop* field, oop new_value) {
 remark_set.add(new_value); // 记录新引用的对象
}
```

#### 写屏障 + 原始快照（SATB）

这种方式解决的是条件一，带来的结果是依然能够标记到D，具体做法如下：

对象B的引用关系变动的时候，即给B对象中的某个属性赋值时，将之前的引用关系记录下来。

当对象B的成员变量的引用发生变化时，比如引用消失（a.b.d = null），我们可以利用写屏障，将B原来成员变量的引用 对象D记录下来：

```java
#写前 
void pre_write_barrier(oop* field) {
 oop old_value = *field; // 获取旧值
 remark_set.add(old_value); // 记录原来的引用对象
}
```

重标记的时候，扫描旧的对象图，这个旧的对象图即原始快照。

实际应用：

CMS：写屏障 + 增量更新

G1：写屏障 + SATB

### 16、说一下JVM调优的工具？

JDK 自带了很多监控工具，都位于 JDK 的 bin 目录下，其中最常用的是 jconsole 和 jvisualvm 这两款视图监控工具。

jconsole：用于对 JVM 中的内存、线程和类等进行监控；

jvisualvm：JDK 自带的全能分析工具，可以分析：内存快照、线程快照、程序死锁、监控内存的变化、gc 变化等。

### 17、常用的JVM调优的参数都有哪些？

常用的JVM调优参数有很多，以下是一些常见的参数：

1.  `-Xms`：设置JVM的初始堆大小。
2.  `-Xmx`：设置JVM的最大堆大小。
3.  `-Xss`：设置线程的栈大小。
4.  `-XX:NewRatio`：设置新生代和老年代的比例。
5.  `-XX:SurvivorRatio`：设置Eden区和Survivor区的比例。
6.  `-XX:MaxPermSize`（在JDK 8之前）或`-XX:MaxMetaspaceSize`（在JDK 8及以后）：设置永久代（或元空间）的最大大小。
7.  `-XX:ParallelGCThreads`：设置并行垃圾收集器的线程数。
8.  `-XX:+UseConcMarkSweepGC`：启用并发标记清除垃圾收集器。
9.  `-XX:+UseG1GC`：启用G1垃圾收集器。
10.  `-XX:+UseSerialGC`：启用串行垃圾收集器。

这只是一小部分常用的JVM调优参数，具体使用哪些参数需要根据应用程序的需求和环境进行调整。调优参数的选择和调整需要根据具体情况进行实验和评估。

### 18、你能保证GC执行吗？

不能，虽然你可以调用 System.gc() 或者 Runtime.gc()，但是没有办法保证 GC 的执行。

GC（垃圾收集）是由JVM自动管理的过程，它负责回收不再使用的内存资源。JVM根据一定的策略和算法来触发和执行GC操作。

虽然无法保证GC的执行，但是你可以通过调整JVM的参数和配置来影响GC的行为和性能。例如，可以调整堆大小、选择合适的垃圾收集器、调整GC线程数等来优化GC的性能和效果。

请注意，在进行GC调优时，需要仔细评估和测试不同的配置和参数，以确保在特定的应用程序和环境中获得最佳的性能和内存管理。

### 19、怎么获取Java程序使用的内存？堆使用的百分比？

可以通过 java.lang.Runtime 类中与内存相关方法来获取剩余的内存，总内存及 最大堆内存。

通过这些方法你也可以获取到堆使用的百分比及堆内存的剩余空间。 Runtime.freeMemory() 方法返回剩余空间的字节数，Runtime.totalMemory() 方法总内存的字节数，Runtime.maxMemory() 返回最大内存的字节数。



## 设计模式

### 1 、什么是设计模式？有什么好处？

设计模式是一种被反复使用、经过验证的解决特定问题的软件设计思想。它是对软件设计中常见问题的一种抽象和总结，提供了一套经验丰富的解决方案。设计模式不是具体的实现代码，而是关于类和对象之间交互和组织的一种结构化的描述。

设计模式的好处如下：

1.  提高代码的重用性：设计模式通过提供通用的解决方案，可以使得代码更加可复用。它们通过抽象和封装常见的问题和解决方法，使得开发人员可以在不同的项目中重用已经验证的设计思想和实践。
2.  提高代码的可维护性：设计模式通过将代码分离成不同的组件和层次，使得代码更模块化和可维护。它们提供了清晰的结构和约定，使得代码更易于理解、调试和修改。
3.  提高软件的可扩展性：设计模式通过解耦、松散耦合和抽象等方式，使得软件系统更容易进行扩展和修改。它们使得系统的各个部分之间的依赖关系更加灵活，可以方便地添加新的功能和改变现有的实现。
4.  提高团队协作效率：设计模式提供了一种共享的设计语言和思想，使得团队成员之间更容易理解和交流。它们可以作为团队共享的设计原则和规范，促进团队成员之间的合作和协作。
5.  提高软件系统的可靠性：设计模式通过经过验证和优化的解决方案，减少了软件系统中的常见错误和问题。它们提供了一种结构化的方法和实践，可以帮助开发避免一些潜在的设计和实现问题。

综上所，设计模式是一种被广泛应用的软件设计思想，通过提供通用的解决方案，提高了代码的重用性、可维护性、可扩展性和团队协作效率，同时也提高了软件系统的可靠性。

### 2、 设计模式的7大基本原则有哪些？

设计模式的7大基本原则是指软件设计中的基本原则和准则，它们可以指导我们在使用设计模式时做出正确的设计决策。这些原则包括：

1.  单一职责原则（Single Responsibility Principle，SRP）：一个类只负责一项职责。一个类应该只有一个引起它变化的原因。
2.  开放封闭原则（Open-Closed Principle，OCP）：软件实体（类、模块、函数等）应该对扩展开放，对修改关闭。通过抽象和多态来实现对软件实体的扩展，而不是通过修改已有的代码。
3.  里氏替换原则（Liskov Substitution Principle，LSP）：子类应该能够替换掉父类并且工作正常，子类必须能够完全替代父类的行为。
4.  依赖倒置原则（Dependency Inversion Principle，DIP）：高层模块不应该依赖于低层模块，它们应该依赖于抽象。抽象不应该依赖于具体实现，具体实现应该依赖于抽象。
5.  接口隔离原则（Interface Segregation Principle，ISP）：客户端不应该依赖它不需要的接口。类之间的依赖关系应该建立在最小的接口上。
6.  迪米特法则（Law of Demeter，LoD）：一个对象应该对其他对象有尽可能少的了解。只与其直接的朋友进行通信，不需要了解朋友的朋友。
7.  合成复用原则（Composite Reuse Principle，CRP）：尽量使用对象组合和聚合，而不是继承来达到复用的目的。通过组合已有的对象来实现新的功能。

这些原则旨在指导我们进行良好的软件设计，提高软件的可读性、可维护性、可扩展性和可测试性。同时，它们也是设计模式的基础，设计模式的目的就是通过遵循这些原则来实现灵活、可复用和可扩展的软件系统。

### 3 、使用哪种设计模式可以提高代码可维护性？

有多种设计模式可以提高代码的可维护性，以下是其中几种常见的设计模式：

1.  单一职责原则（Single Responsibility Principle，SRP）：将一个类或模块的功能限制在一个单一的责任范围内，避免功能的混杂和耦合，使得代码更容易理解和修改。
2.  开放封闭原则（Open-Closed Principle，OCP）：通过抽象和多态来实现对软件实体的扩展，而不是通过修改已有的代码。这样可以避免修改已有代码带来的风险和影响，提高代码的可维护性。
3.  依赖倒置原则（Dependency Inversion Principle，DIP）：高层模块不应该依赖于低层模块，它们应该依赖于抽象。通过依赖注入等技术，将依赖关系从高层模块中抽离出来，使得代码更加灵活、可扩展和可维护。
4.  接口隔离原则（Interface Segregation Principle，ISP）：客户端不应该依赖它不需要的接口。通过定义细粒度的接口，可以避免接口的臃肿和不必要的依赖关系，提高代码的可维护性。
5.  组合模式（Composite Pattern）：通过将对象组合成树状结构，使得客户端可以一致地处理单个对象和组合对象。这样可以减少代码的重复和冗余，提高代码的可维护性。
6.  策略模式（Strategy Pattern）：将不同的算法封装为独立的策略对象，并通过组合和委托来实现运行时的动态算法选择。这样可以降低代码的复杂性，使得算法的变化和扩展更加容易。
7.  观察者模式（Observer Pattern）：通过定义一种一对多的依赖关系，使得当一个对象状态发生变化时，所有依赖于它的对象都会得到通知和更新。这样可以减少对象之间的显式耦合，提高代码的可维护性。

以上只是举例了几种常见的设计模式，实际上，许多设计模式都有助于提高代码的可维护性。选择合适的设计模式取决于具体的情况和需求，需要综合考虑项目的特点、团队的技术水平和开发成本等因素。

### 4、 使用哪种设计模式可以提高代码的复用性？

设计模式中的许多模式都可以提高代码的复用性，以下是一些常用的设计模式，它们有助于代码的复用：

1.  工厂模式（Factory Pattern）：通过工厂类创建对象，将对象的创建与使用分离，提供了一种灵活的对象创建方式，方便代码复用和扩展。
2.  单例模式（Singleton Pattern）：确保一个类只有一个实例，并提供全局访问点，可以在系统中复用同一个实例。
3.  适配器模式（Adapter Pattern）：将一个类的接口转换成客户端所期望的另一个接口，使得原本不兼容的类可以一起工作，提高代码的复用性。
4.  装饰器模式（Decorator Pattern）：动态地给一个对象添加额外的功能，通过装饰器类包装原始对象，可以在不修改原始对象的情况下进行功能扩展，提高代码的复用性。
5.  观察者模式（Observer Pattern）：定义了一种一对多的依赖关系，当一个对象的状态发生变化时，所有依赖它的对象都会得到通知，可以实现松耦合的对象之间的消息传递，提高代码的复用性。
6.  策略模式（Strategy Pattern）：定义一系列算法，将每个算法封装起来，并使它们可以互换，使得算法可以独立于客户端变化，提高代码的复用性。
7.  模板方法模式（Template Method Pattern）：定义一个算法的骨架，将一些步骤延迟到子类中实现，可以复用算法的结构，而具体的实现可以在子类中灵活变化。

这只是一小部分常用的设计模式，每个设计模式都有不同的应用场景和优势。选择适合的设计模式可以提高代码的复用性、可维护性和扩展性。在实际开发中，根据具体需求和情况选择合适的设计模式是很重要的。

### 5 、你在工作中是如何使用设计模式的？

在实际软件开发中，使用设计模式可以提高代码的可读性、可维护性和可扩展性，降低耦合度，增加代码的复用性。以下是一些常见的使用场景和设计模式示例：

1.  在面向对象的编程中，可以使用工厂模式来创建对象，将对象的创建与使用分离，提高代码的灵活性和可复用性。
2.  当需要适配不兼容的接口时，可以使用适配器模式进行接口转换，使得原本不兼容的类可以一起工作。
3.  如果需要在不修改原始对象的情况下动态地给对象添加额外的功能，可以使用装饰器模式。
4.  当需要实现一对多的依赖关系，实现事件驱动的消息传递时，可以使用观察者模式。
5.  在涉及多种算法选择和切换的情况下，可以使用策略模式来封装和切换不同的算法实现。
6.  当需要定义一个算法的骨架，而将一些具体步骤延迟到子类中实现时，可以使用模板方法模式。

这些只是一些示例，实际使用设计模式的情况会根据具体的需求和应用场景而有所不同。在软件开发中，根据具体问题的复杂性和需求的变化，选择合适的设计模式可以提高代码的质量和可维护性。

### 6、单例模式的多种写法

单例模式是一种创建型设计模式，它确保一个类只有一个实例，并提供全局访问点。以下是几种常见的单例模式的实现方式：

1.  懒汉式，线程不安全：

```java
public class Singleton {
    private static Singleton instance;

    private Singleton() {}

    public static Singleton getInstance() {
        if (instance == null) {
            instance = new Singleton();
        }
        return instance;
    }
}
```

1.  懒汉式，线程安全：

```java
public class Singleton {
    private static Singleton instance;

    private Singleton() {}

    public static synchronized Singleton getInstance() {
        if (instance == null) {
            instance = new Singleton();
        }
        return instance;
    }
}
```

1.  饿汉式：

```java
public class Singleton {
    private static Singleton instance = new Singleton();

    private Singleton() {}

    public static Singleton getInstance() {
        return instance;
    }
}
```

1.  双重检查锁定：

```java
public class Singleton {
    private volatile static Singleton instance;

    private Singleton() {}

    public static Singleton getInstance() {
        if (instance == null) {
            synchronized (Singleton.class) {
                if (instance == null) {
                    instance = new Singleton();
                }
            }
        }
        return instance;
    }
}
```

1.  静态内部类：

```java
public class Singleton {
    private Singleton() {}

    private static class SingletonHolder {
        private static final Singleton instance = new Singleton();
    }

    public static Singleton getInstance() {
        return SingletonHolder.instance;
    }
}
```

以上是几种常见的单例模式的实现方式。每种方式都有其优缺点，选择合适的实现方式取决于具体的需求和场景。需要考虑线程安全性、延迟加载、性能等方面的因素。

### 7、 如何破坏单例模式？

破坏单例模式的方法主要有以下几种：

1.  反射破坏：通过反射机制，可以访问私有构造函数并创建多个实例。可以构造函数中添加逻辑来防止反射破坏单例模式。
2.  序列化与反序列化破坏：当一个单例类被序列化后，再次反序列化会创建一个新的实例。可以通过在单例类中添加`readResolve()`方法，返回已有的实例，从而避免破坏。
3.  多线程环境下的破坏：在多线程环境下，如果没有合适的同步机制，可能会创建多个实例。可以使用双重检查锁定或者静态内部类等线程安全的方式来防止破坏。
4.  克隆破坏：如果单例类实现了`Cloneable`接口并重写了`clone()`方法，可以通过克隆对象创建多个实例。可以在`clone()`方法中抛出`CloneNotSupportedException`异常，阻止克隆破坏。

破坏单例模式需要在特殊情况下有意识地使用上述方法，一般情况下，单例模式是为了保证全局唯一性和访问性，不建议破坏。

### 8 、为什么说枚举是实现单例最好的方式？

枚举是实现单例模式最好的方式之一，原因如下：

1.  线程安全性：枚举实例的创建是由JVM在加载枚举类的时候保证的，因此在多线程环境下也能保证单例的唯一性。枚举的实例创建是线程安全的，无需担心并发访问导致的多实例问题。
2.  反射安全性：枚举类的实例是在枚举类加载的时候被创建的，而且枚举类不支持通过反射来创建实例。即使使用反射强制访问枚举类的私有构造函数，也无法创建新的实例，因为枚举类的构造函数默认是私有的。
3.  序列化安全性：枚举类默认实现了`java.io.Serializable`接口，因此可以安全地进行序列化和反序列化。枚举实例在序列化和反序列化过程中保持单例的状态，不会创建新的实例。
4.  简洁性和可读性：使用枚举实现单例模式非常简洁，只需定义一个枚举类型，枚举值即为单例实例。同时，使用枚举实现的单例模式也更易于理解和维护。

综上所述，由于枚举具有线程安全、反射安全、序列化安全以及简洁可读的特性，因此被认为是实现单例模式最好的方式之一。

### 9 、不使用锁如何实现线程安全的单例？

除了使用如双重检查锁定）来实现线程安全的单例模式，还有其他几种方式可以实现线程安全的单例，而不需要使用锁。以下是其中两种常见的方式：

1.  饿汉式：

```java
public class Singleton {
    private static Singleton instance = new Singleton();
    private Singleton() {}
    public static Singleton getInstance() {
        return instance;
    }
}
```

在饿汉式中，单例实例在类加载时就被创建，因此不存在并发访问的问题。由于实例的创建是在静态初始化阶段完成的，所以可以保证线程安全性。

1.  静态内部类：

```java
public class Singleton {
    private Singleton() {}
    private static class SingletonHolder {
        private static final Singleton instance = new Singleton();
    }
    public static Singleton getInstance() {
        return SingletonHolder.instance;
    }
}
```

在静态内部类中，单例实例的创建是在调用 `getInstance()` 方法时进行的，利用了类加载的特性实现了懒加载。由于静态内部类只有在被使用时才会被加载，所以也能保证线程安全性。

这些方式都不需要显式地使用锁，因此可以避免锁带来的性能开销。不过需要注意的是，这些方式在某些特殊情况下（如序列化、反射等）可能仍然存在安全问题，需要进行适当的处理来防止破坏单例模式。

### 10、什么是享元模式，有哪些具体应用？

享元模式（Flyweight Pattern）是一种结构型设计模式，其目的是通过共享对象来减少内存使用和提高性能。享元模式通过将对象的状态划分为内部状态（Intrinsic State）和外部状态（Extrinsic State），来实现对象的共享。

具体用场景和示例：

1.  文字编辑器：在文字编辑器中，每个字符都是一个对象，但是字符的属性（如字体、颜色等）可以作为内部状态进行共享，而文字的位置等属性可以作为外部状态进行传递。
2.  线程池：在线程池中，每个线程对象可以看作是一个享元对象，线程的内部状态（如线程ID、状态标识等）是可以共享的，而外部状态（如任务）是不同的，通过外部传入。
3.  资源池：在数据库连接池、连接池等资源管理中，可以使用享元模式来共享和复用资源对象，提高资源的利用率。
4.  游戏中的角色：在游戏中，角色的外观、动作等可以作为内部状态进行共享，而角色的位置、血量等信息可以作为外部状态。

总的来说，享元模式适用于存在大量细粒度对象的场景，通过共享内部状态来减少对象的开销，提高系统的性能和资源利用率。

享元模式（Flyweight Pattern）是一种结构型设计模式，其目的是通过共享对象来减少内存使用和提高性能。享元模式通过将对象的状态划分为内部状态（Intrinsic State）和外部状态（Extrinsic State），来实现对象的共享。

具体用场景和示例：

1.  文字编辑器：在文字编辑器中，每个字符都是一个对象，但是字符的属性（如字体、颜色等）可以作为内部状态进行共享，而文字的位置等属性可以作为外部状态进行传递。
2.  线程池：在线程池中，每个线程对象可以看作是一个享元对象，线程的内部状态（如线程ID、状态标识等）是可以共享的，而外部状态（如任务）是不同的，通过外部传入。
3.  资源池：在数据库连接池、连接池等资源管理中，可以使用享元模式来共享和复用资源对象，提高资源的利用率。
4.  游戏中的角色：在游戏中，角色的外观、动作等可以作为内部状态进行共享，而角色的位置、血量等信息可以作为外部状态。

总的来说，享元模式适用于存在大量细粒度对象的场景，通过共享内部状态来减少对象的开销，提高系统的性能和资源利用率。





#                                             Java框架

## MyBatis

### 1、Mybatis中#和\$的区别？

在MyBatis中，`#`和`$`是两种不同的参数占位符使用方式。

1. `#`占位符：`#`占位符是使用预编译的方式进行参数传递。在SQL语句中，使用`#`可以将参数值安全地替换到SQL语句中，并自动进行参数类型转换和防止SQL注入攻击。使用`#`占位符时，MyBatis会将参数值作为一个整体传递给数据库，因此可以有效地防止SQL注入问题。

   例如：

   `SELECT * FROM users WHERE id = #{userId}`&#x20;

   在上述示例中，`#{userId}`会被替换为具体的参数值，并且会根据参数类型进行合适的转换。

2. `$`占位符：`$`占位符是使用字符串拼接的方式进行参数传递。在SQL语句中，使用`$`可以将参数值直接拼接到SQL语句中，不进行预编译和参数类型转换。使用`$`占位符时，需要注意潜在的安全风险，因为参数值直接拼接到SQL语句中，可能会导致SQL注入攻击。

   例如：

   `SELECT * FROM users WHERE id = ${userId}`&#x20;

   在上述示例中，`${userId}`会被替换为具体的参数值，但不会进行参数类型转换和安全检查。

总结：

-   使用`#`占位符可以提供更安全和可靠的参数传递方式，适用于大多数情况。
-   使用`$`占位符可以提供更灵活的参数传递方式，但需要注意安全性和潜在的SQL注入问题。

在选择使用`#`还是`$`时，需要根据具体的需求和安全考虑来决定。一般来说，推荐使用`#`占位符，除非有特殊的需求需要使用`$`占位符。

### 2、Mybatis的编程步骤是什么样的？

● 创建SqlSessionFactory

● 通过SqlSessionFactory创建SqlSession

● 通过sqlsession执行数据库操作

● 调用session.commit()提交事务

● 调用session.close()关闭会话

### 3、JDBC编程有哪些不足之处，MyBatis是如何解决这些问题的？

JDBC编程在某些方面存在一些不足之处，而MyBatis通过提供一种更高级的抽象层来解决这些问题。以下是JDBC编程的一些不足之处以及MyBatis是如何解决这些问题的：

1.  **繁琐的代码**：JDBC编程需要编写大量的重复代码，包括连接数据库、创建和释放资源、处理结果集等。这使得代码冗长、难以维护和理解。
    -   MyBatis通过提供一个简洁的配置文件和映射文件，将数据库操作的细节抽象出来，使得开发者只需关注SQL语句和参数映射，大大减少了繁琐的代码量。
2.  **SQL与Java代码的耦合**：在JDBC编程中，SQL语句通常直接嵌入在Java代码中，导致SQL与Java代码紧密耦合，不易于维护和修改。
    -   MyBatis使用了面向SQL的思想，将SQL语句与Java代码分离，通过映射文件将SQL语句与Java对象进行映射，使得SQL与Java代码解耦，提高了代码的可维护性和可读性。
3.  **手动参数设置和结果集处理**：在JDBC编程中，需要手动设置参数并处理结果集，包括类型转换、结果集遍历等，增加了开发的工作量和出错的可能性。
    -   MyBatis通过提供参数映射和结果集映射的功能，自动处理参数设置和结果集转换，开发者只需定义映射关系，MyBatis会自动完成参数设置和结果集处理，简化了开发过程。
4.  **缺乏对象关系映射（ORM）支持**：JDBC编程需要手动将数据库查询结果映射到Java对象中，缺乏对对象关系映射的支持，增加了开发的复杂性。
    -   MyBatis提供了强大的对象关系映射（ORM）功能，可以将查询结果自动映射到Java对象中，支持一对一、一对多、多对一等复杂的关系映射，简化了数据操作的过程。
5.  **缺乏缓存支持**：JDBC编程没有内置的缓存机制，每次查询都需要访问数据库，降低了性能。
    -   MyBatis提供了一级缓存和二级缓存的支持。一级缓存是在同一个会话中的缓存，可以减少对数据库的访问；二级缓存是在多个会话中的缓存，可以共享缓存结果，提高了查询性能。

总的来说，MyBatis通过提供简洁的配置和映射文件、解耦SQL与Java代码、自动处理参数和结果集、支持对象关系映射和缓存等功能，弥补了JDBC编程的不足之处，提供了更便捷、高效和可维护的数据库访问解决方案。

### 4、使用MyBatis的mapper接口调用时有哪些要求？

● Mapper接口方法名和mapper.xml中定义的每个sql的id相同

● Mapper接口方法的输入参数类型和mapper.xml中定义的每个sql的parameterType的类型相同

● Mapper接口方法的输出参数类型和mapper.xml中定义的每个sql的resultType的类型相同

● Mapper.xml文件中的namespace即是mapper接口的类路径。

### 5、Mybatis中一级缓存与二级缓存？

在 MyBatis 中，存在一级缓存和二级缓存两种缓存机制。

1.  一级缓存：
    -   一级缓存是 MyBatis 默认开启的缓存机制，也被称为本地缓存。
    -   一级缓存的作用范围是在同一个 SqlSession 内部，即在同一个会话期间，多次执行相同的查询语句，第一次查询结果会被缓存到一级缓存中，后续的查询会直接从缓存中获取结果，而不再去查询数据库。
    -   一级缓存是基于对象引用的方式实现的，因此在同一个会话期间，如果对查询结果进行了修改（例如更新、插入、删除等操作），则会清空一级缓存，以保证数据的一致性。
2.  二级缓存：
    -   二级缓存是 MyBatis 的全局缓存机制，作用范围是在同一个 Mapper 的 namespace 中，即多个 SqlSession 共享同一个 Mapper 的缓存。
    -   二级缓存可以跨越多个会话，当多个会话执行相同的查询语句时，第一个会话的查询结果会被缓存到二级缓存中，后续的会话可以直接从缓存中获取结果，而不再去查询数据库。
    -   二级缓存是基于序列化的方式实现的，因此要求缓存的对象必须是可序列化的。
    -   默认情况下，二级缓存是关闭的，需要在 Mapper 的配置文件中显式配置开启。

需要注意的是：

-   一级缓存和二级缓存是独立的，互不影响。
-   二级缓存是可选的，可以根据需要选择是否开启。
-   二级缓存的使用需要注意数据的一致性和并发访问的问题，特别是在多线程环境下。

总结： &#x20;
一级缓存是在同一个会话期间的缓存，而二级缓存是在同一个 Mapper 的命名空间中的缓存。一级缓存是默认开启的，二级缓存是可选的。在实际应用中，可以根据需求选择合适的缓存机制来提高查询性能。

### 6、MyBatis在insert插入操作时如何返回主键ID？

在 MyBatis 中，可以通过以下几种方式来获取插入操作后生成的主键 ID：

1. 使用数据库的自增主键：

   -   如果你的表使用了数据库的自增主键（如 MySQL 的 AUTO\_INCREMENT），则在执行插入操作后，可以通过 `SELECT LAST_INSERT_ID()` 来获取最后插入的主键 ID。
   -   在 MyBatis 的映射文件（Mapper XML）中，可以使用 `<selectKey>` 元素来配置获取主键的语句，例如：

   ```纯文本
   <insert id="insertUser" parameterType="User">
     <selectKey keyProperty="id" resultType="Long" order="AFTER">
       SELECT LAST_INSERT_ID()
     </selectKey>
     INSERT INTO user (username, password) VALUES (#{username}, #{password})
   </insert>
   ```

   -   在执行插入操作后，MyBatis 会自动执行 `<selectKey>` 中配置的语句，并将获取到的主键值设置到对应的属性（`keyProperty`）中。

2. 使用数据库的序列（Sequence）：

   -   如果你的表使用了数据库的序列（如 Oracle 的序列），则可以通过调用序列的 `NEXTVAL` 函数来获取下一个序列值作为主键 ID。
   -   在 MyBatis 的映射文件中，可以使用 `<selectKey>` 元素来配置获取序列值的语句，例如：

   ```纯文本
   <insert id="insertUser" parameterType="User">
     <selectKey keyProperty="id" resultType="Long" order="BEFORE">
       SELECT user_seq.NEXTVAL FROM DUAL
     </selectKey>
     INSERT INTO user (id, username, password) VALUES (#{id}, #{username}, #{password})
   </insert>
   ```

   -   在执行插入操作前，MyBatis 会先执行 `<selectKey>` 中配置的语句，并将获取到的序列值设置到对应的属性（`keyProperty`）中。

3. 使用数据库的触发器（Trigger）：

   -   如果你的表使用了数据库的触发器，在触发器中可以获取插入操作后生成的主键 ID，并将其设置到对应的列中。
   -   在 MyBatis 中，执行插入操作后，可以通过查询插入的记录来获取主键 ID，例如：

   ```纯文本
   // 执行插入操作
   sqlSession.insert("insertUser", user);
   
   // 获取插入后的主键 ID
   Long id = user.getId();
   ```

根据你所使用的数据库和表的配置，选择适合的方式来获取插入操作后的主键 ID。

### 7、简述 Mybatis 的插件运行原理，如何编写一个插件

答： Mybatis 只支持针对 ParameterHandler、ResultSetHandler、StatementHandler、Executor 这4 种接口的插件， Mybatis 使用 JDK 的动态代理， 为需要拦截的接口生成代理对象以实现接口方法拦截功能， 每当执行这 4 种接口对象的方法时，就会进入拦截方法，具体就是 InvocationHandler 的invoke() 方法， 拦截那些你指定需要拦截的方法。

编写插件： 实现 Mybatis 的 Interceptor 接口并复写 intercept()方法， 然后在给插件编写注解， 指定
要拦截哪一个接口的哪些方法即可， 在配置文件中配置编写的插件。

```java
@Intercepts({@Signature(type = StatementHandler.class, method = "query", args =
{Statement.class, ResultHandler.class}),
@Signature(type = StatementHandler.class, method = "update", args =
{Statement.class}),
@Signature(type = StatementHandler.class, method = "batch", args = {
Statement.class })})
@Component
invocation.proceed()执行具体的业务逻辑
```



## Spring、SpringMVC、SpringBoot

### 1. 什么是 Spring IOC 容器？

Spring 框架的核心是 Spring 容器。容器创建对象，将它们装配在一起，配置它们并管理它们的完整生命周期。Spring 容器使用依赖注入来管理组成应用程序的组件。容器通过读取提供的配置元数据来接收对象进行实例化，配置和组装的指令。该元数据可以通过 XML，Java 注解或 Java 代码提供。

(ioc是spring框架的两大核心之一。ioc就是控制反转，简单的来说就是将创建对象的权利交由spring框架进行管理，spring会根据配置文件去创建实例对象以及管理依赖。以前创建对象的时机都是自己把握，主动权在自己的手上，现在可以使用java的反射机制进行自动生产，根据配置文件在运行时动态的去创建对象以及管理对象，并调用对象的方法。DI依赖注入，是IOC的一种具体实现方式，就是通过容器获取对象，并进行属性的赋值。IOC是一种思想，而DI是一种实现。)

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\Java框架\Spring、SpringMVC、SpringBoot\image\image_hSHMCVzNU0.png)

### 2. 如何实现一个Spring容器

1、配置文件配置包扫描路径
2、递归包扫描获取.class文件
3、反射、确定需要交给IOC管理的类
4、对需要注入的类进行依赖注入

配置文件中指定需要扫描的包路径
定义一些注解，分别表示访问控制层、业务服务层、数据持久层、依赖注入注解、获取配置文件注
解
从配置文件中获取需要扫描的包路径，获取到当前路径下的文件信息及文件夹信息，我们将当前路
径下所有以.class结尾的文件添加到一个Set集合中进行存储
遍历这个set集合，获取在类上有指定注解的类，并将其交给IOC容器，定义一个安全的Map用来存储这些对象
遍历这个IOC容器，获取到每一个类的实例，判断里面是有有依赖其他的类的实例，然后进行递归注入。

### 3. 什么是依赖注入？可以通过多少种方式完成依赖注入？

在依赖注入中，您不必创建对象，但必须描述如何创建它们。您不是直接在代码中将组件和服务连接在一起，而是描述配置文件中哪些组件需要哪些服务。由 IoC 容器将它们装配在一起。

通常，依赖注入可以通过三种方式完成，即：

-   构造函数注入
-   setter 注入
-   接口注入

在 Spring Framework 中，仅使用构造函数和 setter 注入。

### 4. BeanFactory 和 ApplicationContext的区别？

ApplicationContext是BeanFactory的子接口
ApplicationContext提供了更完整的功能：
①继承MessageSource，因此支持国际化。
②统一的资源文件访问方式。
③提供在监听器中注册bean的事件。
④同时加载多个配置文件。
⑤载入多个（有继承关系）上下文 ，使得每一个上下文都专注于一个特定的层次，比如应用的web层。
BeanFactroy采用的是延迟加载形式来注入Bean的，即只有在使用到某个Bean时(调用
getBean())，才对该Bean进行加载实例化。这样，我们就不能发现一些存在的Spring的配置问
题。如果Bean的某一个属性没有注入，BeanFacotry加载后，直至第一次使用调用getBean方法才会抛出异常。

ApplicationContext，它是在容器启动时，一次性创建了所有的Bean。这样，在容器启动时，我
们就可以发现Spring中存在的配置错误，这样有利于检查所依赖属性是否注入。
ApplicationContext启动后预载入所有的单实例Bean，通过预载入单实例bean ,确保当你需要的时候，你就不用等待，因为它们已经创建好了。
相对于基本的BeanFactory，ApplicationContext 唯一的不足是占用内存空间。当应用程序配置
Bean较多时，程序启动较慢。
BeanFactory通常以编程的方式被创建，ApplicationContext还能以声明的方式创建，如使用
ContextLoader。
BeanFactory和ApplicationContext都支持BeanPostProcessor、BeanFactoryPostProcessor的
使用，但两者之间的区别是：BeanFactory需要手动注册，而ApplicationContext则是自动注册

### 5. 构造函数注入和 setter 注入

构造函数注入和setter注入是依赖注入（Dependency Injection）中两种常见的方式，用于将依赖对象注入到目标对象中。它们在注入方式和使用方式上有所不同。

1.  构造函数注入（Constructor Injection）：
    -   构造函数注入是通过目标对象的构造函数来接收依赖对象的注入。
    -   依赖对象在创建目标对象时通过构造函数的参数传递进来。
    -   一旦目标对象被创建，其依赖对象就不能再改变。
    -   构造函数注入可以保证目标对象在创建时就具备了必要的依赖，使得目标对象的状态是完整和一致的。

示例（Java）：

```纯文本
public class UserService {
    private UserRepository userRepository;

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    // 使用userRepository进行用户操作
}

```

1.  Setter注入（Setter Injection）：
    -   Setter注入是通过目标对象的setter方法来接收依赖对象的注入。
    -   依赖对象通过setter方法设置到目标对象中。
    -   可以在任何时候通过调用setter方法来改变目标对象的依赖对象。
    -   Setter注入可以提供更灵活的依赖注入方式，允许在运行时动态地改变依赖对象。

示例（Java）：

```纯文本
public class UserService {
    private UserRepository userRepository;

    public void setUserRepository(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    // 使用userRepository进行用户操作
}

```

总结：

-   构造函数注入适用于那些在目标对象创建时就必须具备依赖对象的情况，可以保证目标对象的依赖是不可变的。
-   Setter注入适用于那些依赖对象可以在运行时动态改变的情况，提供了更大的灵活性。
-   在选择注入方式时，应根据具体的需求和设计考虑使用哪种方式，或者在需要时结合两种方式使用。

### 6. spring 提供了哪些配置方式？

-   基于 xml 配置

bean 所需的依赖项和服务在 XML 格式的配置文件中指定。这些配置文件通常包含许多 bean 定义和特定于应用程序的配置选项。它们通常以 bean 标签开头。例如：

```纯文本
<bean id="studentbean" class="org.edureka.firstSpring.StudentBean">
 <property name="name" value="Edureka"></property>
</bean>
```

-   基于注解配置

您可以通过在相关的类，方法或字段声明上使用注解，将 bean 配置为组件类本身，而不是使用 XML 来描述 bean 装配。默认情况下，Spring 容器中未打开注解装配。因此，您需要在使用它之前在 Spring 配置文件中启用它。例如：

```纯文本
<beans>
<context:annotation-config/>
<!-- bean definitions go here -->
</beans>
```

-   基于 Java Config配置—目前使用主流。

Spring 的 Java 配置是通过使用 @Bean 和 @Configuration 来实现。

1.  @Bean 注解扮演与 元素相同的角色。
2.  @Configuration 类允许通过简单地调用同一个类中的其他 @Bean 方法来定义 bean 间依赖关系。
3.  @Component注解

例如：

```java
@Configuration
public class AppConfig{
    @Bean
    public Student Student () {
        return new Student ();
    }
}
@Component
public class Person{
  
}


```

### 7. Spring 中的 bean 的作用域有哪些?

**singleton**：默认，每个容器中只有一个bean的实例，单例的模式由BeanFactory自身来维护。该对象的生命周期是与Spring IOC容器一致的（但在第一次被注入时才会创建）

\*\*prototype \*\*: 每次请求都会创建一个新的 bean 实例

**request：** bean被定义为在每个HTTP请求中创建一个单例对象，也就是说在单个请求中都会复用这一个单例对象。

**session**：与request范围类似，确保每个session中有一个bean的实例，在session过期后，bean会随之失效。

**application**：bean被定义为在ServletContext的生命周期中复用一个单例对象。

**websocket**：bean被定义为在websocket的生命周期中复用一个单例对象。

**global-session**：全局作用域，global-session和Portlet应用相关。当你的应用部署在Portlet容器中工作时，它包含很多portlet。如果你想要声明让所有的portlet共用全局的存储变量的话，那么这全局变量需要存储在global-session中。全局作用域与Servlet中的session作用域效果相同。

**refesh**:Springcloud组件扩展了Bean对象的作用域在一次配置文件修改之后有效。

### 8. 深入谈谈对Ioc的理解？

容器概念、控制反转、依赖注入&#x20;

**Ioc容器**：

实际上就是个map（key，value），里面存的是各种对象（在xml里配置的bean节点、@repository、@service、@controller、@component），在项目启动的时候会读取配置文件里面的bean节点，根据全限定类名使用反射创建对象放到map里、扫描到打上上述注解的类还是通过反射创建对象放到map里。这个时候map里就有各种对象了，接下来我们在代码里需要用到里面的对象时，再通过DI注入（@autowired、@resource等注解，xml里bean节点内的ref属性，项目启动的时候会读取xml节点ref属性根据id注入，也会扫描这些注解，根据类型或id注入；id就是对象名）。

**控制反转**：
没有引入IOC容器之前，对象A依赖于对象B，那么对象A在初始化或者运行到某一点的时候，自己必须主动去创建对象B或者使用已经创建的对象B。无论是创建还是使用对象B，控制权都在自己手上。引入IOC容器之后，对象A与对象B之间失去了直接联系，当对象A运行到需要对象B的时候，IOC容器会主动创建一个对象B注入到对象A需要的地方。
通过前后的对比，不难看出来：对象A获得依赖对象B的过程,由主动行为变为了被动行为，控制权颠倒过来了，这就是“控制反转”这个名称的由来。全部对象的控制权全部上缴给“第三方”IOC容器，所以，IOC容器成了整个系统的关键核心，它起到了一种类似“粘合剂”的作用，把系统中的所有对象粘合在一起发挥作用，如果没有这个“粘合剂”，对象与对象之间会彼此失去联系，这就是有人把IOC容器比喻成“粘合剂”的由来。

**依赖注入：**
"获得依赖对象的过程被反转了"。控制被反转之后，获得依赖对象的过程由自身管理变为了由IOC容器主动注入。依赖注入是实现IOC的方法，就是由IOC容器在运行期间，动态地将某种依赖关系注入到对象之中。

### 9. 将一个类声明为Spring的 bean 的注解有哪些?

我们一般使用 @Autowired 注解自动装配 bean，要想把类标识成可用于 @Autowired 注解自动装配的 bean 的类,采用以下注解可实现：

-   @Component ：通用的注解，可标注任意类为 Spring 组件。如果一个Bean不知道属于哪个层，可以使用@Component 注解标注。&#x20;
-   @Repository : 对应持久层即 Dao 层，主要用于数据库相关操作。
-   @Service : 对应服务层，主要涉及一些复杂的逻辑，需要用到 Dao层。
-   @Controller : 对应 Spring MVC 控制层，主要用户接受用户请求并调用 Service 层返回数据给前端页面。
-   @Configuration+\@Bean的方式

### 10. Spring 中的 bean 生命周期?

1.扫描生成BeanDefinition,并注册到BeanDefinitionMap中

2.合并得到BeanDefiniton.

3.加载类resolveBeanClass

4.实例化前

5.实例化

6.实例化后

7.属性填充

8.执行各种Aware

9.初始化前

10.初始化

11.初始化后

12.放入单例池

13.使用Bean对象

14.销毁Spring容器关闭时调用DisposableBean中destory()方法。

其中在实例化前后以及初始化前后程序员都可以通过BeanPostProcessor或者BeanPostProcessor接口的子接口InstantiationAwareBeanPostProcessor进行扩展。

因为Bean的生命周期涉及到的细节太多了...具体源码分析流程，可参考面试题精讲。

### 11.什么是bean的自动装配，有哪些方式？

开启自动装配，只需要在xml配置文件中定义“autowire”属性。

```java
<bean id="cutomer" class="com.xxx.xxx.Customer" autowire="" />
```

autowire属性有六种装配的方式：

1、no – 缺省情况下，自动配置是通过“ref”属性手动设定 。

手动装配：以value或ref的方式明确指定属性值都是手动装配。
需要通过‘ref’属性来连接bean。

2、byName-根据bean的属性名称进行自动装配。

```java
Cutomer的属性名称是person，Spring会将bean id为person的bean通过setter方法进行自动装
配。
<bean id="cutomer" class="com.xxx.xxx.Cutomer" autowire="byName"/>
<bean id="person" class="com.xxx.xxx.Person"/>
```

3、byType-根据bean的类型进行自动装配

```java
Cutomer的属性person的类型为Person，Spirng会将Person类型通过setter方法进行自动装配。
<bean id="cutomer" class="com.xxx.xxx.Cutomer" autowire="byType"/>
<bean id="person" class="com.xxx.xxx.Person"/>
```

4、constructor-类似byType，不过是应用于构造器的参数。如果一个bean与构造器参数的类型形相同，则进行自动装配，否则导致失效。

```java
Cutomer构造函数的参数person的类型为Person，Spirng会将Person类型通过构造方法进行自动装
配。
<bean id="cutomer" class="com.xxx.xxx.Cutomer" autowire="construtor"/>
<bean id="person" class="com.xxx.xxx.Person"/>
```

5、autodetect-如果有默认的构造器，则通过constructor方式进行自动装配，否则使用byType方式进行自动装配。但是spring3.0+已将该值废弃。

```text
如果有默认的构造器，则通过constructor方式进行自动装配，否则使用byType方式进行自动装配
```

6、 default：由上级标签\<beans>的default-autowire属性确定。

@Autowired自动装配bean，可以在字段、setter方法、构造函数上使用。相比Spring自带的自动注入方式，更加灵活。

### 12. Spring中出现同名bean怎么办？

-   如果是在不同的@Component注解中定义的同一个BeanName，那么Spring会直接报错。

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\Java框架\Spring、SpringMVC、SpringBoot\image\图片_jTMLr9a8Cg.png)

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\Java框架\Spring、SpringMVC、SpringBoot\image\图片_hP3d0bat68.png)

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\Java框架\Spring、SpringMVC、SpringBoot\image\图片_lnhfbl70uZ.png)

-   如果是ComponentScan和@Bean出现同名Bean。那么@Bean的会生效，@ComponentScan扫描进来不会生效。原因就是扫描进来的Bean定义是最先被注册的,而Spring默认又是支持BeanDefinition重写。也即allowBeanDefinitionOverriding为true,因此Spring底层就会以后解析的@Bean生成一个新BeanDefinition,且名字仍然是BeanName.然后注册到BeanDefinitonMap中，因此对于Map来说，同一个key的value值以最后一次为准。

### 13. Spring 怎么解决循环依赖问题？

#### 什么是循环依赖:

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\Java框架\Spring、SpringMVC、SpringBoot\image\图片_35rH4qa-5a.png)

这里不会对Bean的生命周期进行详细的描述，只描述一下大概的过程。

Bean的生命周期指的就是：在Spring中，Bean是如何生成的？

被Spring管理的对象叫做Bean。Bean的生成步骤如下：

1.  Spring扫描class得到BeanDefinition
2.  根据得到的BeanDefinition去生成bean
3.  首先根据class推断构造方法
4.  根据推断出来的构造方法，反射，得到一个对象（暂时叫做原始对象）
5.  填充原始对象中的属性（依赖注入）
6.  如果原始对象中的某个方法被AOP了，那么则需要根据原始对象生成一个代理对象
7.  把最终生成的代理对象放入单例池（源码中叫做singletonObjects）中，下次getBean时就直接从单例池拿即可

可以看到，对于Spring中的Bean的生成过程，步骤还是很多的，并且不仅仅只有上面的7步，还有很多很多，比如Aware回调、初始化等等，不详细讨论。

可以发现，在Spring中，构造一个Bean，包括了new这个步骤（第4步构造方法反射）。

得到一个原始对象后，Spring需要给对象中的属性进行依赖注入，那么这个注入过程是怎样的？

比如上文说的A类，A类中存在一个B类的b属性，所以，当A类生成了一个原始对象之后，就会去给b属性去赋值，此时就会根据b属性的类型和属性名去BeanFactory中去获取B类所对应的单例bean。如果此时BeanFactory中存在B对应的Bean，那么直接拿来赋值给b属性；如果此时BeanFactory中不存在B对应的Bean，则需要生成一个B对应的Bean，然后赋值给b属性。

问题就出现在第二种情况，如果此时B类在BeanFactory中还没有生成对应的Bean，那么就需要去生成，就会经过B的Bean的生命周期。

那么在创建B类的Bean的过程中，如果B类中存在一个A类的a属性，那么在创建B的Bean的过程中就需要A类对应的Bean，但是，触发B类Bean的创建的条件是A类Bean在创建过程中的依赖注入，所以这里就出现了循环依赖：

ABean创建-->依赖了B属性-->触发BBean创建--->B依赖了A属性--->需要ABean（但ABean还在创建过程中）

从而导致ABean创建不出来，BBean也创建不出来。

#### 如何解决循环依赖：

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\Java框架\Spring、SpringMVC、SpringBoot\image\图片_O_52PBEwhK.png)

Spring底层最终解决靠的是四个Map（其中三个缓存Map,还有一个是判断有没有提前进行过Aop的Map以及一个Set（判断当前对象是否处于正在创建中）

1.  **singletonObjects**：缓存某个beanName对应的经过了完整生命周期的bean也即我们平时说的单例池。
2.  **earlySingletonObjects**：缓存提前通过原始对象进行了AOP之后得到的代理对象，原始对象还没有进行属性注入和后续的BeanPostProcessor等生命周期
3.  **singletonFactories**：缓存的是一个ObjectFactory，也就是一个Lambda表达式。在创建一个Bean时，在每个Bean的生成过程中，都会提前暴露一个Lambda表达式，并保存到三级缓存中，这个Lambda表达式**可能用到，也可能用不到**，如果没有出现循环依赖依赖本bean，那么这个Lambda表达式无用，本bean按照自己的生命周期执行，执行完后直接把本bean放入singletonObjects中即可，如果出现了循环依赖依赖了本bean，则从三级缓存中获取Lambda表达式，并执行Lambda表达式得到一个AOP之后的代理对象(如果有AOP的话，如果无需AOP，则直接得到一个原始对象)，并把得到的对象放入二级缓存
4.  其实还要一个缓存，就是**earlyProxyReferences**，它用来记录某个原始对象是否进行过AOP了。
5.  \*\*creatingMap \*\*这个作用是去判断是不是出现了循环依赖 也即是不是某个类是不是在创建中。

详情流程分析很多...笔者也不能一下子展开，请结合面试精讲课上的源码分析。

### 14. Spring 中的单例 bean 的线程安全问题？

Spring中的Bean默认是单例模式的，框架并没有对bean进行多线程的封装处理。
如果Bean是有状态的 那就需要开发人员自己来进行线程安全的保证，最简单的办法就是改变bean的作用域 把 "singleton"改为"protopyte" 这样每次请求Bean就相当于是 new Bean() 这样就可以保证线程的安全了。有状态就是有数据存储功能。无状态就是不会保存数据 controller、service和dao层本身并不是线程安全的，只是如果只是调用里面的方法，而且多线程调用一个实例的方法，会在内存中复制变量，这是自己的线程的工作内存，是安全的。

Dao会操作数据库Connection，Connection是带有状态的，比如说数据库事务，Spring的事务管理器使用Threadlocal为不同线程维护了一套独立的connection副本，保证线程之间不会互相影响（Spring是如何保证事务获取同一个Connection的）

不要在bean中声明任何有状态的实例变量或类变量，如果必须如此，那么就使用ThreadLocal把变量变为线程私有的，如果bean的实例变量或类变量需要在多个线程之间共享，那么就只能使用synchronized、lock、CAS等这些实现线程同步的方法了.

### 15. 什么是 AOP？

AOP(Aspect-Oriented Programming), 即 **面向切面编程**, 它与 OOP( Object-Oriented Programming, 面向对象编程) 相辅相成, 提供了与 OOP 不同的抽象软件结构的视角. 在 OOP 中, 我们以类(class)作为我们的基本单元, 而 AOP 中的基本单元是 **Aspect(切面)**

### 16. 谈谈对Aop的理解

系统是由许多不同的组件所组成的，每一个组件各负责一块特定功能。除了实现自身核心功能之外，这些组件还经常承担着额外的职责。例如日志、事务管理和安全这样的核心服务经常融入到自身具有核心业务逻辑的组件中去。这些系统服务经常被称为横切关注点，因为它们会跨越系统的多个组件。当我们需要为分散的对象引入公共行为的时候，OOP则显得无能为力。也就是说，OOP允许你定义从上到下的关系，但并不适合定义从左到右的关系。例如日志功能。
日志代码往往水平地散布在所有对象层次中，而与它所散布到的对象的核心功能毫无关系。
在OOP设计中，它导致了大量代码的重复，而不利于各个模块的重用。
AOP：将程序中的交叉业务逻辑（比如安全，日志，事务等），封装成一个切面，然后注入到目标对象（具体业务逻辑）中去。AOP可以对某个对象或某些对象的功能进行增强，比如对象中的方法进行增强，可以在执行某个方法之前额外的做一些事情，在某个方法执行之后额外的做一些事情。

### 17. AOP 有哪些实现方式？

实现 AOP 的技术，主要分为两大类：

-   静态代理 - 指使用 AOP 框架提供的命令进行编译，从而在编译阶段就可生成 AOP 代理类，因此也称为编译时增强；
    -   编译时编织（特殊编译器实现）
    -   类加载时编织（特殊的类加载器实现）。
-   动态代理 - 在运行时在内存中“临时”生成 AOP 动态代理类，因此也被称为运行时增强。
    -   JDK 动态代理：通过反射来接收被代理的类，并且要求被代理的类必须实现一个接口 。JDK 动态代理的核心是 InvocationHandler 接口和 Proxy 类 。
    -   CGLIB动态代理： 如果目标类没有实现接口，那么 Spring AOP 会选择使用 CGLIB 来动态代理目标类 。CGLIB ，是一个代码生成的类库，可以在运行时动态的生成某个类的子类，注意， CGLIB 是通过继承的方式做的动态代理，因此如果某个类被标记为 final ，那么它是无法使用 CGLIB 做动态代理的。

### 18. Spring 框架中用到了哪些设计模式？

**1**、**工厂设计模式** :&#x20;

**简单工厂**：由一个工厂类根据传入的参数，动态决定应该创建哪一个产品类

Spring中的BeanFactory就是简单工厂模式的体现，根据传入一个唯一的标识来获得Bean对象，但是否是
在传入参数后创建还是传入参数前创建这个要根据具体情况来定。

**工厂方法：**

实现了FactoryBean接口的bean是一类叫做factory的bean。其特点是，spring会在使用getBean()调用获得该bean时，会自动调用该bean的getObject()方法，所以返回的不是factory这个bean，而是这个bean.getOjbect()方法的返回值。

**2、单例模式**

保证一个类仅有一个实例，并提供一个访问它的全局访问点。

spring对单例的实现： spring中的单例模式完成了后半句话，即提供了全局的访问点BeanFactory。但没有从构造器级别去控制单例，这是因为Spring管理的是任意的java对象。

**3、适配器模式：**

Spring定义了一个适配接口，使得每一种Controller有一种对应的适配器实现类，让适配器代替
controller执行相应的方法。这样在扩展Controller时，只需要增加一个适配器类就完成了SpringMVC的扩展了。

**4、装饰器模式：**

动态地给一个对象添加一些额外的职责。就增加功能来说，Decorator模式相比生成子类
更为灵活。

Spring中用到的装饰器模式在类名上有两种表现：一种是类名中含有Wrapper，另一种是类名中含有Decorator。

**5、代理模式：**

切面在应用运行的时刻被织入。一般情况下，在织入切面时，AOP容器会为目标对象创建动态的创建一个代理对象。SpringAOP就是以这种方式织入切面的。

织入：把切面应用到目标对象并创建新的代理对象的过程。

**6、观察者模式**：

spring的事件驱动模型使用的是观察者模式 ，Spring中Observer模式常用的地方是listener的实现。

**7、策略模式：**

Spring框架的资源访问Resource接口。该接口提供了更强的资源访问能力，Spring 框架本身大量使用了Resource 接口来访问底层资源。

**8、模板方法模式** :&#x20;

父类定义了骨架（调用哪些方法及顺序），某些特定方法由子类实现

Spring 中 jdbcTemplate、hibernateTemplate 等以 Template 结尾的对数据库操作的类，它们就使用到了模板模式。

### 19. Spring 事务实现方式有哪些以及原理

-   编程式事务管理：这意味着你可以通过编程的方式管理事务，这种方式带来了很大的灵活性，但很难维护。
-   声明式事务管理：这种方式意味着你可以将事务管理和业务代码分离。你只需要通过注解或者XML配置管理事务。@Transactional注解就是声明式事务。

首先，事务这个概念是数据库层面的，Spring只是基于数据库中的事务进行了扩展，以及提供了一些能让程序员更加方便操作事务的方式。
比如我们可以通过在某个方法上增加@Transactional注解，就可以开启事务，这个方法中所有的sql都会在一个事务中执行，统一成功或失败。
在一个方法上加了@Transactional注解后，Spring会基于这个类生成一个代理对象，会将这个代理对象作为bean，当在使用这个代理对象的方法时，如果这个方法上存在@Transactional注解，那么代理逻辑会先把事务的自动提交设置为false，然后再去执行原本的业务逻辑方法，如果执行业务逻辑方法没有出现异常，那么代理逻辑中就会将事务进行提交，如果执行业务逻辑方法出现了异常，那么则会将事务进行回滚。当然，针对哪些异常回滚事务是可以配置的，可以利用@Transactional注解中的rollbackFor属性进行配置，默认情况下会对RuntimeException和Error进行回滚。

### 20. Spring事务的隔离级别

spring事务隔离级别就是数据库的隔离级别：外加一个默认级别
read uncommitted（未提交读）
read committed（提交读、不可重复读）
repeatable read（可重复读）
serializable（可串行化）

**注意：**

数据库的配置隔离级别是Read Commited,而Spring配置的隔离级别是Repeatable Read，请问这时隔离级别是以哪一个为准？
以Spring配置的为准，如果spring设置的隔离级别数据库不支持，效果取决于数据库。

### 21. Spring事务定义的传播规则

多个事务方法相互调用时,事务如何在这些方法间传播。

方法A是一个事务的方法，方法A执行过程中调用了方法B，那么方法B有无事务以及方法B对事务的要求不同都会对方法A的事务具体执行造成影响，同时方法A的事务对方法B的事务执行也有影响，这种影响具体是什么就由两个方法所定义的事务传播类型所决定。

**REQUIRED(** Spring默认的事务传播类型)：如果当前没有事务，则自己新建一个事务，如果当前存在事务，则加入这个事务。

**SUPPORTS**：当前存在事务，则加入当前事务，如果当前没有事务，就以非事务方法执行。
**MANDATORY**：当前存在事务，则加入当前事务，如果当前事务不存在，则抛出异常。
**REQUIRES\_NEW**：创建一个新事务，如果存在当前事务，则挂起该事务。
**NOT\_SUPPORTED**：以非事务方式执行,如果当前存在事务，则挂起当前事务。
**NEVER**：不使用事务，如果当前事务存在，则抛出异常。
**NESTED**：如果当前事务存在，则在嵌套事务中执行，否则REQUIRED的操作一样（开启一个事务）。

**NESTED**和**REQUIRES\_NEW**的区别
REQUIRES\_NEW是新建一个事务并且新开启的这个事务与原有事务无关，而NESTED则是当前存在事务时（我们把当前事务称之为父事务）会开启一个嵌套事务（称之为一个子事务）。 在NESTED情况下父事务回滚时，子事务也会回滚，而在REQUIRES\_NEW情况下，原有事务回滚，不会影响新开启的事务。

**NESTED**和**REQUIRED**的区别
REQUIRED情况下，调用方存在事务时，则被调用方和调用方使用同一事务，那么被调用方出现异常时，由于共用一个事务，所以无论调用方是否catch其异常，事务都会回滚 而在NESTED情况下，被调用方发生异常时，调用方可以catch其异常，这样只有子事务回滚，父事务不受影响

### 22. Spring事务什么时候会失效

Spring事务的原理是AOP，进行了切面增强，那么失效的根本原因是**这个AOP不起作用了**！常见情况有如下几种
1、发生自调用，类里面使用this调用本类的方法（this通常省略），此时这个this对象不是代理类，而是该类的实例对象本身！
解决方法很简单，让那个this变成该类的的代理类实例对象即可！
2、方法不是public的
3、数据库不支持事务
4、没有被Spring管理
5、异常被吃掉，事务不会回滚(或者抛出的异常没有被定义，默认为RuntimeException)

### 23. SpringMVC 工作原理了解吗?

**流程说明（重要）：**

1\)  用户发送请求至前端控制器 DispatcherServlet。
2）DispatcherServlet 收到请求调用 HandlerMapping 处理器映射器。
3）处理器映射器找到具体的处理器(可以根据 xml 配置、注解进行查找)，生成处理器及处理器拦截器(如果有则生成)一并返回给 DispatcherServlet。
4）DispatcherServlet 调用 HandlerAdapter 处理器适配器。
5）HandlerAdapter 经过适配调用具体的处理器(Controller，也叫后端控制器)
6）Controller 执行完成返回 ModelAndView。
7）HandlerAdapter 将 controller 执行结果 ModelAndView 返回给 DispatcherServlet。

8）DispatcherServlet 将 ModelAndView 传给 ViewReslover 视图解析器。
9）ViewReslover 解析后返回具体 View。
10）DispatcherServlet 根据 View 进行渲染视图（即将模型数据填充至视图中）。
11）DispatcherServlet 响应用户。

### 24. 简单介绍 Spring MVC 的核心组件

Handler：也就是处理器。它直接应对着MVC中的C也就是Controller层，它的具体表现形式有很多，可以是类，也可以是方法。在Controller层中@RequestMapping标注的所有方法都可以看成是一个Handler，只要可以实际处理请求就可以是Handler。
1、**HandlerMapping**
initHandlerMappings(context)，处理器映射器，根据用户请求的资源uri来查找Handler的。在SpringMVC中会有很多请求，每个请求都需要一个Handler处理，具体接收到一个请求之后使用哪个Handler进行，这就是HandlerMapping需要做的事。

2、**HandlerAdapter**
initHandlerAdapters(context)，适配器。因为SpringMVC中的Handler可以是任意的形式，只要能处理请求就ok，但是Servlet需要的处理方法的结构却是固定的，都是以request和response为参数的方法。如何让固定的Servlet处理方法调用灵活的Handler来进行处理呢？这就是HandlerAdapter要做的事情。Handler是用来干活的工具；HandlerMapping用于根据需要干的活找到相应的工具；HandlerAdapter是使用工具干活的人

。
3、**HandlerExceptionResolver**
initHandlerExceptionResolvers(context)， 其它组件都是用来干活的。在干活的过程中难免会出现问题，出问题后怎么办呢？这就需要有一个专门的角色对异常情况进行处理，在SpringMVC中就是HandlerExceptionResolver。具体来说，此组件的作用是根据异常设置ModelAndView，之后再交给render方法进行渲染。

4、**ViewResolver**
initViewResolvers(context)，ViewResolver用来将String类型的视图名和Locale解析为View类型的视图。View是用来渲染页面的，也就是将程序返回的参数填入模板里，生成html（也可能是其它类型）文件。这里就有两个关键问题：使用哪个模板？用什么技术（规则）填入参数？这其实是ViewResolver主要要做的工作，ViewResolver需要找到渲染所用的模板和所用的技术（也就是视图的类型）进行渲染，具体的渲染过程则交由不同的视图自己完成。

5、**RequestToViewNameTranslator**
initRequestToViewNameTranslator(context)，ViewResolver是根据ViewName查找View，但有的Handler处理完后并没有设置View也没有设置ViewName，这时就需要从request获取ViewName了，如何从request中获取ViewName就是RequestToViewNameTranslator要做的事情了。RequestToViewNameTranslator在Spring MVC容器里只可以配置一个，所以所有request到ViewName的转换规则都要在一个Translator里面全部实现。

6、**LocaleResolver**
initLocaleResolver(context)， 解析视图需要两个参数：一是视图名，另一个是Locale。视图名是处理器返回的，Locale是从哪里来的？这就是LocaleResolver要做的事情。LocaleResolver用于从request解析出Locale，Locale就是zh-cn之类，表示一个区域，有了这个就可以对不同区域的用户显示不同的结果。SpringMVC主要有两个地方用到了Locale：一是ViewResolver视图解析的时候；二是用到国际化资源或者主题的时候。

7、**ThemeResolver**
initThemeResolver(context)，用于解析主题。SpringMVC中一个主题对应一个properties文件，里面存放着跟当前主题相关的所有资源、如图片、css样式等。SpringMVC的主题也支持国际化，同一个主题不同区域也可以显示不同的风格。SpringMVC中跟主题相关的类有 ThemeResolver、ThemeSource和Theme。主题是通过一系列资源来具体体现的，要得到一个主题的资源，首先要得到资源的名称，这是ThemeResolver的工作。然后通过主题名称找到对应的主题（可以理解为一个配置）文件，这是ThemeSource的工作。最后从主题中获取资源就可以了。

8、**MultipartResolver**
initMultipartResolver(context)，用于处理上传请求。处理方法是将普通的request包装成
MultipartHttpServletRequest，后者可以直接调用getFile方法获取File，如果上传多个文件，还可以调用getFileMap得到FileName->File结构的Map。此组件中一共有三个方法，作用分别是判断是不是上传请求，将request包装成MultipartHttpServletRequest、处理完后清理上传过程中产生的临时资源。

9、**FlashMapManager**
initFlashMapManager(context)，用来管理FlashMap的，FlashMap主要用在redirect中传递参数。

### 25. @Controller 注解有什么用？

@Controller 注解标记一个类为 Spring Web MVC **控制器** Controller。Spring MVC 会将扫描到该注解的类，然后扫描这个类下面带有 @RequestMapping 注解的方法，根据注解信息，为这个方法生成一个对应的**处理器**对象，在上面的 HandlerMapping 和 HandlerAdapter组件中讲到过。当然，除了添加 @Controller 注解这种方式以外，你还可以实现 Spring MVC 提供的 Controller 或者 HttpRequestHandler 接口，对应的实现类也会被作为一个**处理器**对象

### 26. @RestController 和 @Controller 有什么区别？

@RestController 注解，在 @Controller 基础上，增加了 @ResponseBody 注解，更加适合目前前后端分离的架构下，提供 Restful API ，返回例如 JSON 数据格式。当然，返回什么样的数据格式，根据客户端的 ACCEPT 请求头来决定。

### 27. @RequestMapping 和 @GetMapping 注解的不同之处在哪里？

1.  @RequestMapping：可注解在类和方法上；@GetMapping 仅可注册在方法上
2.  @RequestMapping：可进行 GET、POST、PUT、DELETE 等请求方法；@GetMapping 是 @RequestMapping 的 GET 请求方法的特例，目的是为了提高清晰度。

### 28. @RequestParam 和 @PathVariable 两个注解的区别

两个注解都用于方法参数，获取参数值的方式不同，@RequestParam 注解的参数从请求携带的参数中获取，而 @PathVariable 注解从请求的 URI 中获取。

### 29. 返回 JSON 格式使用什么注解？

可以使用 **@ResponseBody** 注解，或者使用包含 @ResponseBody 注解的 **@RestController** 注解。

当然，还是需要配合相应的支持 JSON 格式化的 HttpMessageConverter 实现类。例如，Spring MVC 默认使用 MappingJackson2HttpMessageConverter。

### 30. 什么是springmvc拦截器以及如何使用它？

Spring MVC拦截器（Interceptor）是一种用于拦截和处理请求的组件，它可以在请求的前后进行处理，并对请求进行修改或添加额外的功能。拦截器可以用于实现一些通用的功能，例如身份验证、日志记录、性能监控等。

以下是使用Spring MVC拦截器的步骤：

1.  创建拦截器类：
    -   创建一个实现HandlerInterceptor接口的拦截器类。
    -   拦截器类可以包含在Spring MVC应用程序的任何位置，例如包下的一个单独类或者一个独立的模块。
2.  实现拦截器方法：
    -   在拦截器类中实现preHandle、postHandle和afterCompletion等方法。
    -   preHandle方法在请求处理之前执行，可以进行一些前置处理，例如身份验证、权限检查等。
    -   postHandle方法在请求处理之后、视图渲染之前执行，可以对模型数据进行处理或添加额外的功能。
    -   afterCompletion方法在整个请求完成之后执行，可以进行一些资源清理或日志记录等操作。
3.  配置拦截器：
    -   在Spring MVC配置文件（如XML配置文件或Java配置类）中配置拦截器。
    -   通过注册拦截器类的方式将其添加到拦截器链中。
    -   可以指定拦截器的拦截路径（URL模式）或排除路径，以确定哪些请求会被拦截。
4.  测试拦截器：
    -   启动Spring MVC应用程序，并发送请求进行测试。
    -   拦截器将根据配置的规则拦截相应的请求，并执行拦截器方法。

通过使用Spring MVC拦截器，您可以在请求的前后进行处理，实现一些通用的功能和逻辑。拦截器提供了一种灵活的方式来对请求进行拦截和处理，使您能够在应用程序中添加额外的功能和行为。

### 31. 为什么要用SpringBoot?

在使用Spring框架进行开发的过程中，需要配置很多Spring框架包的依赖，如spring-core、spring-bean、spring-context等，而这些配置通常都是重复添加的，而且需要做很多框架使用及环境参数的重复配置，如开启注解、配置日志等。Spring Boot致力于弱化这些不必要的操作，提供默认配置，当然这些默认配置是可以按需修改的，快速搭建、开发和运行Spring应用。

以下是使用SpringBoot的一些好处：

-   自动配置，使用基于类路径和应用程序上下文的智能默认值，当然也可以根据需要重写它们以满足开发人员的需求。
-   创建Spring Boot Starter 项目时，可以选择选择需要的功能，Spring Boot将为你管理依赖关系。
-   SpringBoot项目可以打包成jar文件。可以使用Java-jar命令从命令行将应用程序作为独立的Java应用程序运行。
-   在开发web应用程序时，springboot会配置一个嵌入式Tomcat服务器，以便它可以作为独立的应用程序运行。（Tomcat是默认的，当然你也可以配置Jetty或Undertow）
-   SpringBoot包括许多有用的非功能特性（例如安全和健康检查）。
    -

### 32.Spring Boot 自动配置原理？

@Import + @Configuration + Spring spi
自动配置类由各个starter提供，使用@Configuration + @Bean定义配置类，放到META-
INF/spring.factories下。
使用Spring spi扫描META-INF/spring.factories下的配置类。
使用@Import导入自动配置类。

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\Java框架\Spring、SpringMVC、SpringBoot\image\图片_3e5Q5o8qjK.png)

详细流程原理分析，参考毕业精讲课。

### 33. Spring Boot中如何实现对不同环境的属性配置文件的支持？

Spring Boot支持不同环境的属性配置文件切换，通过创建application-{profile}.properties文件，其中{profile}是具体的环境标识名称，

例如：

application-dev.properties用于开发环境，

application-test.properties用于测试环境，

application-uat.properties用于uat环境。

如果要想使用application-dev.properties文件，则在application.properties文件中添加spring.profiles.active=dev。

如果要想使用application-test.properties文件，则在application.properties文件中添加spring.profiles.active=test。

### 34. Spring Boot 的核心注解是哪个？它主要由哪几个注解组成的？

启动类上面的注解是@SpringBootApplication，它也是 Spring Boot 的核心注解，主要组合包含了以下 3 个注解：

@SpringBootConfiguration：组合了 @Configuration 注解，实现配置文件的功能。

@EnableAutoConfiguration：打开自动配置的功能，也可以关闭某个自动配置的选项，如关闭数据源自动配置功能： @SpringBootApplication(exclude = { DataSourceAutoConfiguration.class })。

@ComponentScan：Spring组件扫描。

### 35. 你如何理解 Spring Boot 中的 Starter？

使用spring + springmvc使用，如果需要引入mybatis等框架，需要到xml中定义mybatis需要的bean.

starter就是定义一个starter的jar包，写一个@Configuration配置类、将这些bean定义在里面，然后在starter包的META-INF/spring.factories中写入该配置类，springboot会按照约定来加载该配置类.

开发人员只需要将相应的starter包依赖进应用，进行相应的属性配置（使用默认配置时，不需要配置），就可以直接进行代码开发，使用对应的功能了，比如mybatis-spring-boot--starter，spring-boot-starter-redis.

### 36. Spring Boot Starter 的工作原理是什么？

Spring Boot 在启动的时候会干这几件事情：

-   Spring Boot 在启动时会去依赖的 Starter 包中寻找 resources/META-INF/spring.factories 文件，然后根据文件中配置的 Jar 包去扫描项目所依赖的 Jar 包。
-   根据 spring.factories 配置加载 AutoConfigure 类
-   根据 @Conditional 注解的条件，进行自动配置并将 Bean 注入 Spring Context

总结一下，其实就是 Spring Boot 在启动的时候，按照约定去读取 Spring Boot Starter 的配置信息，再根据配置信息对资源进行初始化，并注入到 Spring 容器中。这样 Spring Boot 启动完毕后，就已经准备好了一切资源，使用过程中直接注入对应 Bean 资源即可.

### 37. 什么是嵌入式服务器？为什么要使用嵌入式服务器?

节省了下载安装tomcat，应用也不需要再打war包，然后放到webapp目录下再运行
只需要一个安装了 Java 的虚拟机，就可以直接在上面部署应用程序了
springboot已经内置了tomcat.jar，运行main方法时会去启动tomcat，并利用tomcat的spi机制加载
springmvc



## SpringCloud

### 1、spring cloud断路器的作用是什么？

Spring Cloud断路器（Hystrix）是一种用于构建弹性、容错和容灾机制的开源库。它提供了一种通过隔离和控制远程服务调用的方式，以防止由于服务故障或延迟而导致的级联故障。

断路器的作用如下：

1.  故障隔离：断路器通过将远程服务调用封装在一个独立的断路器中，可以隔离故障的影响范围。当远程服务发生故障或延迟时，断路器可以快速失败并返回预定义的默认值，而不会影响整个系统的稳定性。
2.  容错处理：断路器可以在远程服务不可用时提供备用方案。通过配置降级逻辑，可以在远程服务故障时返回预先定义的备用数据，以保证系统的可用性和稳定性。
3.  自动恢复：断路器具备自我修复的能力。它会定期尝试恢复远程服务的调用，以检查其可用性。当远程服务恢复正常时，断路器会逐渐恢复对该服务的调用，并重新建立正常的调用链路。
4.  实时监控：断路器提供了实时监控和度量功能，可以收集和展示远程服务调用的各项指标，如调用次数、失败率、响应时间等。这些指标可以帮助开发人员和运维人员了解系统的健康状况，并进行故障排查和性能优化。

通过使用Spring Cloud断路器，可以有效地处理分布式系统中的服务故障和延迟问题，提高系统的容错性和可用性。它是构建弹性和可靠微服务架构的重要组件之一。

### 2、spring cloud的核心组件有哪些以及作用

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\Java框架\SpringCloud\image\图片_QTt8HtVHBa.png)

**Eureka**：服务注册与发现
注册：每个服务都向Eureka登记自己提供服务的元数据，包括服务的ip地址、端口号、版本号、通信协议等。eureka将各个服务维护在了一个服务清单中（双层Map，第一层key是服务名，第二层key是实例名，value是服务地址加端口）。同时对服务维持心跳，剔除不可用的服务，eureka集群各节点相互注册每个实例中都有一样的服务清单。

发现：eureka注册的服务之间调用不需要指定服务地址，而是通过服务名向注册中心咨询，并获取所有服务实例清单(缓存到本地)，然后实现服务的请求访问。

**Ribbon**：服务间发起请求的时候，基于Ribbon做负载均衡，从⼀个服务的多台机器中选择⼀台 （被调用方的服务地址有多个），Ribbon也是通过发起http请求，来进行的调用，只不过是通过调用服务名的地址来实现的。虽然说Ribbon不用去具体请求服务实例的ip地址或域名了，但是每调用一个接口都还要手动去发起Http请求。

**Hystrix**：发起请求是通过Hystrix的线程池来⾛的，不同的服务⾛不同的线程池，实现了不同服务调⽤的隔离，通过统计接口超时次数返回默认值，实现服务熔断和降级。

**Zuul**：如果前端、移动端要调⽤后端系统，统⼀从Zuul⽹关进⼊，由Zuul⽹关转发请求给对应的服务，通过与Eureka进行整合，将自身注册为Eureka下的应用，从Eureka下获取所有服务的实例，来进行服务的路由。Zuul还提供了一套过滤器机制，开发者可以自己指定哪些规则的请求需要执行校验逻辑，只有通过校验逻辑的请求才会被路由到具体服务实例上，否则返回错误提示。

**SpringCloud Config:** 提供服务器端和客户端。服务器存储后端的默认实现使用git，因此它轻松支持标签版本的配置环境，以及可以访问用于管理内容的各种工具。这个还是静态的，需要得配合Spring Cloud Bus实现动态的配置更新。

### 3、spring 如何注册cloud服务？

在Spring框架中使用Spring Cloud服务，需要进行以下步骤来注册和启用Spring Cloud组件：

1.  添加依赖：在项目的构建配置文件（如pom.xml）中添加所需的Spring Cloud依赖。例如，可以添加`spring-cloud-starter-netflix-eureka-client`依赖来使用Eureka服务注册与发现组件。
2.  配置文件：在应用程序的配置文件（如application.properties或application.yml）中配置Spring Cloud服务的相关属性。具体的配置内容取决于所使用的Spring Cloud组件。例如，使用Eureka服务注册与发现时，需要指定Eureka服务器的地址和端口等信息。
3.  注解标记：在Spring Boot应用程序的主类上添加相应的注解来启用Spring Cloud服务。具体的注解取决于所使用的Spring Cloud组件。例如，使用Eureka服务注册与发现时，可以在主类上添加`@EnableEurekaClient`注解。
4.  运行环境：确保应用程序运行的环境中包含了所需的Spring Cloud组件的运行实例。例如，如果使用Eureka服务注册与发现，需要确保Eureka服务器正常运行。

下面是一个使用Eureka服务注册与发现的示例：

1 . 添加依赖：

```xml
<dependency>
    <groupId>org.springframework.cloud</groupId>
    <artifactId>spring-cloud-starter-netflix-eureka-client</artifactId>
</dependency>
```

2 . 配置文件（application.yml）：

```yaml
spring:
  application:
    name: my-service
eureka:
  client:
    service-url:
      defaultZone: http://localhost:8761/eureka/
```

3 . 主类上添加注解：

```java
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@SpringBootApplication
@EnableEurekaClient
public class MyServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(MyServiceApplication.class, args);
    }
}
```

通过以上步骤，你就可以在Spring应用程序中注册和启用Spring Cloud服务了。具体的步骤和配置内容可能会根据所使用的Spring Cloud组件而有所不同，你可以根据具体的需求和文档进行相应的配置和操作。

### 4、微服务优点是什么？

（1)每个服务都足够内聚，代码易于理解；

(2)提高开发效率，一项服务只做一件事；

(3)微服务可以由小团队单独开发；

(4)微服务是松耦合的，是有功能意义的服务；

(5)可以用不同的语言开发，面向接口编程；

(6)易于与第三方集成；

(7)微服务只是业务逻辑的代码，不会和HTML一起使用。CSS或其它界面组合；

(8)可灵活搭配，连接公共库和独立库。

### 5、微服务的缺点是什么？

（1)分布式系统的责任；

(2)多服务运维难度，随着服务的增加，运维压力也在增加；

(3)系统部署依赖；

(4)服务间通信成本；

(5)数据一致性；

(6)系统集成测试；(7)性能监控。

### 6、Spring Cloud Bus是什么?

Spring Cloud Bus是Spring Cloud框架中的一个组件，用于在分布式系统中实现消息总线功能。它建立在Spring Boot和Spring Cloud Stream之上，提供了一种方便的方式来在微服务架构中进行消息传递和事件广播。

Spring Cloud Bus的主要功能是通过消息代理将分布式系统中的各个微服务实例连接起来，使它们能够方便地进行消息的发送和接收。它使用轻量级的消息代理（如RabbitMQ或Kafka）作为中间件，实现了消息的广播和订阅机制。

使用Spring Cloud Bus，可以实现以下功能：

1.  配置中心的刷新：通过发送特定的消息，可以触发所有微服务实例重新加载配置信息，从而实现配置的动态更新。
2.  事件广播：可以将事件消息广播给所有微服务实例，用于实现系统内的事件驱动机制。
3.  监控和管理：可以通过消息传递的方式，实现对微服务实例的监控和管理，例如获取实例的健康状态、查看日志等。

Spring Cloud Bus使用了发布-订阅模式，其中一个微服务实例作为消息的生产者，将消息发送到消息代理，而其他微服务实例作为消息的消费者，订阅感兴趣的消息并进行相应的处理。通过这种方式，可以实现微服务之间的解耦和灵活的消息传递。

需要注意的是，Spring Cloud Bus并不是用于高频率的数据传输或大规模的消息通信，而是用于在分布式系统中进行配置更新、事件广播和管理操作。对于更复杂的消息通信需求，可以结合使用Spring Cloud Stream等组件来实现。

总之，Spring Cloud Bus提供了一种简单而强大的方式来实现分布式系统中的消息总线功能，实现了微服务之间的解耦和灵活的消息传递。它是构建基于Spring Cloud的分布式系统的重要工具之一。

### 7、什么是服务熔断？什么是服务降级？

**1、概念不同：**

服务熔断：其实很好理解，就是一个断开的过程。

下游的服务因为某种原因突然变得不可用或响应过慢，上游服务为了保证自己整体服务的可用性，不再继续调用目标服务，直接返回，快速释放资源。如果目标服务情况好转则恢复调用。

服务降级：降低级别的意思，它是指程序在出现问题时，仍能保证有限功能可用的一种机制。

因此：对于降级是一种退而求其次的选择，而熔断却是整体不可用。

**2、触发原因不太一样**：

服务熔断一般是某个服务（下游服务）故障引起，而服务降级一般是从整体负荷考虑。

**3、管理层次不太一样：**

服务熔断是一个框架层次的处理（每个服务都要考虑，无业务层级之分），服务降级是业务层次的处理。（比如降级一般是从最非核心服务开始）

服务熔断是服务降级的一种特殊情况，他是防止服务雪崩而采取的措施。系统发生异常或者延迟或者流量太大，都会触发该服务的服务熔断措施，链路熔断，返回兜底方法。这是对局部的一种保险措施。

服务降级是对系统整体资源的合理分配。区分核心服务和非核心服务。对某个服务的访问延迟时间、异常等情况做出预估并给出兜底方法。这是一种全局性的考量，对系统整体负荷进行管理。

其实一句话： 降级是一种设计思想，在Java层面就是一个接口，而熔断是降级的不同实现方式，在Java层面就是这个接口的一个实现类。

**4、熔断和降级的关系**

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\Java框架\SpringCloud\image\图片_Ra3eTutVdS.png)

### 8、负载均衡的意义是什么？

负载均衡（Load Balancing）是指将网络或计算资源分配给多个服务器或设备，以达到提高系统性能、可扩展性和可靠性的目的。它在分布式系统中起到重要的作用，具有以下几个重要的意义：

1.  提高系统性能：负载均衡将请求均匀地分配给多个服务器，避免了单个服务器过载的情况。通过合理地分配负载，可以充分利用系统的资源，提高系统的吞吐量和响应速度。
2.  实现高可用性：通过将请求分发到多个服务器，即使其中某个服务器发生故障或不可用，仍然可以继续提供服务。负载均衡器能够检测到故障服务器，并将请求转发到其他正常工作的服务器，从而实现系统的高可用性和容错性。
3.  支持系统扩展：随着用户量和业务需求的增加，单个服务器可能无法满足系统的需求。负载均衡器可以根据实际情况动态地添加或删除服务器，实现系统的水平扩展。通过增加服务器数量，可以提高系统的处理能力和并发性能。
4.  优化资源利用：负载均衡器可以根据服务器的负载情况智能地分配请求，使每个服务器的负载相对均衡。这样可以避免某些服务器过载而其他服务器处于空闲状态的情况，最大限度地提高资源的利用率。
5.  简化系统管理：通过使用负载均衡器，可以将多个服务器组织成一个逻辑集群，对外提供统一的入口。这样可以简化系统的管理和维护工作，减少对客户端的影响，提高系统的可维护性和可管理性。

总之，负载均衡在分布式系统中具有重要的意义。它能够提高系统性能、可用性和可扩展性，优化资源利用，简化系统管理。通过合理地分配负载，负载均衡器能够实现高效、稳定和可靠的系统运行。

### 9、SpringBoot和SpringCloud有什么联系和区别？

Spring Boot和Spring Cloud是两个相互关联但又有不同重点的项目。

1.  Spring Boot（Spring框架）：Spring Boot是一个用于简化和加速Spring应用程序开发的框架。它提供了一种约定优于配置的方式，通过自动配置和默认值，可以快速搭建和部署独立的、可执行的Spring应用程序。Spring Boot使得开发者可以更专注于业务逻辑的实现，而无需手动配置复杂的Spring配置文件。
2.  Spring Cloud：Spring Cloud是一个用于构建分布式系统的工具集合，它基于Spring Boot提供了一系列的开箱即用的分布式系统模块和服务。Spring Cloud包含了多个组件，如服务注册与发现（Eureka、Consul）、服务调用（Feign、Ribbon）、断路器（Hystrix）、网关（Zuul、Gateway）、配置中心（Config）等，这些组件提供了分布式系统开发中常用的功能和解决方案。

联系和区别：

-   联系：Spring Boot是Spring框架的一部分，它为Spring应用程序提供了快速开发的能力，而Spring Cloud是构建分布式系统的工具集合，基于Spring Boot提供了一系列分布式系统模块和服务。
-   区别：Spring Boot主要关注于简化和加速单个Spring应用程序的开发，提供了自动配置、快速启动等特性。而Spring Cloud主要关注于构建分布式系统，提供了服务注册与发现、服务调用、负载均衡、断路器等组件，用于处理分布式系统中的各种挑战。

综上所述，Spring Boot和Spring Cloud是相互关联的，Spring Boot为Spring应用程序提供了快速开发的能力，而Spring Cloud则在此基础上提供了构建分布式系统的工具和解决方案。使用Spring Boot可以快速搭建单个Spring应用程序，而使用Spring Cloud可以在分布式系统中构建和管理多个相互协作的微服务。





#                                            JUC

## 什么是线程池，线程池有哪些？

线程池就是事先将多个线程对象放到一个容器中，当使用的时候就不用 new 线程而是直接去池中拿线程即可，节省了开辟子线程的时间，提高的代码执行效率

在 JDK 的 java.util.concurrent.Executors 中提供了生成多种线程池的静态方法。

ExecutorService newCachedThreadPool = Executors.newCachedThreadPool();

ExecutorService newFixedThreadPool = Executors.newFixedThreadPool(4);

ScheduledExecutorService newScheduledThreadPool = Executors.newScheduledThreadPool(4);

ExecutorService newSingleThreadExecutor = Executors.newSingleThreadExecutor();

然后调用他们的 execute 方法即可。

### （**1**）**newCachedThreadPool**

创建一个可缓存线程池，如果线程池长度超过处理需要，可灵活回收空闲线程，若无可回收，则新建线程。这种类型的线程池特点是：

工作线程的创建数量几乎没有限制(其实也有限制的,数目为Interger. MAX\_VALUE), 这样可灵活的往线程池中添加线程。

如果长时间没有往线程池中提交任务，即如果工作线程空闲了指定的时间(默认为1分钟)，则该工作线程将自动终止。终止后，如果你又提交了新的任务，则线程池重新创建一个工作线程。

在使用CachedThreadPool时，一定要注意控制任务的数量，否则，由于大量线程同时运行，很有会造成系统瘫痪。

### （**2**）newFixedThreadPool

创建一个指定工作线程数量的线程池。每当提交一个任务就创建一个工作线程，如果工作线程数量达到线程池初始的最大数，则将提交的任务存入到池队列中。FixedThreadPool是一个典型且优秀的线程池，它具有线程池提高程序效率和节省创建线程时所耗的开销的优点。但是，在线程池空闲时，即线程池中没有可运行任务时，它不会释放工作线程，还会占用一定的系统资源。

### （**3**）**newSingleThreadExecutor**

创建一个单线程化的Executor，即只创建唯一的工作者线程来执行任务，它只会用唯一的工作线程来执行任务，保证所有任务按照指定顺序(FIFO, LIFO, 优先级)执行。如果这个线程异常结束，会有另一个取代它，保证顺序执行。单工作线程最大的特点是可保证顺序地执行各个任务，并且在任意给定的时间不会有多个线程是活动的。

### （**4**）**newScheduleThreadPool**

创建一个定长的线程池，而且支持定时的以及周期性的任务执行。例如延迟3秒执行。

这4种线程池底层 全部是ThreadPoolExecutor对象的实现，阿里规范手册中规定线程池采用ThreadPoolExecutor自定义的，实际开发也是。

## ThreadPoolExecutor对象有哪些参数？都有什么作用？怎么设定核心线程数和最大线程数？拒绝策略有哪些？ \[重点]

### 参数与作用：共7个参数

**corePoolSize**

核心线程数，在ThreadPoolExecutor中有一个与它相关的配置：allowCoreThreadTimeOut（默认为false），当allowCoreThreadTimeOut为false时，核心线程会一直存活，哪怕是一直空闲着。而当allowCoreThreadTimeOut为true时核心线程空闲时间超过keepAliveTime时会被回收。

**maximumPoolSize**

最大线程数，线程池能容纳的最大线程数，当线程池中的线程达到最大时，此时添加任务将会采用拒绝策略，默认的拒绝策略是抛出一个运行时错误（RejectedExecutionException）。值得一提的是，当初始化时用的工作队列为LinkedBlockingDeque时，这个值将无效。

**keepAliveTime**

存活时间，当非核心空闲超过这个时间将被回收，同时空闲核心线程是否回收受allowCoreThreadTimeOut影响。

**unit**

keepAliveTime的单位。

**workQueue**

任务队列，常用有三种队列，即SynchronousQueue,LinkedBlockingDeque（无界队列）,ArrayBlockingQueue（有界队列）。

**threadFactory**

线程工厂，ThreadFactory是一个接口，用来创建worker。通过线程工厂可以对线程的一些属性进行定制。默认直接新建线程。

**RejectedExecutionHandler**

也是一个接口，只有一个方法，当线程池中的资源已经全部使用，添加新线程被拒绝时，会调用RejectedExecutionHandler的rejectedExecution法。

默认是抛出一个运行时异常。

### **线程池大小设置：**

1.  需要分析线程池执行的任务的特性： CPU 密集型还是 IO 密集型
2.  每个任务执行的平均时长大概是多少，这个任务的执行时长可能还跟任务处理逻辑是否涉及到网络传输以及底层系统资源依赖有关系

如果是 CPU 密集型，主要是执行计算任务，响应时间很快，cpu 一直在运行，这种任务 cpu的利用率很高，那么线程数的配置应该根据 CPU 核心数来决定，CPU 核心数=最大同时执行线程数，加入 CPU 核心数为 4，那么服务器最多能同时执行 4 个线程。过多的线程会导致上下文切换反而使得效率降低。那线程池的最大线程数可以配置为 cpu 核心数+1 如果是 IO 密集型，主要是进行 IO 操作，执行 IO 操作的时间较长，这是 cpu 出于空闲状态，导致 cpu 的利用率不高，这种情况下可以增加线程池的大小。这种情况下可以结合线程的等待时长来做判断，等待时间越高，那么线程数也相对越多。一般可以配置 cpu 核心数的 2 倍。

一个公式：线程池设定最佳线程数目 = （（线程池设定的线程等待时间+线程 CPU 时间）/ &#x20;
线程 CPU 时间 ）\* CPU 数目

这个公式的线程 cpu 时间是预估的程序单个线程在 cpu 上运行的时间（通常使用 loadrunner测试大量运行次数求出平均值）

### **拒绝策略：**

1、**AbortPolicy**

直接抛出异常，默认策略；

2、**CallerRunsPolicy**

用调用者所在的线程来执行任务；

3、**DiscardOldestPolicy**

丢弃阻塞队列中靠最前的任务，并执行当前任务；

4、**DiscardPolicy**

直接丢弃任务； &#x20;
当然也可以根据应用场景实现 RejectedExecutionHandler 接口，自定义饱和策略，如记录日志或持久化存储不能处理的任务

## 常见线程安全的并发容器有哪些？

CopyOnWriteArrayList、CopyOnWriteArraySet、ConcurrentHashMap。

CopyOnWriteArrayList、CopyOnWriteArraySet采用写时复制实现线程安全

ConcurrentHashMap采用分段锁的方式实现线程安全

## Atomic原子类了解多少？原理是什么？

ava中的java.util.concurrent.atomic包提供了一组原子类，用于在多线程环境中执行原子操作，而无需使用显式的锁。这些原子类使用特殊的CPU指令来确保操作的原子性，从而避免了使用锁带来的性能开销。

这些原子类的实现依赖于底层硬件架构提供的原子操作指令。通常，这些指令在现代处理器上是硬件级别的支持，确保对内存的读写是原子的。这使得在不使用锁的情况下，可以在多线程环境中执行某些操作，而不会导致竞态条件（race conditions）。

**以下是一些常见的java.util.concurrent.atomic包中的原子类以及它们的一些实现原理：**

AtomicInteger, AtomicLong, AtomicReference:

这些类使用compareAndSet（CAS）操作实现原子性。CAS是一种乐观锁定机制，它尝试原子地将一个值更新为新值，但只有在当前值等于预期值时才成功。否则，它会重新尝试。
CAS操作是由处理器提供的原子性操作指令支持的。
AtomicBoolean:

AtomicBoolean类使用compareAndSet实现。
compareAndSet的实现通常依赖于底层处理器的CAS指令。
AtomicIntegerArray, AtomicLongArray, AtomicReferenceArray:

这些类提供了对数组元素的原子性访问。
它们也使用CAS操作，但应用于数组的特定位置。
AtomicIntegerFieldUpdater, AtomicLongFieldUpdater, AtomicReferenceFieldUpdater:

这些类提供了对对象字段的原子性更新。
它们使用了反射和CAS操作来实现。
总体来说，原子类的实现依赖于底层硬件提供的原子性操作指令，这通常是现代处理器架构的一部分。这使得原子类能够在无锁的情况下执行一些基本的原子操作，提高了多线程环境中的性能。在高并发的情况下，原子类是一种有用的工具，能够提供线程安全的操作，而无需显式地使用锁。

## synchronized底层实现是什么？lock底层是什么？有什么区别？

### **Synchronized原理：**

方法级的同步是隐式，即无需通过字节码指令来控制的，它实现在方法调用和返回操作之中。JVM可以从方法常量池中的方法表结构(method\_info Structure) 中的 ACC\_SYNCHRONIZED 访问标志区分一个方法是否同步方法。当方法调用时，调用指令将会 检查方法的 ACC\_SYNCHRONIZED 访问标志是否被设置，如果设置了，执行线程将先持有monitor（虚拟机规范中用的是管程一词）， 然后再执行方法，最后再方法完成(无论是正常完成还是非正常完成)时释放monitor。

代码块的同步是利用monitorenter和monitorexit这两个字节码指令。它们分别位于同步代码块的开始和结束位置。当jvm执行到monitorenter指令时，当前线程试图获取monitor对象的所有权，如果未加锁或者已经被当前线程所持有，就把锁的计数器+1；当执行monitorexit指令时，锁计数器-1；当锁计数器为0时，该锁就被释放了。如果获取monitor对象失败，该线程则会进入阻塞状态，直到其他线程释放锁。

### **Lock原理：**

· Lock的存储结构：一个int类型状态值（用于锁的状态变更），一个双向链表（用于存储等待中的线程）

· Lock获取锁的过程：本质上是通过CAS来获取状态值修改，如果当场没获取到，会将该线程放在线程等待链表中。

· Lock释放锁的过程：修改状态值，调整等待链表。

· Lock大量使用CAS+自旋。因此根据CAS特性，lock建议使用在低锁冲突的情况下。

### **Lock与synchronized的区别**

1.  Lock的加锁和解锁都是由java代码配合native方法（调用操作系统的相关方法）实现的，而synchronize的加锁和解锁的过程是由JVM管理的
2.  当一个线程使用synchronize获取锁时，若锁被其他线程占用着，那么当前只能被阻塞，直到成功获取锁。而Lock则提供超时锁和可中断等更加灵活的方式，在未能获取锁的 条件下提供一种退出的机制。
3.  一个锁内部可以有多个Condition实例，即有多路条件队列，而synchronize只有一路条件队列；同样Condition也提供灵活的阻塞方式，在未获得通知之前可以通过中断线程以 及设置等待时限等方式退出条件队列。
4.  synchronize对线程的同步仅提供独占模式，而Lock即可以提供独占模式，也可以提供共享模式

| synchronized                             | Lock                            |
| ---------------------------------------- | ------------------------------- |
| 关键字                                   | 接口/类                         |
| 自动加锁和释放锁                         | 需要手动调用unlock() 方法释放锁 |
| JVM层面的锁                              | API层面的锁                     |
| 非公平锁                                 | 可以选择公平或者非公平锁        |
| 锁是一个对象，并且锁的信息保存在了对象中 | 代码中通过int类型的state标识    |
| 有一个锁升级的过程                       | 无                              |





#                                         数据库

## MySQL

### 1、对MySQL数据库去重的关键字是什么？

在MySQL数据库中，可以使用`DISTINCT`关键字来进行去重操作。`DISTINCT`关键字用于查询语句的`SELECT`子句中，用于返回唯一的结果集，去除重复的行。

例如，以下是使用`DISTINCT`关键字进行去重的示例：

`SELECT DISTINCT column1, column2 FROM table_name;`&#x20;

上述示例中，`column1`和`column2`是要查询的列名，`table_name`是要查询的表名。查询结果将返回去重后的唯一行。

需要注意的是，`DISTINCT`关键字会对查询结果的所有列进行去重。如果只想对部分列进行去重，可以指定相应的列名。

### 2、MySQL多表连接有哪些方式？怎么用的？这些连接都有什么区别？

连接方式：左连接、右连接、内连接

使用方法：

左连接：select \* from A LEFT JOIN B on [A.id=B.id](http://A.id=B.id "A.id=B.id");

右连接：select \* from A RIGHT JOIN B on [A.id=B.id](http://A.id=B.id "A.id=B.id");

内连接：select \* from A inner join B on a.xx=b.xx;（其中inner可以省略）

区别：

Inner join 内连接，在两张表进行连接查询时，只保留两张表中完全匹配的结果集

left join 在两张表进行连接查询时，会返回左表所有的行，即使在右表中没有匹配的记录。

right join 在两张表进行连接查询时，会返回右表所有的行，即使在左表中没有匹配的记录。

### 3、索引的基本原理

索引用来快速地寻找那些具有特定值的记录。如果没有索引，一般来说执行查询时遍历整张表。

索引的原理：就是把无序的数据变成有序的查询

1.  把创建了索引的列的内容进行排序。
2.  对排序结果生成倒排表。
3.  在倒排表内容上拼上数据地址链。
4.  在查询的时候，先拿到倒排表内容，再取出数据地址链，从而拿到具体数据

### 4、说一下索引的优势和劣势？

优势：

唯一索引可以保证数据库表中每一行数据的唯一性，索引可以加快数据查询速度，减少查询时间

劣势：

创建索引和维护索引要耗费时间，索引需要占物理空间，除了数据表占用数据空间之外，每一个索引还要占用一定的物理空间，给表中的数据进行增、删、改的时候，索引也要动态的维护。

### 5、MySQL聚簇和非聚簇索引的区别

都是B+树的数据结构

聚簇索引：将数据存储与索引放到了一块、并且是按照一定的顺序组织的，找到索引也就找到了数
据，数据的物理存放顺序与索引顺序是一致的，即：只要索引是相邻的，那么对应的数据一定也是
相邻地存放在磁盘上的。
非聚簇索引：叶子节点不存储数据、存储的是数据行地址，也就是说根据索引查找到数据行的位置
再去磁盘查找数据，这个就有点类似一本书的目录，比如我们要找第三章第一节，那我们先在这个
目录里面找，找到对应的页码后再去对应的页码看文章。

优势：
1、查询通过聚簇索引可以直接获取数据，相比非聚簇索引需要第二次查询（非覆盖索引的情况下）效率要高
2、聚簇索引对于范围查询的效率很高，因为其数据是按照大小排列的。
3、聚簇索引适合用在排序的场合，非聚簇索引不适合。

劣势：
1、维护索引很昂贵，特别是插入新行或者主键被更新导致要分页(page split)的时候。建议在大量插入新行后，选在负载较低的时间段，通过OPTIMIZE TABLE优化表，因为必须被移动的行数据可能造成碎片。使用独享表空间可以弱化碎片。
2、表因为使用UUId（随机ID）作为主键，使数据存储稀疏，这就会出现聚簇索引有可能有比全表扫面更慢，所以建议使用int的auto\_increment作为主键
3、如果主键比较大的话，那辅助索引将会变的更大，因为辅助索引的叶子存储的是主键值；过长的主键值，会导致非叶子节点占用占用更多的物理空间。

InnoDB中一定有主键，主键一定是聚簇索引，不手动设置、则会使用unique索引，没有unique索引，则会使用数据库内部的一个行的隐藏id来当作主键索引。在聚簇索引之上创建的索引称之为辅助索引，辅助索引访问数据总是需要二次查找，非聚簇索引都是辅助索引，像复合索引、前缀索引、唯一索引，辅助索引叶子节点存储的不再是行的物理位置，而是主键值.

MyISM使用的是非聚簇索引，没有聚簇索引，非聚簇索引的两棵B+树看上去没什么不同，节点的结构完全一致只是存储的内容不同而已，主键索引B+树的节点存储了主键，辅助键索引B+树存储了辅助键。表数据存储在独立的地方，这两颗B+树的叶子节点都使用一个地址指向真正的表数据，对于表数据来说，这两个键没有任何差别。由于索引树是独立的，通过辅助键检索无需访问主键的索引树。

如果涉及到大数据量的排序、全表扫描、count之类的操作的话，还是MyISAM占优势些，因为索引所占空间小，这些操作是需要在内存中完成的。

### 6、MySQL索引的数据结构，各自优劣

索引的数据结构和具体存储引擎的实现有关，在MySQL中使用较多的索引有Hash索引，B+树索引等，InnoDB存储引擎的默认索引实现为：B+树索引。对于哈希索引来说，底层的数据结构就是哈希表，因此在绝大多数需求为单条记录查询的时候，可以选择哈希索引，查询性能最快；其余大部分场景，建议选择BTree索引。

B+树：
B+树是一个平衡的多叉树，从根节点到每个叶子节点的高度差值不超过1，而且同层级的节点间有指针相互链接。在B+树上的常规检索，从根节点到叶子节点的搜索效率基本相当，不会出现大幅波动，而且基于索引的顺序扫描时，也可以利用双向指针快速左右移动，效率非常高。因此，B+树索引被广泛应用于数据库、文件系统等场景。

哈希索引：
哈希索引就是采用一定的哈希算法，把键值换算成新的哈希值，检索时不需要类似B+树那样从根节点到叶子节点逐级查找，只需一次哈希算法即可立刻定位到相应的位置，速度非常快。

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\数据库\MySQL\image\图片_JS3nXXcHhV.png)

如果是等值查询，那么哈希索引明显有绝对优势，因为只需要经过一次算法即可找到相应的键值；前提是键值都是唯一的。如果键值不是唯一的，就需要先找到该键所在位置，然后再根据链表往后扫描，直到找到相应的数据；

如果是范围查询检索，这时候哈希索引就毫无用武之地了，因为原先是有序的键值，经过哈希算法后，有可能变成不连续的了，就没办法再利用索引完成范围查询检索；

哈希索引也没办法利用索引完成排序，以及like ‘xxx%’ 这样的部分模糊查询（这种部分模糊查询，其实本质上也是范围查询）；

哈希索引也不支持多列联合索引的最左匹配规则；

B+树索引的关键字检索效率比较平均，不像B树那样波动幅度大，在有大量重复键值情况下，哈希索引的效率也是极低的，因为存在哈希碰撞问题。

### 7、MySQL索引的设计原则

查询更快、占用空间更小

1.  适合索引的列是出现在where子句中的列，或者连接子句中指定的列。
2.  基数较小的表，索引效果较差，没有必要在此列建立索引
3.  使用短索引，如果对长字符串列进行索引，应该指定一个前缀长度，这样能够节省大量索引空间，如果搜索词超过索引前缀长度，则使用索引排除不匹配的行，然后检查其余行是否可能匹配
4.  不要过度索引。索引需要额外的磁盘空间，并降低写操作的性能。在修改表内容的时候，索引会进行更新甚至重构，索引列越多，这个时间就会越长。所以只保持需要的索引有利于查询即可。
5.  定义有外键的数据列一定要建立索引。
6.  更新频繁字段不适合创建索引。
7.  若是不能有效区分数据的列不适合做索引列(如性别，男女未知，最多也就三种，区分度实在太低)
8.  对于那些查询中很少涉及的列，重复值比较多的列不要建立索引。
9.  对于定义为text、image和bit的数据类型的列不要建立索引。

### 8、MySQL中B+树和B树的区别

1、**非叶子节点数据不同**：

-   B+树的非叶子节点的数据都在叶子节点中出现过，也就是叶子节点中的数据都在非叶子节点冗余一份。B树中非叶子节点中元素不会冗余。
-   B+树非叶子节点只存放指针，不存放数据，B树所有节点（叶子节点）都存放数据。

2、**叶子节点数据不同**：B+树叶子节点存放数据，B树所有节点（非叶子节）点存放数据。数据遍布整个树结构。

3、**时间复杂度不同**：由于B+树的数据都存在叶子节点，因此B+树的时间复杂度固定为o(log n)，而B树的数据分布在每个节点中，因此时间复杂度不固定，最好为o(1).

4、**叶子节点连接不同**：B+树的叶子节点通过有序的双向链表相连，B树叶子节点不相连。

5、**区间查询效率不同**：因为第4点的原因，所以B+树去范围查询效率更快，而B树范围查询比较慢。

因此，存在大量范围查询的场景，适合使用B+树

而对大量单个key查询的场景，可以考虑B树

### 9、MySQL中的锁类型有哪些？

基于锁的属性分类：共享锁、排他锁。

基于锁的粒度分类：行级锁(INNODB)、表级锁(INNODB、MYISAM)、页级锁(BDB引擎 )、记录锁、间隙锁、临键锁。

**共享锁(Share Lock)**：

共享锁又称读锁，简称S锁；当一个事务为数据加上读锁之后，其他事务只能对该数据加读锁，而不能对数据加写锁，直到所有的读锁释放之后其他事务才能对其进行加持写锁。共享锁的特性主要是为了支持并发的读取数据，读取数据的时候不支持修改，避免出现重复读的问题。

**排他锁（Exclusive Lock）**:

排他锁又称写锁，简称X锁；当一个事务为数据加上写锁时，其他请求将不能再为数据加任何锁，直到该锁释放之后，其他事务才能对数据进行加锁。排他锁的目的是在数据修改时候，不允许其他人同时修改，也不允许其他人读取。避免了出现脏数据和脏读的问题.

**表锁**：

表锁是指上锁的时候锁住的是整个表，当下一个事务访问该表的时候，必须等前一个事务释放了锁才能进行对表进行访问；
特点： 粒度大，加锁简单，容易冲突

**行锁：**

行锁是指上锁的时候锁住的是表的某一行或多行记录，其他事务访问同一张表时，只有被锁住的记录不能访问，其他的记录可正常访问；
特点：粒度小，加锁比表锁麻烦，不容易冲突，相比表锁支持的并发要高。

**记录锁(Record Lock)**

记录锁也属于行锁中的一种，只不过记录锁的范围只是表中的某一条记录，记录锁是说事务在加锁后锁住的只是表的某一条记录。
精准条件命中，并且命中的条件字段是唯一索引
加了记录锁之后数据可以避免数据在查询的时候被修改的重复读问题，也避免了在修改的事务未提交前被其他事务读取的脏读问题。

**页锁**：

页级锁是MySQL中锁定粒度介于行级锁和表级锁中间的一种锁。表级锁速度快，但冲突多，行级冲突少，但速度慢。所以取了折衷的页级，一次锁定相邻的一组记录。
特点：开销和加锁时间界于表锁和行锁之间；会出现死锁；锁定粒度界于表锁和行锁之间，并发度一般。

**间隙锁(Gap Lock**）

属于行锁中的一种，间隙锁是在事务加锁后其锁住的是表记录的某一个区间，当表的相邻ID之间出现空隙则会形成一个区间，遵循左开右闭原则。
间隙锁只会出现在REPEATABLE\_READ（可重复读)的事务级别中。
触发条件：防止幻读问题，事务并发的时候，如果没有间隙锁，就会发生如下图的问题，在同一个事务里，A事务的两次查询出的结果会不一样。
比如表里面的数据ID 为 1,4,5,7,10 ,那么会形成以下几个间隙区间，-n-1区间，1-4区间，5-7区间，7-10区间，10-n区间 （-n代表负无穷大，n代表正无穷大）。

**临建锁(Next-Key Lock)：**

也属于行锁的一种，并且它是INNODB的行锁默认算法，总结来说它就是记录锁和间隙锁的组合，临键锁会把查询出来的记录锁住，同时也会把该范围查询内的所有间隙空间也会锁住。
触发条件：范围查询并命中，查询命中了索引。
结合记录锁和间隙锁的特性，临键锁避免了在范围查询时出现脏读、重复读、幻读问题。加了临键锁之后，在范围区间内数据不允许被修改和插入。

### 10、MySQL什么是死锁？怎么解决？

死锁是指两个或多个事务在同一资源上相互占用，并请求锁定对方的资源，从而导致恶性循环的现象。

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\数据库\MySQL\image\image_7bRSowfRxq.png)

有四个必要条件：互斥条件，请求和保持条件，环路等待条件，不剥夺条件。

解决死锁思路，一般就是切断环路，尽量避免并发形成环路。如果不同程序会并发存取多个表，尽量约定以相同的顺序访问表，可以大大降低死锁机会；在同一个事务中，尽可能做到一次锁定所需要的所有资源，减少死锁产生概率；对于非常容易产生死锁的业务部分，可以尝试使用升级锁定颗粒度，通过表级锁定来减少死锁产生的概率；如果业务处理不好可以用分布式事务锁或者使用乐观锁；死锁与索引密不可分，解决索引问题，需要合理优化索引。

### 11、MySQL的约束有哪些？

NOT NULL: 约束字段的内容一定不能为NULL。

UNIQUE: 约束字段唯一性，一个表允许有多个Unique约束。

PRIMARY KEY: 约束字段唯一，不可重复，一个表只允许存在一个。

FOREIGN KEY: 用于预防破坏表之间连接的动作，也能防止非法数据插入外键。用来让两张表的数据之间建立连接，从而保证数据的一致性和完整性。

CHECK: 用于控制字段的值范围。保证字段值满足某一个条件。

DEFAULT：保存数据时，如果未指定该字段的值，则采用默认值

### 12、关心过业务系统里面的sql耗时吗？统计过慢查询吗？对慢查询都怎么优化过？

在业务系统中，除了使用主键进行的查询，其他的都会在测试库上测试其耗时，慢查询的统计主要由运维在做，会定期将业务中的慢查询反馈给我们。

慢查询的优化首先要搞明白慢的原因是什么？

**1、是查询条件没有命中索引？**

**2、是load了不需要的数据列？**

**3、还是数据量太大？**

所以优化也是针对这三个方向来的，
1、首先分析语句，看看是否load了额外的数据，可能是查询了多余的行并且抛弃掉了，可能是加载了许多结果中并不需要的列，对语句进行分析以及重写。

2、分析语句的执行计划，然后获得其使用索引的情况，之后修改语句或者修改索引，使得语句可以尽可能的命中索引。

3、如果对语句的优化已经无法进行，可以考虑表中的数据量是否太大，如果是的话可以进行横向或者纵向的分表。

### 13、MySQL事务的基本特性和隔离级别

事务基本特性ACID分别是：

**原子性**:指的是一个事务中的操作要么全部成功，要么全部失败。

**一致性:** 指的是数据库总是从一个一致性的状态转换到另外一个一致性的状态。比如A转账给B100块钱，假设A只有90块，支付之前我们数据库里的数据都是符合约束的,但是如果事务执行成功了,我们的数据库数据就破坏约束了,因此事务不能成功,这里我们说事务提供了一致性的保证。

**隔离性**:指的是一个事务的修改在最终提交前，对其他事务是不可见的。

**持久性**：指的是一旦事务提交，所做的修改就会永久保存到数据库中。

隔离性有4个隔离级别，分别是：

**read uncommit** 读未提交，可能会读到其他事务未提交的数据，也叫做脏读。
用户本来应该读取到id=1的用户age应该是10，结果读取到了其他事务还没有提交的事务，结果读取结果age=20，这就是脏读。

\*\*read commit \*\*读已提交，两次读取结果不一致，叫做不可重复读。
不可重复读解决了脏读的问题，他只会读取已经提交的事务。
用户开启事务读取id=1用户，查询到age=10，再次读取发现结果=20，在同一个事务里同一个查询读取到不同的结果叫做不可重复读。

\*\*repeatable read \*\*可重复复读，这是mysql的默认级别，就是每次读取结果都一样，但是有可能产生幻读。

\*\*serializable \*\*串行，一般是不会使用的，他会给每一行读取的数据加锁，会导致大量超时和锁竞争
的问题。

**脏读**(Drity Read)：某个事务已更新一份数据，另一个事务在此时读取了同一份数据，由于某些原因，前一个RollBack了操作，则后一个事务所读取的数据就会是不正确的。
**不可重复读**(Non-repeatable read):在一个事务的两次查询之中数据不一致，这可能是两次查询过程中间插入了一个事务更新的原有的数据。
**幻读**(Phantom Read):在一个事务的两次查询中数据笔数不一致，例如有一个事务查询了几列(Row)数据，而另一个事务却在此时插入了新的几列数据，先前的事务在接下来的查询中，就会发现有几列数据是它先前所没有的。

### 14、MySQL中ACID靠什么保证的？

**A（原子性**）由undo log日志保证，它记录了需要回滚的日志信息，事务回滚时撤销已经执行成功的sql。
**C（一致性**）由其他三大特性保证、程序代码要保证业务上的一致性。
**I（隔离性**）由MVCC来保证。
**D（持久性）** 由内存+redo log来保证，mysql修改数据同时在内存和redo log记录这次操作。宕机的时候可以从redo log恢复redolog的刷盘会在系统空闲时进行。

### 15、MySQL中的MVCC是什么？

多版本并发控制：读取数据时通过一种类似快照的方式将数据保存下来，这样读锁就和写锁不冲突了，不同的事务会看到自己特定版本的数据，版本链.

MVCC只在 READ COMMITTED 和 REPEATABLE READ 两个隔离级别下工作。其他两个隔离级别和MVCC不兼容, 因为 READ UNCOMMITTED 总是读取最新的数据行, 而不是符合当前事务版本的数据行。而 SERIALIZABLE 则会对所有读取的行都加锁。

聚簇索引记录中有两个必要的隐藏列：
trx\_id：用来存储每次对某条聚簇索引记录进行修改的时候的事务id。

roll\_pointer：每次对哪条聚簇索引记录有修改的时候，都会把老版本写入undo日志中。这个
roll\_pointer就是存了一个指针，它指向这条聚簇索引记录的上一个版本的位置，通过它来获得上一个版本的记录信息。(注意插入操作的undo日志没有这个属性，因为它没有老版本)

已提交读和可重复读的区别就在于它们生成ReadView的策略不同。

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\数据库\MySQL\image\图片_DRf1QHYkSQ.png)

开始事务时创建ReadView，ReadView维护当前活动的事务id，即未提交的事务id，排序生成一个数组.

访问数据，获取数据中的事务id，对比ReadView：

如果在ReadView的左边（比ReadView都小），可以访问（在左边意味着该事务已经提交）

如果在ReadView的右边（比ReadView都大）或者就在ReadView中，不可以访问，获取roll\_pointer，取上一版本重新对比（在右边意味着，该事务在ReadView生成之后出现，在ReadView中意味着该事务还未提交）

已提交读隔离级别下的事务在每次查询的开始都会生成一个独立的ReadView,而可重复读隔离级别则在第一次读的时候生成一个ReadView，之后的读都复用之前的ReadView。

这就是Mysql的MVCC,通过版本链，实现多版本，可并发读-写，写-读。通过ReadView生成策略的不同实现不同的隔离级别

### 16、UNION和UNION ALL的区别？

先说结论，因为[UNION](https://so.csdn.net/so/search?q=UNION\&spm=1001.2101.3001.7020 "UNION") 操作会对结果去重且排序，所以从速度来说， UNION ALL会更胜一筹。建两张表，分别插入几条数据：

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\数据库\MySQL\image\image_Ud8auPETKZ.png)

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\数据库\MySQL\image\image_u4NPwgqBZh.png)

这两张表唯一的不同就是数据中，一个是“王五”，一个是“老六”。

**1.使用union all**

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\数据库\MySQL\image\image_OqMQYGx06D.png)

可以看出，union all 没有去重，查出了两个“张三”和“李四”；

**2.使用union**

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\数据库\MySQL\image\image_7zJdRv1HUX.png)

由此可见，“张三”和“李四”被去重了。 &#x20;
然后，我们再来看下两个SQL（也就是union和union all）的性能分析：

**3. 使用union all 性能分析**

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\数据库\MySQL\image\image_CLLJbdwA4F.png)

**4. 使用union性能分析**

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\数据库\MySQL\image\image_6z9QPEo2Dq.png)

**通过性能分析可得出，union比union all 多做了操作。由此得结论：**

1.union去重并排序，union all直接返回合并的结果，不去重也不排序； &#x20;
2.union all比union性能好；

### 17、主键使用自增ID还是UUID，为什么？

如果是单机的话，选择自增ID；如果是分布式系统，优先考虑UUID，但还是最好公司自己有一套分布式唯一ID生产方案。自增ID：数据存储空间小，查询效率高。但是如果数据量过大,会超出自增长的值范围，多库合并，也有可能出现问题。uuid：适合大量数据的插入和更新操作，但它是无序的，插入数据效率慢，占用空间大。

### 18、MySQL数据库cpu飙升的话，要怎么处理呢？

排查过程：

使用top命令观察，确定是mysqld导致还是其他原因。

如果是mysqld导致的，show processlist，查看session情况，确定是不是有消耗资源的sql在运行。

找出消耗高的 sql，看看执行计划是否准确， 索引是否缺失，数据量是否太大。

处理：

kill掉这些线程(同时观察cpu使用率是否下降)，

进行相应的调整(比如说加索引、改sql、改内存参数)

重新跑SQL。

其他情况：

也有可能是每个sql消耗资源并不多，但是突然之间，有大量的session 连进来导致cpu飙升，这种情况就需要跟应用一起来分析为何连接数会激增，再做出相应的调整，比如说限制连接数等。

### 19、什么是存储过程？有哪些优缺点？

存储过程，就是一些编译好了的SQL语句，这些SQL语句代码像一个方法实现一些功能（对单表或多表的增删改查），然后给这些代码块取一个名字，在用到这个功能的时候调用即可。

优点：

存储过程是一个预编译的代码块，执行效率比较高，存储过程在服务器端运行，减少客户端的压力，允许模块化程序设计，只需要创建一次过程，以后在程序中就可以调用该过程任意次，类似方法的复用，一个存储过程替代大量SQL语句 ，可以降低网络通信量，提高通信速率，可以一定程度上确保数据安全。

缺点：

调试麻烦，可移植性不灵活，存在重新编译问题

### 20、了解什么是表分区吗？表分区的好处有哪些？

表分区，是指根据一定规则，将数据库中的一张表分解成多个更小的容易管理的部分。从逻辑上看，只有一张表，但是底层却是由多个物理分区组成。

存储更多数据。分区表的数据可以分布在不同的物理设备上，从而高效地利用多个硬件设备。和单个磁盘或者文件系统相比，可以存储更多数据。

优化查询。在where语句中包含分区条件时，可以只扫描一个或多个分区表来提高查询效率；涉及sum和count语句时，也可以在多个分区上并行处理，最后汇总结果。

分区表更容易维护。例如：想批量删除大量数据可以清除整个分区。

避免某些特殊的瓶颈，例如InnoDB的单个索引的互斥访问。

### 21、MySQL主从同步原理

MySQL主从同步的过程：

MySQL的主从复制中主要有三个线程： master（binlog dump thread）、slave（I/O thread 、SQLthread） ，Master一条线程和Slave中的两条线程。

主节点 binlog，主从复制的基础是主库记录数据库的所有变更记录到 binlog。binlog 是数据库服
务器启动的那一刻起，保存所有修改数据库结构或内容的一个文件。

主节点 log dump 线程，当 binlog 有变动时，log dump 线程读取其内容并发送给从节点。

从节点 I/O线程接收 binlog 内容，并将其写入到 relay log 文件中。

从节点的SQL 线程读取 relay log 文件内容对数据更新进行重放，最终保证主从数据库的一致性。

注：主从节点使用 binglog 文件 + position 偏移量来定位主从同步的位置，从节点会保存其已接收到的偏移量，如果从节点发生宕机重启，则会自动从 position 的位置发起同步。

由于MySQL默认的复制方式是异步的，主库把日志发送给从库后不关心从库是否已经处理，这样会产生一个问题就是假设主库挂了，从库处理失败了，这时候从库升为主库后，日志就丢失了。由此产生两个概念。

**全同步复制**
主库写入binlog后强制同步日志到从库，所有的从库都执行完成后才返回给客户端，但是很显然这个方式的话性能会受到严重影响。

**半同步复制**
和全同步不同的是，半同步复制的逻辑是这样，从库写入日志成功后返回ACK确认给主库，主库收到至少一个从库的确认就认为写操作完成。

### 22、简述MyISAM和InnoDB的区别

**MyISAM：**
1、不支持事务，但是每次查询都是原子的；
2、支持表级锁，即每次操作是对整个表加锁；
3、存储表的总行数；
4、一个MYISAM表有三个文件：索引文件、表结构文件、数据文件；
5、采用非聚集索引，索引文件的数据域存储指向数据文件的指针。辅索引与主索引基本一致，但是辅索引不用保证唯一性。

**InnoDB**：
1、支持ACID的事务，支持事务的四种隔离级别；
2、支持行级锁及外键约束：因此可以支持写并发；
3、不存储总行数；
4、一个InnoDB引擎存储在一个文件空间（共享表空间，表大小不受操作系统控制，一个表可能分布在多个文件里），也有可能为多个（设置为独立表空，表大小受操作系统文件大小限制，一般为2G），受操作系统文件大小的限制；
5、主键索引采用聚集索引（索引的数据域存储数据文件本身），辅索引的数据域存储主键的值；因此从辅索引查找数据，需要先通过辅索引找到主键值，再访问主键索引树；索引最好使用自增主键，防止插入数据时，为维持B+树结构，文件的大调整。

### 23、简述MySQL中索引类型及对数据库的性能的影响

**普通索引**：允许被索引的数据列包含重复的值。
**唯一索引**：可以保证数据记录的唯一性。
**主键**：是一种特殊的唯一索引，在一张表中只能定义一个主键索引，主键用于唯一标识一条记录，使用关键字 PRIMARY KEY 来创建。
**联合索引**：索引可以覆盖多个数据列，如像INDEX(columnA, columnB)索引。
**全文索引**：通过建立 倒排索引 ,可以极大的提升检索效率,解决判断字段是否包含的问题，是目前搜索引擎使用的一种关键技术。可以通过ALTER TABLE table\_name ADD FULLTEXT (column);创建全文索引索引可以极大的提高数据的查询速度。

通过使用索引，可以在查询的过程中，使用优化隐藏器，提高系统的性能。
但是会降低插入、删除、更新表的速度，因为在执行这些写操作时，还要操作索引文件
索引需要占物理空间，除了数据表占数据空间之外，每一个索引还要占一定的物理空间，如果要建立聚簇索引，那么需要的空间就会更大，如果非聚集索引很多，一旦聚集索引改变，那么所有非聚集索引都会跟着变。

### 24、MySQL执行计划怎么看

执行计划就是sql的执行查询的顺序，以及如何使用索引查询，返回的结果集的行数
EXPLAIN SELECT \* from A where X=? and Y=?

1 **.id** ：是一个有顺序的编号，是查询的顺序号，有几个 select 就显示几行。id的顺序是按 select 出现的顺序增长的。id列的值越大执行优先级越高越先执行，id列的值相同则从上往下执行，id列的值为NULL最后执行。

**2.selectType** 表示查询中每个select子句的类型
SIMPLE： 表示此查询不包含 UNION 查询或子查询
PRIMARY： 表示此查询是最外层的查询（包含子查询）
SUBQUERY： 子查询中的第一个 SELECT
UNION： 表示此查询是 UNION 的第二或随后的查询
DEPENDENT UNION： UNION 中的第二个或后面的查询语句, 取决于外面的查询
UNION RESULT, UNION 的结果
DEPENDENT SUBQUERY: 子查询中的第一个 SELECT, 取决于外面的查询. 即子查询依赖于外层查
询的结果.
DERIVED：衍生，表示导出表的SELECT（FROM子句的子查询）
**3.table**：表示该语句查询的表

**4.type：** 优化sql的重要字段，也是我们判断sql性能和优化程度重要指标。他的取值类型范围：
const：通过索引一次命中，匹配一行数据
system: 表中只有一行记录，相当于系统表；
eq\_ref：唯一性索引扫描，对于每个索引键，表中只有一条记录与之匹配
ref: 非唯一性索引扫描,返回匹配某个值的所有
range: 只检索给定范围的行，使用一个索引来选择行，一般用于between、<、>；
index: 只遍历索引树；
ALL: 表示全表扫描，这个类型的查询是性能最差的查询之一。 那么基本就是随着表的数量增多，
执行效率越慢。
执行效率：
\*\*ALL < index < range< ref < eq\_ref < const < system。\*\*最好是避免ALL和index

**5.possible\_keys**：它表示Mysql在执行该sql语句的时候，可能用到的索引信息，仅仅是可能，实际不一定会用到。

**6.key：** 此字段是 mysql 在当前查询时所真正使用到的索引。 他是possible\_keys的子集

**7.key\_len**：表示查询优化器使用了索引的字节数，这个字段可以评估组合索引是否完全被使用，这也是我们优化sql时，评估索引的重要指标

**9.rows**：mysql 查询优化器根据统计信息，估算该sql返回结果集需要扫描读取的行数，这个值相关重要，索引优化之后，扫描读取的行数越多，说明索引设置不对，或者字段传入的类型之类的问题，说明要优化空间越大。

**10.filtered：** 返回结果的行占需要读到的行(rows列的值)的百分比，就是百分比越高，说明需要查询到数据越准确， 百分比越小，说明查询到的数据量大，而结果集很少

**11.extra**
using filesort ：表示 mysql 对结果集进行外部排序，不能通过索引顺序达到排序效果。一般有
using filesort都建议优化去掉，因为这样的查询 cpu 资源消耗大，延时大。
using index：覆盖索引扫描，表示查询在索引树中就可查找所需数据，不用扫描表数据文件，往
往说明性能不错。
using temporary：查询有使用临时表, 一般出现于排序， 分组和多表 join 的情况， 查询效率不
高，建议优化。
using where ：sql使用了where过滤,效率较高。

### 25、MySQL常见优化手段

（1）尽量选择较小的列

（2）将where中用的比较频繁的字段建立索引

（3）select子句中避免使用‘ \*’

（4）避免在索引列上使用计算、not in 和<>等操作

（5）当只需要一行数据的时候使用limit 1

（6）保证单表数据不超过200W，适时分割表。针对查询较慢的语句，可以使用explain 来分析该语句具体的执行情况。

（7）避免改变索引列的类型。

（8）选择最有效的表名顺序，from字句中写在最后的表是基础表，将被最先处理，在from子句中包含多个表的情况下，你必须选择记录条数最少的表作为基础表。

（9）避免在索引列上面进行计算。

（10）能用关联查询的不要用子查询

（11）尽量缩小子查询的结果





#                                          网络

## Netty

### 1 为什么Netty适合做网络编程？

Netty是一个基于Java的高性能网络编程框架，它被广泛用于构建可扩展的、高性能的网络应用程序。以下是一些原因说明为什么Netty适合做网络编程：

1.  强大的抽象和组件：Netty提供了一组强大的抽象和可重用的组件，如事件模型、处理器链、编解码器等。这些组件使得网络编程变得更加简单和灵活，开发者可以根据需求自由组合和定制。
2.  高性能：Netty采用了基于事件驱动的异步非阻塞IO模型，利用了Java NIO（New IO）的特性，能够处理大量的并发连接。它的线程模型和内存管理机制也经过优化，能够最大限度地提高网络应用程序的性能和吞吐量。
3.  完善的协议支持：Netty提供了丰富的协议支持，包括TCP、UDP、HTTP、WebSocket等。它内置了许多常用的协议编解码器，可以轻松地进行协议的解析和编码，简化了网络应用程序的开发过程。
4.  可扩展性：Netty的设计非常灵活，支持自定义的协议、编解码器和处理器。它提供了丰富的扩展点和钩子函数，可以方便地进行功能扩展和定制，满足各种复杂的业务需求。
5.  成熟稳定：Netty是一个成熟稳定的开源项目，经过了广泛的实际应用和验证。它拥有活跃的社区和强大的生态系统，提供了大量的文档、示例和工具，使得开发者能够快速上手并解决问题。

综上所述，Netty具有强大的抽象和组件、高性能、完善的协议支持、可扩展性和成熟稳定等特点，使其成为一种优秀的选择用于网络编程。

### 2 Netty性能好的原因是什么？

Netty 是一个高性能的网络应用框架，其性能好的原因主要有以下几点：

1.  异步非阻塞：Netty 使用异步非阻塞的 I/O 模型，可以处理大量的并发连接而不需要为每个连接分配一个线程。这种模型减少了线程切换的开销，提高了系统的吞吐量和响应速度。
2.  高度可定制化：Netty 提供了丰富的可定制化选项，可以根据应用的需求进行灵活的配置。开发者可以自定义编解码器、处理器链、线程模型等，以适应不同的网络应用场景。
3.  零拷贝：Netty 支持零拷贝技术，可以避免数据在内存之间的多次拷贝，减少了内存的使用和数据传输的开销，提高了性能。
4.  内存管理优化：Netty 使用了内存池技术，可以重用内存，减少了频繁的内存分配和回收操作，提高了内存的利用率和性能。
5.  模块化设计：Netty 的设计模块化，各个功能模块之间解耦，可以根据需要选择性地使用特定的模块，避免了不必要的性能损耗。

总的来说，Netty 的高性能得益于其异步非阻塞的 I/O 模型、可定制化的设计、零拷贝技术、内存管理优化和模块化架构等多个方面的优势。这些特性使得 Netty 成为开发高性能网络应用的理想选择。

### 3 Netty的零拷贝是怎么实现的？

Netty 实现零拷贝主要依赖于以下两个技术：

1.  零拷贝文件传输：Netty 使用了操作系统提供的零拷贝机制，例如 Linux 下的 sendfile 和 splice 系统调用。这些系统调用可以直接将文件数据从磁盘读取到网络套接字，或者从一个套接字传输到另一个套接字，而无需经过用户空间和内核空间之间的数据拷贝。
2.  零拷贝内存传输：Netty 使用了 Direct Memory Buffer（直接内存缓冲区）来实现零拷贝内存传输。直接内存缓冲区是一种直接分配在堆外内存的缓冲区，可以通过操作系统的文件描述符直接读写数据，避免了数据在用户空间和内核空间之间的拷贝。

通过使用这些零拷贝技术，Netty 在进行数据传输时可以避免将数据从一个缓冲区拷贝到另一个缓冲区，从而减少了数据拷贝的次数和数据在内存之间的传输开销。这样可以提高数据传输的效率和性能。

需要注意的是，零拷贝并不是在所有情况下都能完全避免数据拷贝。在某些情况下，仍然需要进行少量的数据拷贝操作，例如数据的解码和编码过程。但是相比传统的拷贝方式，Netty 的零拷贝机制可以最大程度地减少数据拷贝的次数，提高了性能。

### 4 能不能说一说Netty的无锁化设计？

Netty 的无锁化设计是指在多线程环境下，尽量减少对共享数据的锁使用，以避免锁竞争和线程阻塞，从而提高系统的并发性能。Netty 在实现无锁化设计时主要采用了以下几种技术：

1.  并发容器：Netty 使用了并发容器来替代传统的线程安全集合类。例如，使用 ConcurrentMap 替代 HashMap，使用 ConcurrentLinkedQueue 替代 LinkedList，这些并发容器底层使用了 CAS（Compare and Swap）等无锁算法来实现线程安全。
2.  原子操作：Netty 使用了原子操作来实现对共享数据的无锁访问。原子操作是一种不可中断的操作，可以保证在多线程环境下对共享数据的操作是原子性的。Netty 使用了 Java 提供的原子类，如 AtomicBoolean、AtomicInteger 等，来实现无锁访问。
3.  事件驱动模型：Netty 的核心思想是基于事件驱动的模型，通过事件的发布和订阅来实现线程间的解耦和通信。这种模型避免了线程间的锁竞争，每个线程只需要处理自己感兴趣的事件，大大提高了系统的并发性能。
4.  非阻塞 I/O：Netty 使用了非阻塞的 I/O 模型，通过异步的方式处理网络 I/O 操作，避免了线程在等待 I/O 完成时的阻塞，提高了系统的并发性能。

通过这些无锁化设计的技术手段，Netty 在多线程环境下能够更好地利用计算资源，提高系统的并发性能和可伸缩性。同时，无锁化设计也减少了线程间的竞争和线程阻塞，避免了潜在的死锁和性能瓶颈问题。

### 5 Netty的线程模型是怎么样的？

Netty的线程模型是基于事件驱动的，它采用了多线程池的架构来处理网络请求和事件。以下是Netty的线程模型的主要特点：

1.  **Boss线程池（Acceptors）**：这个线程池用于处理新的连接请求，通常会绑定到一个端口，并且负责接受客户端的连接。每个Boss线程都会监听一个独立的套接字，用于接受客户端的连接请求。
2.  **Worker线程池（EventLoopGroup）**：一旦连接建立，客户端的请求会被传递给Worker线程池中的一个EventLoop进行处理。Worker线程池负责处理I/O事件，如读取和写入数据，以及执行用户定义的业务逻辑。Netty通常会有多个Worker线程，每个线程都会处理多个连接，通过事件循环（EventLoop）来处理这些连接上的事件。
3.  **EventLoop（事件循环）**：每个Worker线程都包含一个EventLoop，它负责处理一个或多个连接上的事件。EventLoop会持续地从事件队列中获取事件，然后执行相应的操作，比如读取数据、处理请求、写入数据等。每个连接都会被分配到一个特定的EventLoop，确保了事件的顺序性和线程的安全性。
4.  **任务队列**：Netty使用任务队列来存储需要处理的事件，这些事件可以是读写操作、用户自定义的任务或其他事件。这些事件会被EventLoop从队列中取出并执行。

总体来说，Netty的线程模型允许多个连接共享同一个线程，避免了线程创建和销毁的开销，提高了系统的性能和效率。通过事件驱动的方式，Netty能够高效地处理大量的并发连接，适用于构建高性能、可扩展的网络应用程序。需要注意的是，具体的线程数目和配置可以根据应用程序的需求进行调整。

### 6 Netty如何解决TCP粘包、拆包的问题的？

Netty提供了多种解决TCP粘包和拆包问题的机制，帮助开发者处理在网络传输过程中可能出现的数据分片问题。这些机制可以确保数据在发送和接收时能够正确地分割和组装，从而避免粘包和拆包的困扰。

以下是Netty解决TCP粘包和拆包问题的一些常见方法：

1.  **固定长度解码器（FixedLengthFrameDecoder）**：这个解码器会根据指定的固定长度对接收到的数据进行切割。无论数据内容如何，都会按照固定长度进行拆分，从而确保每个数据包的长度是一致的。
2.  **行尾分隔符解码器（LineBasedFrameDecoder）**：适用于基于文本协议的场景，该解码器会根据行尾分隔符（如换行符）将数据切分为不同的数据包。这样，每个数据包都会包含一行完整的文本。
3.  **分隔符解码器（DelimiterBasedFrameDecoder）**：类似于行尾分隔符解码器，但可以自定义分隔符。开发者可以指定特定的字节序列作为分隔符，用于切分数据。
4.  **自定义解码器**：Netty还允许开发者根据具体的协议和业务需求创建自定义的解码器。这样可以更灵活地处理数据的分割和组装。

这些解码器通常作为ChannelPipeline中的一部分，用于解决数据在网络传输过程中可能引发的粘包和拆包问题。开发者可以根据自己的需求选择合适的解码器，或者结合多种解码器来处理不同类型的数据。

需要注意的是，虽然这些解码器可以很好地处理大部分粘包和拆包问题，但在一些复杂的情况下可能仍需要开发者进行额外的处理和调优。

### 7 Netty的Buffer为什么好用

Netty的Buffer在网络编程中被认为非常好用，有以下几个方面的优势：

1.  **内存管理优化**：Netty的Buffer实现了内存池技术，能够有效地管理内存的分配和释放。这可以减少频繁的内存分配和垃圾回收，从而提高性能和减少延迟。
2.  **零拷贝技术**：Netty的Buffer支持零拷贝（Zero-Copy）技术，这意味着在数据传输过程中可以避免不必要的数据拷贝，减少了CPU和内存的负担，提高了数据传输的效率。
3.  **支持多种数据类型**：Netty的Buffer提供了多种类型的Buffer，如堆内存缓冲区（Heap Buffer）和直接内存缓冲区（Direct Buffer），可以根据需要选择合适的Buffer类型来优化性能。
4.  **灵活的API**：Netty的Buffer提供了丰富的操作方法，可以轻松地进行数据读写、切片、复制等操作，使得处理数据变得更加方便和灵活。
5.  **与ChannelPipeline集成**：Netty的Buffer与ChannelPipeline紧密集成，可以方便地在不同的处理器（如编码器、解码器、处理器等）之间传递数据，简化了数据处理的流程。
6.  **可扩展性和定制性**：Netty允许开发者基于自己的需求扩展和定制Buffer的行为，从而实现更高级别的功能和优化。

综上所述，Netty的Buffer在性能、内存管理、数据传输效率以及灵活性方面的优势，使得它成为了网络编程中一个非常实用和强大的工具。无论是处理小规模数据还是大规模数据，Netty的Buffer都能够有效地提升网络应用的性能和可靠性。

### 8 说说 Netty 的对象池技术？

Netty的对象池技术是一种用于管理和重用对象的机制，旨在提高内存使用效率和性能。在网络编程中，频繁地创建和销毁对象可能会导致内存碎片化和额外的垃圾回收开销，从而影响应用程序的性能。Netty引入了对象池技术来缓解这些问题。

在Netty中，对象池主要用于管理两种类型的对象：ByteBuf（字节缓冲区）和ChannelHandlerContext（通道处理上下文）。以下是关于Netty对象池技术的一些关键点：

1.  **ByteBuf对象池**：Netty的ByteBuf是用于处理网络数据的字节缓冲区。通过使用ByteBuf对象池，Netty可以重用已经分配的字节缓冲区，避免频繁地创建和销毁这些对象。这有助于减少内存分配和垃圾回收的开销，提高数据传输效率和应用程序性能。
2.  **ChannelHandlerContext对象池**：Netty中的ChannelHandlerContext代表了处理器（如编码器、解码器、处理器等）与Channel之间的关联关系。通过使用ChannelHandlerContext对象池，Netty可以在数据处理过程中重用上下文对象，减少上下文对象的创建和销毁开销，从而提高数据处理的效率。
3.  **资源回收和管理**：Netty的对象池技术能够自动地管理对象的生命周期和资源回收。当对象不再需要时，它们会被返回到对象池，以便稍后重用。这有助于避免内存泄漏和资源浪费。
4.  **配置和定制**：Netty允许开发者根据应用程序的需求进行对象池的配置和定制。开发者可以设置池的大小、对象的生存时间等参数，以适应不同的场景和负载。

综上所述，Netty的对象池技术是一项重要的功能，能够有效地提高网络应用程序的内存使用效率和性能，特别是在处理大规模数据和高并发情况下。通过重用对象，Netty能够降低资源开销，提高数据传输效率，并且在一定程度上减少内存碎片化问题。

### 9 Netty有哪些序列化协议？

Netty并不直接提供序列化协议，但它可以与各种序列化协议进行集成。序列化是将对象转换为可在网络上传输或持久化存储的格式的过程。Netty可以与多种序列化协议一起使用，以根据应用程序的需要进行数据的编码和解码。以下是一些常见的序列化协议，可以与Netty一起使用：

1.  **Java自带的序列化（Java Serialization）**：Java自带了一套对象序列化机制，可以将Java对象转换为字节流进行传输。但是，这种序列化方式在性能和灵活性方面可能存在问题，因此在高性能网络应用中可能不是首选。
2.  **JSON（JavaScript Object Notation）**：JSON是一种轻量级的数据交换格式，易于阅读和编写，适用于各种编程语言。Netty可以与JSON库（如Jackson、Gson等）一起使用，将对象转换为JSON格式进行传输。
3.  **Protobuf（Protocol Buffers）**：Protobuf是一种由Google开发的高效的二进制序列化协议，具有很高的性能和紧凑的数据表示。Netty可以与Protobuf集成，使用Protobuf生成的类来进行对象的编码和解码。
4.  **MessagePack**：MessagePack是一种基于二进制的轻量级序列化格式，具有高性能和紧凑的数据表示。它可以与Netty一起使用，实现数据的传输和解析。
5.  **Thrift**：Thrift是由Apache开发的一种跨语言的序列化协议，支持多种编程语言，并具有高性能和可扩展性。Netty可以与Thrift一起使用，实现对象的序列化和反序列化。
6.  **Avro**：Avro是另一种由Apache开发的序列化框架，旨在提供紧凑的二进制格式和动态数据模型。Netty可以与Avro一起使用，实现数据的编码和解码。

这些序列化协议可以根据应用程序的需求进行选择，根据性能、数据大小、跨语言支持等因素来决定使用哪种协议。Netty的灵活性使得它能够与各种序列化协议集成，以实现高效的网络通信。

### 10 Netty 中用了哪些设计模式？

在Netty中使用了许多设计模式来实现高效的网络通信和处理。以下是一些Netty中使用的设计模式：

1.  **工厂模式（Factory Pattern）**：Netty使用工厂模式来创建不同类型的通道、处理器和其他组件，隐藏了对象创建的细节，使代码更具可维护性和扩展性。
2.  **装饰器模式（Decorator Pattern）**：Netty的处理器链（Pipeline）机制使用了装饰器模式。每个处理器都可以在收到数据、处理数据和传递数据时添加额外的逻辑，这使得用户可以轻松地定制数据的处理流程。
3.  **观察者模式（Observer Pattern）**：Netty中的事件和事件监听器机制使用了观察者模式。通道状态变化、数据读写等事件可以被观察，而用户可以注册相应的监听器来处理这些事件。
4.  **责任链模式（Chain of Responsibility Pattern）**：Netty的处理器链（Pipeline）本质上就是一个责任链，每个处理器负责特定的任务，可以在链中按顺序处理数据，将复杂的处理逻辑拆分成独立的模块。
5.  **单例模式（Singleton Pattern）**：Netty中的一些关键组件，如线程池、事件循环，都使用了单例模式确保只有一个实例存在，从而节省资源并确保一致性。
6.  **模板方法模式（Template Method Pattern）**：Netty的一些类提供了模板方法，定义了通用的处理流程和步骤，而将具体的实现细节留给子类来实现。
7.  **策略模式（Strategy Pattern）**：Netty中的一些组件，如编码器和解码器，可以根据不同的业务需求进行替换，这种灵活性符合策略模式的思想。
8.  **适配器模式（Adapter Pattern）**：Netty中的适配器可以帮助用户将不同的数据格式、协议等转换成统一的格式，以适应不同的通信需求。

这些设计模式的使用使得Netty能够提供高度灵活、高性能和可扩展的网络通信框架，满足各种不同应用场景的需求。



## Tomcat

### 1、Tomcat的缺省端口是多少，怎么修改？

默认端口为8080，可以通过在tomcat安装包conf目录下，service.xml中的Connector元素的port属性来修改端口。

### 2、tomcat 有哪几种Connector 运行模式(优化)？

这三种模式的不同之处如下：

BIO：一个线程处理一个请求。缺点：并发量高时，线程数较多，浪费资源。Tomcat7版本或更低版本中，在Linux系统中默认使用这种方式。

NIO：利用Java的异步IO处理，可以通过少量的线程处理大量的请求。tomcat8.0.x中默认使用的是NIO。Tomcat7必须修改Connector配置来启动：

```纯文本
<Connector port="8080" protocol="org.apache.coyote.http11.Http11NioProtocol" connectionTimeout="20000" redirectPort="8443"/>
```

APR：即Apache Portable Runtime，从操作系统层面解决io阻塞问题。Tomcat7或Tomcat8在Win7或以上的系统中启动默认使用这种方式。

### 3、Tomcat有几种部署方式？

利用Tomcat的自动部署：把web应用拷贝到webapps目录（生产环境不建议放在该目录中）。Tomcat在启动时会加载目录下的应用，并将编译后的结果放入work目录下。

使用Manager App控制台部署：在tomcat主页点击“Manager App” 进入应用管理控制台，可以指定一个web应用的路径或war文件。修改conf/server.xml文件部署：在server.xml文件中，增加Context节点可以部署应用。

增加自定义的Web部署文件：在conf/Catalina/localhost/路径下增加 xyz.xml文件，内容是Context节点，可以部署应用。

### 4、tomcat容器是如何创建servlet类实例？用到了什么原理？

当容器启动时，会读取在webapps目录下所有的web应用中的web.xml文件，然后对 xml文件进行解析，并读取servlet注册信息。然后，将每个应用中注册的servlet类都进行加载，并通过 反射的方式实例化。（有时候也是在第一次请求时实例化）在servlet注册时加上1如果为正数，则在一开始就实例化，如果不写或为负数，则第一次请求实例化。

### 5、tomcat 如何优化？

tomcat作为Web服务器，它的处理性能直接关系到用户体验，下面是几种常见的优化措施：

掉对web.xml的监视，把jsp提前编辑成Servlet。有富余物理内存的情况，加大tomcat使用的jvm的内存

服务器所能提供CPU、内存、硬盘的性能对处理能力有决定性影响。

对于高并发情况下会有大量的运算，那么CPU的速度会直接影响到处理速度。内存在大量数据处理的情况下，将会有较大的内存容量需求，可以用-Xmx -Xms -XX:MaxPermSize等参数对内存不同功能块进行划分。我们之前就遇到过内存分配不足，导致虚拟机一直处于full GC，从而导致处理能力严重下降。硬盘主要问题就是读写性能，当大量文件进行读写时，磁盘极容易成为性能瓶颈。最好的办法还是利用下面提到的缓存。利用缓存和压缩

对于静态页面最好是能够缓存起来，这样就不必每次从磁盘上读。这里我们采用了Nginx作为缓存服务器，将图片、css、js文件都进行了缓存，有效地减少了后端tomcat的访问。另外，为了能加快网络传输速度，开启gzip压缩也是必不可少的。但考虑到tomcat已经需要处理很多东西了，所以把这个压缩的工作就交给前端的Nginx来完成。除了文本可以用gzip压缩，其实很多图片也可以用图像处理工具预先进行压缩，找到一个平衡点可以让画质损失很小而文件可以减小很多。曾经我就见过一个图片从300多kb压缩到几十kb，自己几乎看不出来区别。采用集群

单个服务器性能总是有限的，最好的办法自然是实现横向扩展，那么组建tomcat集群是有效提升性能的手段。我们还是采用了Nginx来作为请求分流的服务器，后端多个tomcat共享session来协同工作。

优化线程数优化

找到Connector port="8080" protocol="HTTP/1.1"，增加maxThreads和acceptCount属性（使acceptCount大于等于maxThreads），如下：

```纯文本
<Connector port="8080" protocol="HTTP/1.1"connectionTimeout="20000" redirectPort="8443"acceptCount="500" maxThreads="400" />
```

其中：

maxThreads：tomcat可用于请求处理的最大线程数，默认是200 minSpareThreads：tomcat初始线程数，即最小空闲线程数 maxSpareThreads：tomcat最大空闲线程数，超过的会被关闭 acceptCount：当所有可以使用的处理请求的线程数都被使用时，可以放到处理队列中的请求数，超过这个数的请求将不予处理.默认100

使用线程池优化

在server.xml中增加executor节点，然后配置connector的executor属性，如下：

```纯文本
<Executor name="tomcatThreadPool" namePrefix="req-exec-"maxThreads="1000" minSpareThreads="50"maxIdleTime="60000"/><Connector port="8080" protocol="HTTP/1.1"executor="tomcatThreadPool"/>
```

其中：

namePrefix：线程池中线程的命名前缀 maxThreads：线程池的最大线程数 minSpareThreads：线程池的最小空闲线程数 maxIdleTime：超过最小空闲线程数时，多的线程会等待这个时间长度，然后关闭 threadPriority：线程优先级

注：当tomcat并发用户量大的时候，单个jvm进程确实可能打开过多的文件句柄，这时会报java.net.SocketException:Too many open files错误。可使用下面步骤检查：

ps -ef |grep tomcat 查看tomcat的进程ID，记录ID号，假设进程ID为10001 lsof -p 10001|wc -l 查看当前进程id为10001的 文件操作数 使用命令：ulimit -a 查看每个用户允许打开的最大文件数

启动速度优化

删除没用的web应用：因为tomcat启动每次都会部署这些应用。关闭WebSocket：websocket-api.jar和tomcat-websocket.jar。随机数优化：设置JVM参数：-Djava.security.egd=file:/dev/./urandom。内存优化

因为tomcat启动起来后就是一个java进程，所以这块可以参照JVM部分的优化思路。堆内存相关参数，比如说：

-Xms：虚拟机初始化时的最小堆内存。

-Xmx：虚拟机可使用的最大堆内存。-Xms与-Xmx设成一样的值，避免JVM因为频繁的GC导致性能大起大落

-XX:MaxNewSize：新生代占整个堆内存的最大值。

另外还有方法区参数调整（注意：JDK版本）、垃圾收集器等优化。JVM相关参数请看：手把手教你设置JVM调优参数

### 6、熟悉tomcat的哪些配置？

Context(表示一个web应用程序，通常为WAR文件，关于WAR的具体信息见servlet规范)标签。

docBase：该web应用的文档基准目录（Document Base，也称为Context Root），或者是WAR文件的路径。可以使绝对路径，也可以使用相对于context所属的Host的appBase路径。

path：表示此web应用程序的url的前缀，这样请求的url为<http://localhost:8080/path/。>

reloadable：这个属性非常重要，如果为true，则tomcat会自动检测应用程序的/WEB-INF/lib和/WEB-INF/classes目录的变化，自动装载新的应用程序，我们可以在不重启tomcat的情况下改变应用程序。

useNaming：如果希望Catalina为该web应用使用一个JNDI InitialContext对象，设为true。该InitialialContext符合J2EE平台的约定，缺省值为true。

workDir：Context提供的临时目录的路径，用于servlet的临时读/写。利用javax.servlet.context.tempdir属性，servlet可以访问该目录。如果没有指定，使用\$CATALINA\_HOME/work下一个合适的目录。

swallowOutput：如果该值为true，System.out和System.err的输出被重定向到web应用的logger。如果没有指定，缺省值为false

debug：与这个Engine关联的Logger记录的调试信息的详细程度。数字越大，输出越详细。如果没有指定，缺省为0。

host(表示一个虚拟主机)标签。

name：指定主机名。

appBase：应用程序基本目录，即存放应用程序的目录。

unpackWARs：如果为true，则tomcat会自动将WAR文件解压，否则不解压，直接从WAR文件中运行应用程序。

Logger(表示日志，调试和错误信息)标签。

className：指定logger使用的类名，此类必须实现org.apache.catalina.Logger接口。

prefix：指定log文件的前缀。

suffix：指定log文件的后缀。

timestamp：如果为true，则log文件名中要加入时间，如下例：localhost\_log.2001-10-04.txt。



## 计算机网络

### 1、介绍一下OSI七层模型？

当然，我很乐意为您介绍一下OSI七层模型。

OSI七层模型是一个用于描述计算机网络通信协议的框架，它由国际标准化组织（ISO）于1984年制定并发布。该模型将网络通信过程分解为七个不同的层次，每个层次都负责特定的功能，从物理连接到应用程序的交互，以实现数据在不同设备之间的传输和交换。以下是每个层次的简要介绍：

1.  **物理层（Physical Layer）：** 这是最底层的层次，负责处理物理媒介和电信号传输。它定义了连接硬件设备的标准，例如电缆类型、电压规范等。
2.  **数据链路层（Data Link Layer）：** 此层负责在直接相连的两个设备之间传输数据帧，通过物理地址（MAC地址）进行寻址和识别。它还处理错误检测和校正，确保可靠的数据传输。
3.  **网络层（Network Layer）：** 网络层负责在不同网络之间路由数据包，通过IP地址进行寻址。它处理数据包的传输路径选择和逻辑寻址，以实现跨网络的通信。
4.  **传输层（Transport Layer）：** 传输层负责在端到端的通信中提供数据传输的可靠性和错误检测。它管理数据的分段、传输控制、流量控制等，常见的传输层协议包括TCP（传输控制协议）和UDP（用户数据报协议）。
5.  **会话层（Session Layer）：** 会话层负责建立、管理和终止应用程序之间的会话连接。它处理会话的控制和同步，确保数据正确传输并在需要时进行恢复。
6.  **表示层（Presentation Layer）：** 表示层负责数据的格式化、加密、压缩等处理，以确保不同系统间数据的交换和解释能够无障碍地进行。
7.  **应用层（Application Layer）：** 应用层是最顶层的层次，直接为用户提供网络服务和应用程序。它包含了各种应用，如电子邮件、文件传输、远程访问等。

通过这种分层的方式，OSI模型帮助网络工程师和开发者更好地理解和设计网络协议、通信和应用。然而，需要注意的是，实际网络协议不一定都严格按照这七层模型来设计，而是根据实际需求和技术进行了调整和扩展。

### 2、什么是TCP的粘包、拆包

TCP（Transmission Control Protocol）是一种常用的传输层协议，用于在计算机网络上可靠地传输数据。在TCP通信中，粘包（Packet Sticking）和拆包（Packet Splitting）是两个可能出现的问题，涉及到数据的传输和接收过程中的数据分割和组合。

**粘包（Packet Sticking）：** 粘包指的是在发送端将多个小数据包连续发送，而接收端却可能一次性接收到了多个小数据包，这些数据包“粘”在一起，无法准确分辨出每个数据包的界限。这可能是因为发送端的数据写入缓冲区比较快，而接收端读取数据的速度较慢，导致多个数据包被一次性读取。粘包会导致接收端无法正确解析数据，从而影响数据的处理和解释。

**拆包（Packet Splitting）：** 拆包指的是在发送端将一个大数据包分割成多个小数据包发送，而接收端却可能无法正确地将这些小数据包组合成完整的大数据包。这可能是因为发送端的数据分割不当，或者接收端没有足够的信息来确定如何正确组合这些小数据包。拆包会导致接收端无法还原原始数据，从而造成数据的错误或丢失。

为了解决粘包和拆包问题，通常需要在应用层设计一些协议或者采用一些技术手段，例如：

1.  **消息长度字段：** 在消息的开头加入一个固定长度的字段，用来表示后续消息的长度，接收端可以根据这个字段来准确地分割和组合数据包。
2.  **消息分隔符：** 在消息的末尾加入一个特定的分隔符，接收端通过识别分隔符来分割数据包。
3.  **使用固定长度消息：** 将所有消息都固定到同样的长度，不足的部分用填充数据补齐。
4.  **应用层协议设计：** 在应用层定义明确的消息格式和协议，确保发送端和接收端都按照相同的规则进行数据的分割和组合。

总之，处理粘包和拆包问题需要在应用层进行合适的设计和处理，以确保数据在传输过程中能够正确地分割和组合，保证通信的可靠性和准确性。

### 3、ARP 与 RARP 的区别是什么？

ARP（Address Resolution Protocol）和RARP（Reverse Address Resolution Protocol）都是用于在网络通信中解决IP地址和物理MAC地址之间映射关系的协议，但它们的功能和应用场景有所不同。

1.  **ARP（Address Resolution Protocol）：** ARP用于将一个已知的IP地址解析成对应的物理MAC地址。在一个局域网中，当主机需要与另一个主机通信时，它会先检查自己的ARP缓存表，看是否已经有目标IP地址对应的MAC地址。如果没有，它就会发送一个ARP请求广播，询问局域网内是否有响应该IP地址的主机。目标主机收到该请求后，会发送一个ARP响应，包含自己的MAC地址。这样，请求主机就可以得到目标主机的MAC地址，从而建立通信。
2.  **RARP（Reverse Address Resolution Protocol）：** RARP与ARP相反，它用于将已知的物理MAC地址解析成对应的IP地址。主要应用于无盘工作站等设备，在启动时需要获取自己的IP地址，但是这些设备没有预设IP地址，只有MAC地址。设备启动时会发送一个RARP请求广播，请求分配一个IP地址。RARP服务器会收到请求后，查找MAC地址对应的IP地址，然后将IP地址发送回设备，使设备能够配置自己的IP地址。

总结区别：

-   ARP解析IP地址到MAC地址，而RARP解析MAC地址到IP地址。
-   ARP主要用于常规网络通信，而RARP主要用于无盘设备等特殊情况下的地址配置。
-   ARP请求由需要通信的主机发出，而RARP请求由需要获取IP地址的设备发出。

需要注意的是，随着网络技术的发展，ARP和RARP在现代网络中的使用逐渐减少，因为有更高级的技术和协议来管理IP地址和MAC地址的映射关系，如DHCP（Dynamic Host Configuration Protocol）和IPv6的邻居发现协议。

### 4、路由器与交换机的区别是什么？

路由器（Router）和交换机（Switch）是网络中常见的两种设备，它们在网络中扮演不同的角色，有以下区别：

1.  **功能与工作层次**：
    -   **路由器**：路由器位于网络的边缘，连接不同的网络或子网，主要负责在不同网络之间转发数据包。它能够基于目标IP地址决定数据包的最佳路径，从而实现网络之间的通信。
    -   **交换机**：交换机通常位于局域网（LAN）内部，它通过学习MAC地址来建立和维护一个MAC地址表，然后根据MAC地址表将数据包直接从源端口转发到目标端口，从而实现局域网内部设备之间的通信。
2.  **转发决策**：
    -   **路由器**：路由器通过查看数据包的目标IP地址来进行转发决策，选择最佳路径将数据包从一个网络传送到另一个网络。
    -   **交换机**：交换机通过查看数据包的源MAC地址来决定将数据包发送到哪个目标端口，以实现局域网内部设备之间的直接通信。
3.  **广播域和碰撞域**：
    -   **路由器**：路由器能够隔离不同网络之间的广播域和碰撞域，这意味着在不同网络间的广播消息不会被传播到其他网络。
    -   **交换机**：交换机也能够隔离广播域，但在同一个交换机内部，所有设备共享一个碰撞域，因此在交换机内部通信不会发生碰撞。
4.  **网络范围**：
    -   **路由器**：路由器通常用于连接不同的网络，可以跨越不同的物理位置和地理区域。
    -   **交换机**：交换机通常用于连接同一局域网内的设备，限制在一个相对较小的网络范围内。

总之，路由器和交换机在网络中扮演不同的角色，分别用于实现不同的通信需求。路由器负责不同网络之间的数据包转发，而交换机则负责同一网络内部设备之间的数据包交换。

### 5、什么是TCP三次握手、四次挥手？

当然，我可以解释一下TCP三次握手和四次挥手的概念。

**TCP三次握手**：

TCP三次握手是在建立TCP连接时使用的一种协议，用于确保客户端和服务器之间的通信能够稳定地开始。这个过程涉及三个步骤：

1.  **第一步（SYN）**：客户端向服务器发送一个带有SYN（同步）标志的数据包，请求建立连接。客户端进入SYN\_SENT状态。
2.  **第二步（SYN-ACK）**：服务器收到客户端的请求后，会发送一个带有SYN和ACK（确认）标志的数据包，表示同意建立连接。服务器进入SYN\_RECEIVED状态。
3.  **第三步（ACK）**：客户端收到服务器的响应后，发送一个带有ACK标志的数据包给服务器，确认连接已建立。双方都进入已建立连接的状态，可以开始进行数据传输。

这三步握手过程确保了双方都同意建立连接，并且双方都准备好了进行数据传输。

**TCP四次挥手**：

TCP四次挥手是在关闭TCP连接时使用的一种协议，用于确保双方能够安全地终止连接。这个过程涉及四个步骤：

1.  **第一步（FIN）**：一方（通常是客户端）向另一方（通常是服务器）发送一个带有FIN（结束）标志的数据包，表示希望关闭连接。发送方进入FIN\_WAIT\_1状态。
2.  **第二步（ACK）**：接收方收到关闭请求后，发送一个带有ACK标志的数据包作为确认。发送方进入FIN\_WAIT\_2状态，等待接收方的确认。
3.  **第三步（FIN）**：接收方准备好关闭连接时，会发送一个带有FIN标志的数据包，表示同意关闭连接。接收方进入CLOSE\_WAIT状态。
4.  **第四步（ACK）**：发送方收到接收方的关闭确认后，发送一个带有ACK标志的数据包作为确认。双方都进入连接已关闭的状态。

这四步挥手过程确保双方都完成了数据传输，并且同意关闭连接，避免了数据丢失或不完整的情况。

总之，TCP三次握手和四次挥手是确保通信的可靠性和完整性的重要步骤，分别用于建立和关闭TCP连接。

### 6、TCP是如何保证可靠传输的？

TCP（传输控制协议）保证可靠传输的主要方式包括以下几个方面：

1.  **三次握手**：在建立连接时，发送方首先发送一个SYN（同步）标志的数据包给接收方。接收方收到后，确认收到这个SYN，并发送一个带有ACK（确认）和SYN标志的数据包给发送方。最后，发送方再发送一个带有ACK标志的数据包作为确认。这三步握手确保双方都同意建立连接，减少了连接错误的可能性。
2.  **序列号和确认机制**：TCP使用序列号来标识每个发送的数据包，接收方根据序列号确认收到的数据包。如果发送方未收到确认，会重新发送数据包，直到接收到确认为止。这保证了数据的可靠传输，避免了数据包丢失的情况。
3.  **数据分段和重组**：TCP将应用层传输的大块数据分割成小的数据段进行传输，接收方根据序列号将这些数据段重新组装成完整的数据。如果发现某个数据段丢失，TCP会要求重新发送该数据段，确保数据的完整性。
4.  **流量控制**：TCP利用滑动窗口机制进行流量控制，确保发送方不会发送过多的数据导致接收方无法及时处理。这防止了拥塞并保持了传输的平稳。
5.  **超时重传**：如果发送方在一定时间内没有收到确认，会认为数据包丢失，然后会重新发送这些数据包。这样即使数据包在传输过程中丢失，也能够通过超时重传来确保数据的到达。
6.  **四次挥手**：在关闭连接时，发送方和接收方都要确认关闭，防止数据的丢失或不完整。

通过上述机制，TCP可以有效地保证数据的可靠传输，确保数据在传输过程中不会丢失、重复或无序。

### 7、基于UDP实现一个TCP协议

UDP（User Datagram Protocol）是一种无连接的、不可靠的传输协议，而TCP（Transmission Control Protocol）是一种面向连接的、可靠的传输协议。基于UDP实现一个TCP协议是不可行的，因为UDP缺乏TCP提供的许多关键特性，如可靠的数据传输、流量控制、拥塞控制等。

然而，你可以使用UDP来实现一种类似TCP的协议，提供一些基本的可靠性和有序性。下面是一个简单的示例，展示了如何使用UDP实现一个基于可靠传输的简化TCP协议：

1.  **序号和确认机制：** 在数据包中添加序号字段和确认字段。发送方将每个数据包分配一个唯一的序号，并等待接收方发送确认消息。接收方收到数据包后，发送确认消息，确认收到的最后一个有序数据包的序号。发送方根据接收到的确认消息确定哪些数据包已经被成功接收。
2.  **超时重传：** 发送方需要设置一个定时器，在发送数据包后启动计时器。如果在一定时间内没有收到确认消息，发送方会假设数据包丢失，并重新发送该数据包。接收方在收到重复的数据包时可以丢弃重复的数据。
3.  **流量控制：** 发送方和接收方可以使用滑动窗口机制来进行流量控制。发送方根据接收方的可接受窗口大小来确定发送的数据量，并根据接收方发送的确认消息调整发送窗口的大小。
4.  **拥塞控制：** 由于UDP本身不提供拥塞控制机制，你可以基于UDP实现一些简单的拥塞控制策略，如慢启动和拥塞避免。这可以包括动态调整发送窗口大小和控制发送速率，以避免网络拥塞。

需要注意的是，尽管你可以使用UDP实现一些类似TCP的特性，但由于UDP的本质特点，它仍然无法提供与TCP完全相同的可靠性和性能。在实际应用中，如果需要可靠的数据传输和其他高级特性，建议使用TCP协议而不是基于UDP的自定义协议。

### 8、为什么需要HTTP/2，他解决了什么问题？

HTTP/2 是 HTTP 协议的下一代版本，旨在改进性能和效率。它解决了 HTTP/1.1 存在的一些问题，并引入了一些新的特性和优化，以提供更快的网页加载速度、更高的效率和更好的用户体验。以下是 HTTP/2 解决的一些问题：

1.  **多路复用（Multiplexing）：** 在 HTTP/1.1 中，每个请求都需要使用单独的连接，导致了高延迟和低效率。HTTP/2 使用二进制分帧层，通过在单个连接上同时发送多个请求和响应，实现了多路复用。这意味着可以并发处理多个请求，减少了延迟，提高了效率。
2.  **头部压缩（Header Compression）：** 在 HTTP/1.1 中，每个请求和响应的头部都需要重复发送，浪费了带宽和资源。HTTP/2 引入了头部压缩机制，使用了 HPACK 压缩算法，可以显著减少头部的大小，减少了数据传输量，提高了效率。
3.  **服务器推送（Server Push）：** 在 HTTP/1.1 中，客户端需要发送多个请求来获取网页中的所有资源，例如脚本、样式表和图片等。而 HTTP/2 支持服务器推送，服务器可以主动将与请求的资源相关的其他资源一起推送给客户端，减少了额外的请求延迟，提高了页面加载速度。
4.  **流量控制（Flow Control）：** HTTP/2 引入了流量控制机制，可以对数据流进行控制，防止发送方发送过多的数据导致接收方无法处理。这有助于平衡发送和接收之间的速度差异，提高了性能和稳定性。
5.  **优先级（Priority）：** HTTP/2 支持请求的优先级设置，可以告知服务器哪些请求更重要，服务器可以相应地优先处理重要的请求，提高了用户体验。

总体而言，HTTP/2 在性能、效率和用户体验方面有了显著的改进。它通过多路复用、头部压缩、服务器推送、流量控制和优先级等特性，减少了延迟、提高了吞吐量，加快了网页加载速度，提供了更好的性能和效率。

### 9、HTTP/2存在什么问题，为什么需要HTTP/3？

尽管 HTTP/2 在性能和效率方面带来了显著的改进，但它仍然存在一些问题，这些问题促使了 HTTP/3 的出现。以下是一些 HTTP/2 存在的问题：

1.  **依赖于 TCP 协议：** HTTP/2 是在 TCP 协议之上构建的，而 TCP 协议在高延迟和不可靠的网络环境下存在一些问题。当出现丢包或网络拥塞时，TCP 使用的拥塞控制机制会导致连接的延迟增加，从而影响性能。
2.  **队头阻塞（Head-of-Line Blocking）：** HTTP/2 使用多路复用技术，但在一个连接上的多个请求和响应共享同一个传输通道。如果其中一个请求或响应出现延迟或丢失，将会阻塞后续的请求和响应，这被称为队头阻塞。这可能导致其他请求受到影响，影响了整体性能。
3.  **部署复杂性：** HTTP/2 的实施相对复杂，需要对服务器和客户端进行更新以支持新的协议。这可能导致一些兼容性和部署问题，使得采用 HTTP/2 变得相对困难。

为了解决这些问题，HTTP/3 应运而生，它采用了全新的传输协议——QUIC（Quick UDP Internet Connections）。HTTP/3 基于 UDP 协议，而不是 TCP，以提供更好的性能和可靠性。以下是为什么需要 HTTP/3 的一些原因：

1.  **解决 TCP 的问题：** QUIC 作为传输层协议，克服了 TCP 的一些问题，如连接建立的延迟、队头阻塞和拥塞控制机制。QUIC 使用自己的拥塞控制算法，可以更快地适应网络状况的变化，并提供更好的性能。
2.  **减少延迟：** HTTP/3 使用 QUIC 协议，通过减少握手时间和降低队头阻塞的影响，可以显著减少延迟。这对于实时通信、视频流和移动应用等对低延迟要求较高的场景非常重要。
3.  **更好的并发性：** HTTP/3 在一个连接上可以同时处理多个请求和响应，避免了队头阻塞的问题。这提供了更好的并发性和吞吐量，提高了性能。
4.  **更好的适应性：** HTTP/3 的部署相对简单，因为它使用了现有的 UDP 协议。它可以更容易地通过 NAT 和防火墙，适应多样化的网络环境。

总的来说，HTTP/3 通过引入 QUIC 协议，解决了 HTTP/2 存在的一些问题，如 TCP 的限制和队头阻塞。它提供了更好的性能、更低的延迟和更好的并发性，同时具有更好的适应性和部署简单性。

### 10、Cookie，Session，Token的区别是什么？

Cookie、Session 和 Token 都是用于在 Web 应用程序中管理用户身份验证和状态的方式，但它们在实现和使用上有一些区别。以下是它们之间的主要区别：

1.  **Cookie：**
    -   Cookie 是一小段文本信息，由服务器发送到用户的浏览器，并存储在用户的本地计算机上。
    -   主要用于在浏览器和服务器之间存储少量数据，通常用于身份验证、用户偏好设置、跟踪用户活动等。
    -   Cookie 存储在客户端，可以在浏览器中设置过期时间，以及作用域（可以限定在特定的域名或路径下）。
    -   可以被浏览器禁用或删除，且可能存在安全性问题，如跨站点脚本（XSS）攻击和跨站请求伪造（CSRF）攻击。
2.  **Session：**
    -   Session 是服务器端存储的用户信息，通过一个唯一的会话标识（Session ID）与客户端进行关联。
    -   当用户访问服务器时，服务器会创建一个新的 Session，并分配一个唯一的 Session ID，将用户数据存储在服务器上，而不是在用户的浏览器中。
    -   Session 数据存储在服务器上，通常在内存、数据库或缓存中，因此相对安全，但会占用服务器资源。
    -   Session 常用于存储敏感信息，如用户身份验证状态、购物车内容等。
3.  **Token：**
    -   Token 是一种令牌，通常是一个加密的字符串，用于验证用户身份和授权。
    -   在基于令牌的身份验证中，用户在登录后会收到一个令牌，将其保存在客户端（通常是本地存储或 Cookie）中，并在每次请求时将令牌发送给服务器。
    -   服务器使用密钥验证令牌的有效性，从而确定用户身份和权限。
    -   令牌可以在客户端存储，不需要在服务器上维护会话状态，因此适用于分布式系统和无状态应用。

总结起来：

-   Cookie 是在客户端存储的小段文本数据，通常用于存储用户偏好和跟踪用户活动。
-   Session 是服务器端存储的用户数据，通过唯一的会话标识与客户端关联，常用于存储敏感信息。
-   Token 是一种令牌，用于验证用户身份和授权，适用于无状态应用和分布式系统。

选择使用哪种方法取决于应用程序的需求和安全性考虑。

### 11、HTTPS只是比HTTP安全吗？

HTTPS（Hypertext Transfer Protocol Secure）不仅仅是比 HTTP（Hypertext Transfer Protocol）更安全，而且它提供了一系列安全性和保护机制，以确保在 Web 通信中的数据保密性、完整性和身份验证。以下是 HTTPS 相对于 HTTP 的主要安全改进：

1.  **数据加密：** HTTPS 使用 SSL（Secure Sockets Layer）或 TLS（Transport Layer Security）协议对传输的数据进行加密。这意味着在数据从客户端发送到服务器的过程中，第三方无法轻易地截取、窃听或篡改数据。加密保护了用户的敏感信息，如登录凭据、支付信息等。
2.  **身份验证：** HTTPS 通过使用数字证书对服务器进行身份验证。数字证书由受信任的证书颁发机构（Certificate Authority，CA）签发，用于证明服务器的身份。这样，用户可以确信他们正在与合法的服务器通信，而不是被冒充的恶意服务器。
3.  **数据完整性：** HTTPS 使用加密算法和消息认证码（Message Authentication Code，MAC）来确保数据在传输过程中没有被篡改或损坏。接收方可以验证数据的完整性，以确保数据的原始性和完整性。
4.  **信任度和安全指示：** 浏览器在使用 HTTPS 连接时会显示安全指示，如绿色锁图标、网站名称旁边的“安全”标签等。这些指示向用户传达了对网站的信任和数据的保护，帮助用户识别安全的网站并减少受到网络攻击的风险。
5.  **防止窃听和篡改：** HTTPS 的加密机制防止了中间人攻击（Man-in-the-Middle Attack），其中攻击者可以窃听、篡改或伪造通信内容。通过加密和身份验证，HTTPS 提供了更高的安全性，使得中间人攻击变得更加困难。

总而言之，HTTPS 不仅仅是比 HTTP 更安全，它通过加密通信、身份验证、数据完整性和安全指示等机制，提供了更高级别的保护，确保用户的数据在传输过程中得到保密、完整和安全。因此，在涉及敏感信息传输的场景中，使用 HTTPS 是非常重要和推荐的。

### 12、浏览器输入www\.baidu.com回车之后发生了什么

当在浏览器中输入 "[www.baidu.com](http://www.baidu.com/ "www.baidu.com")" 并按下回车之后，以下是大致的步骤和过程：

1.  **域名解析：** 浏览器首先会将 "[www.baidu.com](http://www.baidu.com/ "www.baidu.com")" 解析为 IP 地址。它会检查本地 DNS 缓存，如果找到了对应的 IP 地址，则跳过后续步骤。如果没有找到，则浏览器会向本地计算机的 DNS 解析器发送查询请求。
2.  **DNS 查询：** 本地计算机的 DNS 解析器会收到浏览器发送的 DNS 查询请求，并尝试解析域名 "[www.baidu.com"。如果本地解析器缓存中有对应的记录，则返回解析结果给浏览器。如果没有缓存记录，则本地解析器会向根域名服务器发送查询请求。](http://www.baidu.com".xn--,-kq6an9j8ufda12ezrp2m6yebybw1ngmcn95b4nan2cka4qoa538yx85bmqyb2da60d858m0sana655jdh3a.xn--,-436au9gupq1cik1a409bea80rdxcqxiu4go7pd91aec81a81dkgt8chycs78b43b8v5rlrqck1jdkb2q505g./ "www.baidu.com\"。如果本地解析器缓存中有对应的记录，则返回解析结果给浏览器。如果没有缓存记录，则本地解析器会向根域名服务器发送查询请求。")
3.  **递归查询：** 根域名服务器收到查询请求后，会返回给本地解析器一个对应的顶级域名服务器的 IP 地址。本地解析器再次向顶级域名服务器发送查询请求。
4.  **迭代查询：** 顶级域名服务器收到查询请求后，会返回给本地解析器一个次级域名服务器的 IP 地址。本地解析器再次向次级域名服务器发送查询请求。
5.  **迭代查询继续：** 这个过程会一直进行下去，直到本地解析器获得了最终的目标服务器的 IP 地址。
6.  **建立 TCP 连接：** 一旦浏览器获得了目标服务器的 IP 地址，它会使用 HTTP 协议中的默认端口（80）或 HTTPS 协议中的默认端口（443）与服务器建立 TCP 连接。
7.  **发送 HTTP 请求：** 浏览器通过建立的 TCP 连接向服务器发送一个 HTTP 请求。这个请求包含了请求的方法（如 GET、POST）、请求的路径（如 "/"）以及其他的头部信息（如用户代理、Cookie 等）。
8.  **服务器处理请求：** 服务器收到浏览器发送的请求后，会根据请求的路径和其他信息来处理请求。对于百度的首页请求，服务器会返回相应的 HTML 页面。
9.  **服务器响应：** 服务器处理完请求后，会生成一个 HTTP 响应。响应包括响应的状态码（如 200 表示成功）、响应的内容（如 HTML 页面）以及其他的头部信息（如响应的日期、内容类型等）。
10.  **接收和渲染页面：** 浏览器收到服务器的响应后，会解析响应内容并渲染页面。它会将 HTML 解析为 DOM（文档对象模型），加载和显示页面中的其他资源（如 CSS、JavaScript、图像等）。
11.  **断开连接：** 页面渲染完成后，浏览器和服务器之间的 TCP 连接会被断开。

以上是一个简化的描述，实际的过程可能还涉及到其他的细节和步骤。但总体上，这些步骤描述了当在浏览器中输入 "[www.baidu.com](http://www.baidu.com/ "www.baidu.com")" 并按下回车后，浏览器如何解析域名、建立连接、发送请求、接收响应和渲染页面的过程。

### 13、对称加密和非对称加密有什么区别？

对称加密和非对称加密是两种常见的加密算法，它们在加密和解密数据时有一些重要的区别：

**对称加密：**

-   使用相同的密钥（称为密钥）来进行加密和解密数据。
-   加密和解密的过程速度较快，因为使用的算法相对简单。
-   对称加密适用于大量数据的加密，如文件传输。
-   密钥的管理相对较为复杂，需要确保密钥的安全性，防止未授权的人获取密钥。
-   常见的对称加密算法有 DES（Data Encryption Standard）、AES（Advanced Encryption Standard）等。

**非对称加密：**

-   使用一对密钥，分别是公钥和私钥。公钥用于加密数据，私钥用于解密数据。
-   加密和解密的过程相对较慢，因为使用的算法相对复杂。
-   非对称加密适用于安全性要求较高的场景，如身份验证、数字签名等。
-   公钥可以公开分发，而私钥必须保密保存。
-   常见的非对称加密算法有 RSA（Rivest-Shamir-Adleman）、DSA（Digital Signature Algorithm）等。

总结起来，对称加密使用相同的密钥进行加密和解密，速度快但密钥管理复杂；非对称加密使用不同的密钥进行加密和解密，安全性高但速度较慢。通常的做法是，对称加密用于加密大量的数据，而非对称加密用于安全性要求较高的场景，例如建立安全的通信渠道、数字签名等。在实际应用中，通常会将对称加密和非对称加密结合起来使用，以兼顾效率和安全性。

### 14、简单介绍一下DNS？

DNS（Domain Name System，域名系统）是互联网中用于将人类可读的域名转换为计算机可理解的IP地址的一种系统。它充当了互联网上的“电话簿”，使用户能够通过易于记忆的域名访问网站，而不必记住复杂的IP地址。

以下是 DNS 的基本工作原理和组成部分：

1.  **域名结构：** 域名按照层次结构划分，从右到左逐级具有不同的层级。例如，"[www.example.com](http://www.example.com/ "www.example.com")" 中，顶级域是 ".com"，次级域是 "example"，子域是 "www"。
2.  **域名解析：** 当用户在浏览器中输入一个域名，比如 "[www.example.com"，操作系统或浏览器会向本地计算机的](http://www.example.xn--com",-so5k9st09ahogwqcg73d76hkijpg439gm21befuhlgo4kxt6d84i/ "www.example.com\"，操作系统或浏览器会向本地计算机的") DNS 解析器发送查询请求，以获取该域名对应的IP地址。
3.  **DNS解析过程：** 如果本地解析器的缓存中没有目标域名的IP地址，它会执行以下步骤：
    -   **递归查询：** 本地解析器向根域名服务器发送查询请求，根服务器会返回顶级域名服务器的IP地址。
    -   **迭代查询：** 本地解析器继续向顶级域名服务器发送查询请求，获得次级域名服务器的IP地址。
    -   **继续迭代：** 这个过程会一直持续下去，直到本地解析器获取了目标域名的IP地址。
4.  **响应缓存：** 本地解析器在解析域名后，会将结果缓存一段时间。这样，如果再次有相同域名的查询，就可以直接从缓存中获取结果，加快访问速度。
5.  **记录类型：** DNS查询可以返回多种类型的记录，包括：
    -   A记录：将域名映射到IPv4地址。
    -   AAAA记录：将域名映射到IPv6地址。
    -   CNAME记录：将域名指向另一个域名。
    -   MX记录：指定邮件服务器的地址。
    -   NS记录：指定管理特定区域的域名服务器。

DNS在互联网中起着至关重要的作用，它不仅使人们能够通过易于记忆的域名访问网站，还支持电子邮件、域名注册等多种互联网服务。然而，由于其核心的分布式特性，DNS也需要关注安全性和性能方面的问题。

### 15、ping的原理是什么？

Ping是一种常用的网络工具，用于测试主机之间的连通性和测量网络延迟。它基于ICMP（Internet Control Message Protocol，互联网控制报文协议）来实现。

以下是Ping的基本工作原理：

1.  发送ICMP Echo请求：当用户在命令行中执行ping命令，并指定目标主机的IP地址或域名时，操作系统会创建一个ICMP Echo请求报文。
2.  封装ICMP报文：ICMP Echo请求报文包含一个特定的标识符和序列号，以及一些其他的控制信息。操作系统将ICMP报文封装在IP数据包中，设置目标IP地址为目标主机的IP地址。
3.  发送数据包：操作系统将封装好的IP数据包发送到本地网络接口，通过网络传输到目标主机。
4.  目标主机的响应：目标主机接收到ICMP Echo请求后，会检查目标IP地址是否与自己匹配。如果匹配，则生成一个ICMP Echo响应报文。
5.  返回响应数据包：目标主机将ICMP Echo响应报文封装在IP数据包中，并将数据包发送回源主机的IP地址。
6.  源主机接收响应：源主机接收到ICMP Echo响应后，会检查标识符和序列号是否与发送的请求匹配。如果匹配，则认为目标主机可达，并计算往返时间（Round-Trip Time，RTT）。

Ping的原理基于ICMP协议，它通过发送Echo请求并接收Echo响应来测试主机之间的连通性。Ping命令通常用于诊断网络问题、测量网络延迟和检查主机的可达性。通过比较发送请求和接收响应之间的时间差，可以估计网络的延迟情况。

### 16、什么是IPV6？和IPV4有什么区别？

IPv6（Internet Protocol version 6，互联网协议第6版）是互联网上的一种网络协议，用于为设备分配唯一的IP地址以及进行数据包传输。它是IPv4（Internet Protocol version 4，互联网协议第4版）的继任者。IPv6的引入主要是为了解决IPv4地址空间不足、支持更多的设备连接以及提供更好的网络性能和安全性等问题。

主要的区别如下：

1.  **地址空间：** 最显著的区别是IPv6提供了远远超过IPv4的地址空间。IPv4使用32位地址，最多支持约42亿个不同的IP地址，而IPv6采用128位地址，可支持的地址数量极其庞大，约为3.4 x 10^38个。这解决了IPv4中地址短缺的问题，使每个设备都能够拥有唯一的IP地址。
2.  **地址表示：** IPv6地址使用冒号分隔的8组16进制数表示，例如：2001:0db8:85a3:0000:0000:8a2e:0370:7334。为了缩短表示，IPv6允许省略前导零，以及连续的零块。IPv4则使用点分十进制表示，例如：192.168.1.1。
3.  **自动配置：** IPv6支持更强大的自动地址配置机制，设备可以通过Router Advertisement（路由器通告）协议自动获取IP地址和其他网络配置信息，从而简化了网络设置。
4.  **安全性：** IPv6在设计时考虑了更多的安全性特性，包括内置的IPSec（Internet Protocol Security，互联网协议安全）支持，可以更轻松地实现网络通信的加密和认证。
5.  **移动性支持：** IPv6更好地支持移动设备，有助于实现无缝漫游和移动IP地址的更改。
6.  **流量控制和质量服务：** IPv6引入了更灵活和精细的流量控制和质量服务机制，有助于提供更稳定和高效的网络传输。
7.  **NAT（Network Address Translation）：** 在IPv4中，由于地址短缺，常常需要使用NAT来将多个设备共享单个公共IP地址。在IPv6中，地址数量充足，减少了对NAT的需求，有助于简化网络配置。

尽管IPv6带来了许多优势，但由于网络基础设施的升级以及应用程序和设备的适配等问题，目前全球网络仍然广泛使用IPv4。然而，随着时间的推移，IPv6的推广和采用逐渐增加，以满足不断增长的互联网连接需求。

### 17、什么是正向代理和反向代理？

正向代理（Forward Proxy）和反向代理（Reverse Proxy）是两种常见的代理服务器配置，用于在客户端和目标服务器之间进行中间转发和处理。

**正向代理：** 正向代理是位于客户端和目标服务器之间的代理服务器。当客户端发送请求时，请求首先被发送到正向代理服务器，然后由代理服务器转发请求到目标服务器，并将响应返回给客户端。客户端通常需要配置代理服务器的地址和端口，以便与目标服务器通信。

正向代理的主要功能包括：

1.  隐藏客户端的真实IP地址：客户端的请求被代理服务器转发，目标服务器只能看到代理服务器的IP地址，无法直接获取客户端的真实IP地址。
2.  访问控制和过滤：代理服务器可以实施访问控制策略，限制客户端对目标服务器的访问。它还可以过滤请求和响应，对流量进行审查和修改。
3.  缓存：代理服务器可以缓存目标服务器的响应，以减轻目标服务器的负载并提高响应速度。
4.  加速和优化：代理服务器可以对请求和响应进行优化，例如压缩、加密、负载均衡等，以提供更快的访问速度和更好的性能。

**反向代理：** 反向代理是位于目标服务器和客户端之间的代理服务器。当客户端发送请求时，请求首先被发送到反向代理服务器，然后由代理服务器将请求转发到一个或多个目标服务器，最后将目标服务器的响应返回给客户端。客户端不需要知道目标服务器的存在，只需要与反向代理服务器通信。

反向代理的主要功能包括：

1.  负载均衡：反向代理可以将请求分发到多个目标服务器，以平衡服务器负载，提高系统的可扩展性和容错性。
2.  安全性和保护：反向代理可以充当防火墙，保护目标服务器免受恶意请求和攻击，例如DDoS攻击。
3.  缓存和加速：反向代理可以缓存目标服务器的响应，以提供更快的访问速度和更好的性能。
4.  SSL加密和解密：反向代理可以处理SSL/TLS加密和解密，减轻目标服务器的负载。

总结： &#x20;
正向代理是代理客户端的请求，代表客户端与目标服务器通信；而反向代理是代理目标服务器的响应，代表目标服务器与客户端通信。两者在网络架构中扮演不同的角色，提供不同的功能和优势。

### 18、什么是跨域访问问题，如何解决？

跨域访问问题（Cross-Origin Resource Sharing，CORS）是由浏览器的同源策略引起的。同源策略是一种安全机制，它限制了一个网页中的脚本只能访问同源（相同协议、域名和端口）的资源，防止恶意网站通过脚本访问其他网站的数据。

当网页中的 JavaScript 代码尝试从一个源（域）请求另一个源的资源时，浏览器会发出跨域请求，如果目标资源的服务器没有正确配置跨域访问策略，浏览器会阻止该请求，从而导致跨域访问问题。

为了解决跨域访问问题，可以采取以下方法：

1.  **服务器端设置响应头：**目标服务器可以在响应中设置特定的响应头来允许跨域访问。常见的响应头是"Access-Control-Allow-Origin"，它指定允许访问资源的域。服务器可以设置该头为特定的域名，或使用通配符" *"表示允许任意域名进行访问。例如，设置响应头："Access-Control-Allow-Origin:* "
2.  **请求时添加额外的头信息：** 发起跨域请求时，可以在请求中添加一些额外的头信息，例如"Origin"头，用于告知服务器请求的来源。服务器可以根据该头信息来判断是否允许跨域访问，并设置相应的响应头。
3.  **使用代理：** 可以在自己的服务器上设置代理，将跨域请求转发到目标服务器。客户端与自己的服务器进行通信，而自己的服务器与目标服务器进行通信，从而避免了浏览器的跨域限制。
4.  **JSONP（JSON with Padding）：** JSONP是一种跨域访问的解决方案，它通过在页面中动态创建`<script>`标签，将跨域请求转换为对一个包含回调函数的URL的请求。服务器返回的响应会被包裹在回调函数中，从而实现跨域数据的获取。
5.  **CORS代理：** 可以使用CORS代理服务器，将跨域请求发送到代理服务器，代理服务器再将请求发送到目标服务器，并将响应返回给客户端。这样客户端与代理服务器之间是同源的，避免了跨域问题。

需要注意的是，解决跨域访问问题需要在目标服务器上进行配置或采取相应的措施，因为同源策略是由浏览器实施的安全机制。另外，一些高级的跨域访问场景可能需要更复杂的解决方案，如使用WebSocket、跨域资源嵌入（Cross-Origin Resource Embedding，CORE）等。

### 19、什么是CDN，为什么他可以做缓存？

CDN，全称为内容分发网络（Content Delivery Network），是一种分布式网络架构，旨在加速网站和应用程序的内容传输，提高用户访问体验和性能。CDN通过将内容部署到全球各地的服务器节点上，使用户可以从距离更近的服务器获取所需的资源，从而减少延迟和网络拥塞。

CDN的工作原理如下：

1.  **缓存：** CDN服务器会缓存网站的静态资源，如图片、CSS、JavaScript文件等，将这些资源复制到分布在全球各地的服务器节点上。
2.  **就近访问：** 当用户访问网站时，请求会被路由到距离用户最近的CDN节点，该节点会检查是否有所需的缓存内容。如果有缓存，就直接返回缓存的资源，减少了从源服务器请求资源的时间和延迟。
3.  **动态负载均衡：** 如果CDN节点没有所需的缓存内容，它会根据一定的负载均衡算法将请求转发到源服务器，从中获取内容。这样可以分担源服务器的负载，提高整体性能。
4.  **内容更新：** 当源服务器的内容发生变化时，CDN会根据设置的策略进行内容更新。新的内容会被传送到CDN节点，从而保持内容的最新状态。

CDN之所以能够做缓存，主要是因为它能够将静态资源复制到分布在各地的服务器节点上，并将这些资源保存在节点的缓存中。这样做带来了以下优势：

1.  **降低延迟：** 用户从距离更近的CDN节点获取资源，减少了数据传输的时间，从而降低了延迟，提高了网站的响应速度。
2.  **减轻源服务器负载：** 缓存静态资源的CDN节点可以减轻源服务器的负载，使其能够更专注地处理动态请求，提高了整体的性能和稳定性。
3.  **抵御突发流量：** CDN节点可以分散突发的用户请求，使源服务器不容易被突发的大量访问所压垮。
4.  **提高可用性：** CDN的分布式架构提高了内容的可用性，即使某个节点发生故障，仍然可以从其他节点获取内容。

总的来说，CDN通过缓存静态资源、就近访问、负载均衡等方式，显著地改善了网站和应用程序的性能，提高了用户体验，同时降低了源服务器的负载。





#                                          消息队列

## RabbitMQ

### 1、简述RabbitMQ的架构设计

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\消息队列\RabbitMQ\image\图片_paZFSkkOAR.png)

**Broker**：rabbitmq的服务节点&#x20;

**Queue**：队列，是RabbitMQ的内部对象，用于存储消息。RabbitMQ中消息只能存储在队列中。生产者投递消息到队列，消费者从队列中获取消息并消费。多个消费者可以订阅同一个队列，这时队列中的消息会被平均分摊(轮询)给多个消费者进行消费，而不是每个消费者都收到所有的消息进行消费。(注意：RabbitMQ不支持队列层面的广播消费，如果需要广播消费，可以采用一个交换器通过路由Key绑定多个队列，由多个消费者来订阅这些队列的方式。

**Exchange**：交换器。生产者将消息发送到Exchange，由交换器将消息路由到一个或多个队列中。如果路由不到，或返回给生产者，或直接丢弃，或做其它处理。

**RoutingKey**：路由Key。生产者将消息发送给交换器的时候，一般会指定一个RoutingKey，用来指定这个消息的路由规则。这个路由Key需要与交换器类型和绑定键(BindingKey)联合使用才能最终生效。在交换器类型和绑定键固定的情况下，生产者可以在发送消息给交换器时通过指定。RoutingKey来决定消息流向哪里。

**Binding**：通过绑定将交换器和队列关联起来，在绑定的时候一般会指定一个绑定键，这样RabbitMQ就可以指定如何正确的路由到队列了。

交换器和队列实际上是多对多关系。就像关系数据库中的两张表。他们通过BindingKey做关联(多对多关系表)。在投递消息时，可以通过Exchange和RoutingKey(对应BindingKey)就可以找到相对应的队列。

**信道**：信道是建立在Connection 之上的虚拟连接。当应用程序与Rabbit Broker建立TCP连接的时候，客户端紧接着可以创建一个AMQP 信道(Channel) ，每个信道都会被指派一个唯一的ID。RabbitMQ 处理的每条AMQP 指令都是通过信道完成的。信道就像电缆里的光纤束。一条电缆内含有许多光纤束，允许所有的连接通过多条光线束进行传输和接收。

### 2、介绍一下RabbitMQ有几种工作模式？

RabbitMQ是一种流行的消息中间件，它支持多种工作模式，以满足不同的消息传递需求。以下是RabbitMQ中常见的几种工作模式：

1.  **简单模式（Simple Queue）**：
    -   也被称为点对点模式。
    -   在这种模式下，有一个生产者（Producer）将消息发送到队列（Queue），然后有一个消费者（Consumer）从队列中接收和处理消息。
        ![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\消息队列\RabbitMQ\image\图片_zneOp4sqSb.png)

应用场景： 将发送的电子邮件放到消息队列，然后邮件服务在队列中获取邮件并发送给收件人

2.**工作队列模式（Work queues**）

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\消息队列\RabbitMQ\image\图片_gfHwsbYi6n.png)

在多个消费者之间分配任务（竞争的消费者模式），一个生产者对应多个消费者，一般适用于执行资源密集型任务，单个消费者处理不过来，需要多个消费者进行处理。

应用场景： 一个订单的处理需要10s，有多个订单可以同时放到消息队列，然后让多个消费者同时处理，这样就是并行了，而不是单个消费者的串行情况。

**3.发布订阅模式（Publish/Subscribe）**

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\消息队列\RabbitMQ\image\图片_Es-BcjtkSM.png)

一次向许多消费者发送消息，一个生产者发送的消息会被多个消费者获取，也就是将消息将广播到所有的消费者中。

应用场景： 更新商品库存后需要通知多个缓存和多个数据库，这里的结构应该是：

-   一个fanout类型交换机扇出两个个消息队列，分别为缓存消息队列、数据库消息队列
-   一个缓存消息队列对应着多个缓存消费者
-   一个数据库消息队列对应着多个数据库消费者

4、**路由模式（Routing**）

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\消息队列\RabbitMQ\image\图片_L05umrKY3_.png)

有选择地（Routing key）接收消息，发送消息到交换机并且要指定路由key ，消费者将队列绑定到交换机时需要指定路由key，仅消费指定路由key的消息

应用场景： 如在商品库存中增加了1台iphone12，iphone12促销活动消费者指定routing key为iphone12，只有此促销活动会接收到消息，其它促销活动不关心也不会消费此routing key的消息。

5、**主题模式（Topics**）

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\消息队列\RabbitMQ\image\图片__BbV1yX1l7.png)

根据主题（Topics）来接收消息，将路由key和某模式进行匹配，此时队列需要绑定在一个模式上，#匹配一个词或多个词，\*只匹配一个词。

应用场景： 同上，iphone促销活动可以接收主题为iphone的消息，如iphone12、iphone13等。

6、**发布者确认（Publisher Confirms）**

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\消息队列\RabbitMQ\image\图片_CUVH0UmPq8.png)

与发布者进行可靠的发布确认，发布者确认是RabbitMQ扩展，可以实现可靠的发布。在通道上启用发布者确认后，RabbitMQ将异步确认发送者发布的消息。

应用场景： 对于消息可靠性要求较高，比如钱包扣款。而一旦我们使用了消息队列，我们基本都要保证消息的百分百投递，因此建议使用的时候尽量选择该模式。

**7、RPC(这种模式用的很少)**

### 3 **、RabbitMQ如何确保消息发送 ？ 消息接收？**

**即消息百分百投递问题。**

**发送方确认机制**：

信道需要设置为 confirm 模式，则所有在信道上发布的消息都会分配一个唯一 ID。

一旦消息被投递到queue（可持久化的消息需要写入磁盘），信道会发送一个确认给生产者（包含消息唯一ID）。如果消息和队列是可持久化的，那么确认消息会在将消息写入磁盘之后发出。

如果 RabbitMQ 发生内部错误从而导致消息丢失，会发送一条 nack（未确认）消息给生产者。

所有被发送的消息都将被 confirm（即 ack） 或者被nack一次。但是没有对消息被 confirm 的快慢做任何保证，并且同一条消息不会既被 confirm又被nack。

发送方确认模式是异步的，生产者应用程序在等待确认的同时，可以继续发送消息。当确认消息到达生产者，生产者的回调方法会被触发来处理该确认消息，如果RabbitMQ因为自身内部错误导致消息丢失，就会发送一条nack消息，生产者应用程序同样可以在回调方法中处理该nack消息。

ConfirmCallback接口：只确认是否正确到达 Exchange 中，成功到达则回调。

ReturnCallback接口：消息失败返回时回调

**接收方确认机制：**

消费者在声明队列时，可以指定noAck参数，当noAck=false时，RabbitMQ会等待消费者显式发回ack信号后才从内存(或者磁盘，持久化消息)中移去消息。否则，消息被消费后会被立即删除。
消费者接收每一条消息后都必须进行确认（消息接收和消息确认是两个不同操作）。只有消费者确认了消息，RabbitMQ 才能安全地把消息从队列中删除。

RabbitMQ不会为未ack的消息设置超时时间，它判断此消息是否需要重新投递给消费者的唯一依据是消费该消息的消费者连接是否已经断开。这么设计的原因是RabbitMQ允许消费者消费一条消息的时间可以很长。保证数据的最终一致性；

如果消费者返回ack之前断开了链接，RabbitMQ 会重新分发给下一个订阅的消费者。（可能存在消息重复消费的隐患，需要去重）；

&#x20;**消息队列本身**

可以进行消息持久化, 即使rabbitMQ挂了，重启后也能恢复数据

如果要进行消息持久化，那么需要对以下3种实体均配置持久化

a) Exchange

声明exchange时设置持久化（durable = true）并且不自动删除(autoDelete = false)

b) Queue

声明queue时设置持久化（durable = true）并且不自动删除(autoDelete = false)

c) message

发送消息时通过设置deliveryMode=2持久化消息

### 4、RabbitMQ事务消息

**通过对信道的设置实现**

1.  channel.txSelect()；通知服务器开启事务模式；服务端会返回Tx.Select-Ok
2.  channel.basicPublish；发送消息，可以是多条，可以是消费消息提交ack
3.  channel.txCommit()提交事务；
4.  channel.txRollback()回滚事务；

**消费者使用事务：**

1.  autoAck=false，手动提交ack，以事务提交或回滚为准；
2.  autoAck=true，不支持事务的，也就是说你即使在收到消息之后在回滚事务也是于事无补的，队列已经把消息移除了

如果其中任意一个环节出现问题，就会抛出IoException异常，用户可以拦截异常进行事务回滚，或决定要不要重复消息。事务消息会降低rabbitmq的性能。

### 5、RabbitMQ如何实现延迟消息？

RabbitMQ本身并不直接支持延迟消息的功能，但可以通过结合使用RabbitMQ的一些特性来实现延迟消息的效果。下面介绍两种常见的实现方式：

1.  利用消息的过期时间和死信队列（DLX）：这种方式可以通过设置消息的过期时间来实现延迟消息的效果。具体步骤如下：
    -   创建一个普通的交换机和队列用于接收延迟消息。
    -   设置队列的消息过期时间，可以通过设置队列的`x-message-ttl`参数或通过单独设置消息的`expiration`属性。
    -   设置队列的死信交换机和死信路键，将过期的消息发送到指定的死信交换机和路由键。
    -   创建一个死信交换机和队列，用于处理过期的消息。
    -   将队列绑定到死信交换机上，指定合适的路由键。
    -   发送延迟消息时，将消息发送到普通的交换机和队列。
        消息会在指定的过期时间后发送到死信交换机和队列，从而实现延迟消息的效果。
2.  使用RabbitMQ的延迟插件（rabbitmq\_delayed\_message\_exchange）：RabbitMQ社区提供了一个延迟插件，可以直接实现延迟消息的功能。具体步骤如下：
    -   下载并安装rabbitmq\_delayed\_message\_exchange插件。
    -   启用延迟插件，通过RabbitMQ的管理界面或命令行工具进行配置。
    -   创建一个延迟交换机和队列，将延迟插件应用到交换机上。
    -   发送延迟消息时，将消息发送到延迟交换机和队列，同时设置消息的延迟时间。
        延迟交换机会根据消息的延迟时间将消息发送到指定的目标队列，从而实现延迟消息的效果。

需要注意的是，以上两种方式都是通过消息的过期时间来实现延迟消息的，因此在使用时需要根据实际需求和性能考虑合适的延迟时间设置。另外，延迟消息的实现可能会增加系统的复杂性和消息的处理延迟，需要根据具体业务场景进行评估和选择。

### 6、RabbitMQ如何保证消息的顺序性？

消息队列中的若干消息如果是对同一个数据进行操作，这些操作具有前后的关系，必须要按前后的顺序执行，否则就会造成数据异常。举例： &#x20;
比如通过mysql binlog进行两个数据库的数据同步，由于对数据库的数据操作是具有顺序性的，如果操作顺序搞反，就会造成不可估量的错误。比如数据库对一条数据依次进行了 插入->更新->删除操作，这个顺序必须是这样，如果在同步过程中，消息的顺序变成了 删除->插入->更新，那么原本应该被删除的数据，就没有被删除，造成数据的不一致问题。

举例场景：

RabbitMQ：

①一个queue，有多个consumer去消费，这样就会造成顺序的错误，consumer从MQ里面读取数据是有序的，但是每个consumer的执行时间是不固定的，无法保证先读到消息的consumer一定先完成操作，这样就会出现消息并没有按照顺序执行，造成数据顺序错误。

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\消息队列\RabbitMQ\image\图片_hH1nSGMkZo.png)

②一个queue对应一个consumer，但是consumer里面进行了多线程消费，这样也会造成消息消费顺序错误。

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\消息队列\RabbitMQ\image\图片_ZZvD1vs-W3.png)

解决方案：

①拆分多个queue，每个queue一个consumer，就是多一些queue而已，确实是麻烦点；这样也会造成吞吐量下降，可以在消费者内部采用多线程的方式取消费。

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\消息队列\RabbitMQ\image\图片_BGSPAyxTpl.png)

一个queue对应一个consumer

②或者就一个queue但是对应一个consumer，然后这个consumer内部用内存队列做排队，然后分发给底层不同的worker来处理

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\消息队列\RabbitMQ\image\图片_wUfasKGG18.png)

一个queue对应一个consumer，采用多线程

### 7、如何使用RabbitMQ解决分布式事务？

**分布式事务：** 不同的服务操作不同的数据源（库或表），保证数据一致性的问题。

**解决：** 采用RabbitMQ消息最终一致性的解决方案，解决分布式事务问题。

分布式事务场景：

1、电商项目中的商品库和ES库数据同步问题。

2、电商项目中：支付----订单---库存，一系列操作，进行状态更改等。

在互联网应用中，基本都会有用户注册的功能。在注册的同时，我们会做出如下操作：

收集用户录入信息，保存到数据库向用户的手机或邮箱发送验证码等等…

如果是传统的集中式架构，实现这个功能非常简单：开启一个本地事务，往本地数据库中插入一条用户数据，发送验证码，提交事物。

但是在分布式架构中，用户和发送验证码是两个独立的服务，它们都有各自的数据库，那么就不能通过本地事物保证操作的原子性。这时我们就需要用到 RabbitMQ（消息队列）来为我们实现这个需求。

在用户进行注册操作的时候，我们为该操作创建一条消息，当用户信息保存成功时，把这条消息发送到消息队列。验证码系统会监听消息，一旦接受到消息，就会给该用户发送验证码。

### **8、如何防止RabbitMQ消息重复消费？**

保证消息幂等性。和保证接口幂等性一样。

RabbitMQ、RocketMQ、Kafka等任何队列不保证消息不重复，如果业务需要消息不重复消费，则需要消费端处理业务消息要保持幂等性

方式一：Redis的setNX() , 做消息id去重 java版本目前不支持设置过期时间。

```java
//Redis中操作，判断是否已经操作过 TODO

boolean flag = jedis.setNX(key);

if(flag){

//消费

}else{

//忽略，重复消费

} 
```

方式二：redis的 Incr 原子操作：key自增，大于0 返回值大于0则说明消费过，(key可以是消息的md5取值, 或者如果消息id设计合理直接用id做key)

```java
int num = jedis.incr(key);

if(num == 1){

//消费

}else{

//忽略，重复消费

}
```

方式三：数据库去重表

设计一个去重表，某个字段使用Message的key做唯一索引，因为存在唯一索引，所以重复消费会失败

```java
CREATE TABLE `message_record` ( `id` int(11) unsigned NOT NULL AUTO_INCREMENT, `key` varchar(128) DEFAULT NULL, `create_time` datetime DEFAULT NULL, PRIMARY KEY (`id`), UNIQUE KEY `key` (`key`) ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

方式四：数据库主键id唯一约束。（但是注意不能把主键id设置为了自增，因此需要生成一个唯一的全局id.作为主键）。

**方式五：利用消息队列自带的判断消息唯一性（在消费端）机制**

```java
如果判断该消息已经处理过一次 // getRedelivered() 判断是否已经处理过一次消息！ 
if (!message.getMessageProperties().getRedelivered()) {
 System.out.println("消息已重复处理,拒绝再次接收"); 
 // 拒绝消息 channel.basicReject(message.getMessageProperties().getDeliveryTag(), false); }
  else {
   System.out.println("该消息不是重复的");

channel.basicNack(message.getMessageProperties().getDeliveryTag(), false, true);

} 

```

**方式六：利用**Redis机制

**生产者：**

```java
public void sendMessage(){
    JSONObject jsonObject = new JSONObject();
    jsonObject.put("message","hello world");
    String json = jsonObject.toJSONString();
    Message message = MessageBuilder.withBody(json.getBytes()).setContentType(MessageProperties.CONTENT_TYPE_JSON).setContentEncoding("UTF-8").setMessageId(UUID.randomUUID()+"").build();
    amqpTemplate.convertAndSend("javatrip",message);
}
```

**消费者：**

```java
public class Consumer {

    @RabbitHandler
    public void receiveMessage(Message message) throws Exception {


        String messageId = message.getMessageProperties().getMessageId();
        String msg = new String(message.getBody(),"UTF-8");
        System.out.println("接收到的消息为："+msg+"==消息id为："+messageId);

        String messageIdRedis = redisTemplate.opsForValue().get("messageId")

        if(messageId == messageIdRedis){
            // 代表是重复的
            return;
        }
        JSONObject jsonObject = JSONObject.parseObject(msg);
        String email = jsonObject.getString("message");
        redisTemplate.opsForValue().set("messageId",messageId);
    }
}
```

### 9、如何解决消息队列的延时以及过期失效问题?消息队列满了之后该如何处理?有几百万的消息持续积压几小时,说说如何解决?

方案分析

该问题,其本质针对的场景，都是说，可能你的消费端出了问题，不消费了，或者消费的极其极其慢。另外还有可能你的消息队列集群的磁盘都快写满了，都没人消费，这个时候怎么办？或者是整个这就积压了几个小时，你这个时候怎么办？或者是你积压的时间太长了，导致比如rabbitmq设置了消息过期时间后就没了怎么办？

所以这种问题线上常见的，一般不出，一出就是大问题，一般常见于，举个例子，消费端每次消费之后要写mysql，结果mysql挂了，消费端挂掉了。导致消费速度极其慢。

分析1+话术

这个是我们真实遇到过的一个场景，确实是线上故障了，这个时候要不然就是修复consumer的问题，让他恢复消费速度，然后傻傻的等待几个小时消费完毕。(可行,但是不建议 在面试的时候说)

一个消费者一秒是1000条，一秒3个消费者是3000条，一分钟是18万条，1000多万条

所以如果你积压了几百万到上千万的数据，即使消费者恢复了，也需要大概1小时的时间才能恢复过来

一般这个时候，只能操作临时紧急扩容了，具体操作步骤和思路如下：

1）先修复consumer的问题，确保其恢复消费速度，然后将现有cnosumer都停掉

2）新建一个topic，partition是原来的10倍，临时建立好原先10倍或者20倍的queue数量

3）然后写一个临时的分发数据的consumer程序，这个程序部署上去消费积压的数据，消费之后不做耗时的处理，直接均匀轮询写入临时建立好的10倍数量的queue

4）接着临时征用10倍的机器来部署consumer，每一批consumer消费一个临时queue的数据

5）这种做法相当于是临时将queue资源和consumer资源扩大10倍，以正常的10倍速度来消费数据

6）等快速消费完积压数据之后，得恢复原先部署架构，重新用原先的consumer机器来消费消息

分析2+话术

rabbitmq是可以设置过期时间的，就是TTL，如果消息在queue中积压超过一定的时间就会被rabbitmq给清理掉，这个数据就没了。那这就是第二个坑了。这就不是说数据会大量积压在mq里，而是大量的数据会直接搞丢。

这个情况下，就不是说要增加consumer消费积压的消息，因为实际上没啥积压，而是丢了大量的消息。我们可以采取一个方案，就是批量重导，这个我们之前线上也有类似的场景干过。就是大量积压的时候，我们当时就直接丢弃数据了，然后等过了高峰期以后，比如大家一起喝咖啡熬夜到晚上12点以后，用户都睡觉了。

这个时候我们就开始写程序，将丢失的那批数据，写个临时程序，一点一点的查出来，然后重新灌入mq里面去，把白天丢的数据给他补回来。也只能是这样了。

假设1万个订单积压在mq里面，没有处理，其中1000个订单都丢了，你只能手动写程序把那1000个订单给查出来，手动发到mq里去再补一次

分析3+话术

如果走的方式是消息积压在mq里，那么如果你很长时间都没处理掉，此时导致mq都快写满了，咋办？这个还有别的办法吗？没有，谁让你第一个方案执行的太慢了，你临时写程序，接入数据来消费，消费一个丢弃一个，都不要了，快速消费掉所有的消息。然后走第二个方案，到了晚上再补数据吧。







#                                              分布式

## Cloud核心中间件

### **一、Nacos**

#### 1、注册中心如何选型？

选择注册中心时，需要考虑以下几个方面的因素：&#x20;

1.  高可用性：注册中心是服务治理的核心组件，因此高可用性是非常重要的。注册中心应该能够容忍单点故障，并且能够自动进行故障转移和恢复。
2.  性能和扩展性：注册中心需要能够处理大量的服务实例注册和查询请求，并保持较低的延迟。此外，注册中心还应该支持水平扩展，以应对日益增长的服务规模。
3.  数据一致性：注册中心应该保证数据的一致性，即使在面对网络分区或节点故障的情况下也能保持数据的可靠性和准确性。
4.  安全性：注册中心应该提供合适的安全机制，包括身份认证、访问控制和数据加密等，以保护服务实例的注册信息和通信数据的安全。
5.  功能和灵活性：注册中心应该提供丰富的功能，如服务发现、负载均衡、服务路由、健康检查等，还应该具备灵活的配置和扩展能力，以满足不同的业务需求。
6.  社区支持和生态系统：选择一个有活跃的社区和丰富的生态系统的注册中心，可以获得更好的技术支持和资源，以及更多的集成和扩展选项。

常见的注册中心选型包括：ZooKeeper、Consul、Etcd、Eureka等。每个注册中心都有其特点和优势，需要根据具体的业务需求和技术栈来选择适合的注册中心。同时，也可以考虑多个注册中心组合使用，以实现高可用性和灵活性的要求。

#### 2、什么是Nacos，主要用来作什么？

Nacos是一个开源的分布式服务注册和配置中心。它提供了服务注册、发现、配置和管理的能力，可以帮助开发者构建和管理微服务架构。

主要功能包括：

1.  服务注册与发现：Nacos充当了服务注册中心的角色，服务提供者通过向Nacos注册自己的服务，使得服务消费者能够方便地发现和调用服务。
2.  动态配置管理：Nacos提供了统一的配置管理功能，可以集中管理应用程序的配置信息。它支持动态刷新配置，可以在运行时动态修改应用程序的配置，而无需重启应用。
3.  服务路由与负载均衡：Nacos可以根据服务的健康状况和负载情况，动态地进行服务路由和负载均衡，以提供更好的服务质量和可用性。
4.  服务共享与版本管理：Nacos支持多租户的服务共享，不同的租户可以共享同一个服务。同时，Nacos还提供了版本管理功能，可以管理不同版本的服务。
5.  服务监控与治理：Nacos提供了服务的健康检查和监控功能，可以实时监控服务的状态和性能指标。此外，Nacos还提供了服务熔断、限流等治理能力，以提高系统的稳定性和可靠性。

总之，Nacos是一个功能强大的分布式服务注册和配置中心，它可以帮助开发者简化微服务架构的开发和管理工作，提高系统的弹性和可伸缩性。

#### 3、Nacos是AP的还是CP的？

Nacos是一个AP（可用性和分区容忍性）的系统。在分布式系统中，CAP定理指出，一个系统无法同时满足一致性（Consistency）、可用性（Availability）和分区容忍性（Partition tolerance）这三个特性。Nacos选择了AP模型，即在面对网络分区时，为了保证系统的可用性和分区容忍性，它牺牲了一致性。这意味着在网络分区的情况下，Nacos可能会出现数据的不一致性，但它能够保证服务的可用性和高效性。对于服务注册发现、配置管理等功能，Nacos提供了强大的可用性和灵活性，使得开发者能够便捷地构建和管理分布式系统。然而，在某些特定情况下，如果一致性是系统中最重要的特性，那么可能需要考虑选择其他CP模型的系统。

#### 4、Nacos如何实现的配置变化客户端可以感知到？

Nacos通过以下机制实现配置变化客户端可以感知到：

1.  长轮询（Long Polling）：客户端可以向Nacos发送一个长轮询请求，如果配置发生变化，Nacos会立即返回配置变化的通知给客户端。客户端在收到通知后可以及时更新本地配置。
2.  客户端缓存：Nacos客户端会在本地缓存配置信息，定期从Nacos服务器拉取最新的配置。当Nacos服务器上的配置发生变化时，客户端会通过定时任务或者其他方式从Nacos服务器获取最新的配置。
3.  事件通知机制：Nacos会将配置变更事件发布给订阅了该配置的客户端。客户端可以订阅特定的配置，当该配置发生变化时，Nacos会发送事件通知给客户端，客户端收到通知后可以进行相应的处理。

通过以上机制，Nacos实现了配置变化的实时感知。客户端可以根据自身的需求选择适合的方式来获取配置变化的通知，并进行相应的处理。这样，当配置发生变化时，客户端可以及时更新配置，实现配置的动态管理。

#### 5、Nacos能同时实现AP和CP的原理是什么？

Nacos能够同时实现AP（可用性和分区容忍性）和CP（一致性和分区容忍性）的原理是通过引入不同的组件和机制来实现的。

在Nacos中，服务注册和发现模块采用了AP模型，通过将服务实例的注册信息存储在多个节点上，实现了服务的高可用性和分区容忍性。当某个节点发生故障或网络分区时，其他节点仍然可以提供服务注册和发现的功能。

而配置管理模块则采用了CP模型，通过使用Raft协议来实现一致性。当客户端更新配置时，Nacos会将配置写入多个节点的Raft日志中，经过多数节点的确认后才会认为配置写入成功。这保证了配置的一致性。在配置变更时，通过Raft协议的复制机制，确保配置变更在集群中的所有节点上同步，保证了配置的一致性和可靠性。

通过这种方式，Nacos在不同的模块中根据需求选择了合适的一致性和可用性模型，从而同时实现了AP和CP的特性。这使得Nacos能够满足分布式系统在服务注册、发现和配置管理等方面的需求，提供高可用性、弹性和可靠性的服务。

#### 6、Nacos服务发现的原理

服务发现：

调用方在第一去发起远程调用的时候，会把远程的服务以及该服务的实例都缓存到本地Map中，当后面在去发起远程调用的时候，就会优先查询本地Map,如果本地Map有，那么直接根据本地Map的数据，去发起远程调用，如若没有，才像远程（Nacos）发送一个请求:/nacos/v1/ns/list.获取到远程数据在同步到缓存。

有了本地缓存机制，就可以保证我未来发起远程调用的时候，更快。但是会带来数据一致性问题。

如何解决本地缓存和远程数据一致性问题：

**1、被动定时拉取**，每隔10s钟会发起一个查询（远程Nacos）最新数据，来同步本地Map这样做虽然能够解决最终这两份数据是一致的，但是在这一次定时任务和下一次定时任务开始之间，远程注册表发生了变化，那么就获取不到远程（Nacos）最新。而对于定时任务发请求去要远程数据这个环节走的是tcp协议，而用了

tcp协议之后就可以保证数据包不丢失。但是tcp协议会有三次握手和四次挥手，因此从效率来说，会慢一些。

初始化1s执行这个定时任务，如果在某一次找远程要的时候没有出现异常，那么这个任务每隔10s会继续执行，但是如果在找远程要数据的时候，出现了异常，那么这个时间就会从2s开始,最多到1min钟结束。

**2、主动推送更新**，一旦远程注册表发生了改变，那么Nacos服务端会主动发送一个事件，并且使用的是udp协议来发送的，接着我客户端只要订阅了这个udp的端口，那么就会让客户端主动去找远程Nacos获取最新的注册表。

upd协议：快，（因为没有三次握手和四种挥手的过程）但是可能会丢失数据包。

最终Ncaos来解决服务发现数据不一致问题是通过TCP协议的定时任务发请求，和UDP协议的主动发送事件请求，来解决一致性的。

#### 7、**Nacos注册中心原理**

[0301-Nacos.pdf](file/0301-Nacos_IDYXct_ol2.pdf " 0301-Nacos.pdf")

[Nacos注册中心AP架构剖析流程图 (1).pdf](<file/Nacos注册中心AP架构剖析流程图 (1)_JWHQ4WlJvO.pdf> " Nacos注册中心AP架构剖析流程图 (1).pdf")

**具体细节请结合课上分析。**

### 二、Feign

#### **Feign的调用原理：**

首先，如果你对某个接口定义了@FeignClient注解，Feign就会针对这个接口创建一个动态代理 &#x20;
Feign的动态代理会根据你在接口上的@RequestMapping等注解，来动态构造出你要请求的服务的地址  最后针对这个地址，发起请求、解析响应。

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\分布式\Cloud核心中间件\image\图片_2BGbpmra-b.png)

#### **Feign+Nacos注册中心原理**：

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\分布式\Cloud核心中间件\image\图片_F6hRLanAOa.png)

#### **Feign的底层调用源码大致流程:**

1.1、判断当前代理的方式是不是equals()、hashCode()、toString().如果是 直接结束，因为本地服务有这些方法，压根不需要从远程来要。 &#x20;

1.2、dispatch.get(method).invoke(args)  **：核心代理逻辑**

从一个派发器中获取解析当前方法的处理器  ---派发器的结构是一个Map--- Map\<Method, MethodHandler>来获取解析这个方法的处理器  。

默认从这个Map中找到的方法处理器是SynchronousMethodHandler---同步方法处理器 &#x20;

1.3、SynchronousMethodHandler.invoke（args） &#x20;

1.3.1 构建一个RequestTemplate。作用是为了发请求的是时候用这个模版造一个请求 &#x20;

细节：根据老的请求模版构建一个新的请求模版，接着会将老的请求模版中的一些参数放到新的请求模版中，但是请求头中参数如果没有在Feign中去指定的话，  那么这个老模版中就没有头，而新模板中也就没有请求头数据。因此后面在用这个新模版创建请求的时候，该请求就没有请求头数据，所以Feign在远程调用时出现了请求头丢失问题。 &#x20;

1.3.2 支持Options---可以独立对自己的业务远程接口去指定一些连接超时时间和读取的超时时间。 &#x20;

1.3.3 得到一个重试器Retryer &#x20;

如果在发送远程调用的时候，出现异常，那么feign在底层会用catch捕捉到， &#x20;

然后进行重试---  retryer.continueOrPropagate(e); &#x20;

但是对于重试feign自己也有规则： &#x20;

如果一旦在重试期间出现了异常，直接将异常抛出，结束这一次远程调用。 &#x20;

如果在重试期间没有出现异常，但是feign通过最大次数（5次调用）如果到了最大次数5 那么feign仍然是会抛出异常，结束这一次远程调用。 &#x20;

1.3.4 executeAndDecode---执行并解码（执行：指的是要去给远程发请求 解码：远程给我的数据都是字节流 我要将自字节流转成我业务能用的对象【反序列化】 ） &#x20;

1.3.4.1 发送请求 &#x20;

response = client.execute(); &#x20;

\---根据服务名从Nacos找到该服务下的所有客户端，然后负载均衡的掉用某一个。并且在第一次找该客户端的时候， &#x20;

会将第一次找到的这个客户端放到缓存中去，下一次再来发起远程调用的时候，直接从缓存中获取该客户端。&#x20;

1.3.4.2 对响应的数据进行反序列化 &#x20;

handleResponse();

#### **远程调用的本质**：

1、建立连接 &#x20;
2、给远程发送请求 &#x20;
3、远程处理数据 &#x20;
4、远程响应数据 &#x20;
5、将数据进行渲染



## ElasticSearch

### 1 、为什么要使用ElasticSearch？

使用Elasticsearch有以下几个主要原因：

1.  强大的全文搜索功能：Elasticsearch是一个基于Lucene的分布式搜索引擎，具有强大的全文搜索和检索功能。它支持复杂的查询语法和多种搜索方式，能够高效地处理大量的文本数据。这使得它非常适合用于构建搜索引擎、日志分析、内容推荐等应用。
2.  分布式和高可用性：Elasticsearch是一个分布式系统，它能够将数据分布在多个节点上进行存储和计算。这使得它具有高可用性和横向扩展能力，能够处理大规模数据和高并发访问。它还支持故障转移和自动数据恢复，即使某个节点发生故障，系统仍然可以继续运行。
3.  实时数据分析和聚合：Elasticsearch提供了强大的聚合功能，能够对大规模数据进行实时的数据分析和统计。它支持各种聚合操作，如求和、平均值、最大最小值、分组计数等，能够快速生成各种报表和可视化图表，帮助用户更好地理解和利用数据。
4.  构建实时应用：Elasticsearch具有低延迟的写入和查询能力，能够快速响应实时数据的变化。这使得它非常适合用于构建实时监控、实时推荐、实时搜索等实时应用场景。
5.  生态系统和易用性：Elasticsearch拥有丰富的生态系统，包括Kibana用于数据可视化、Logstash用于日志收集和处理、Beats用于数据采集等。它还提供了RESTful API和丰富的客户端库，使得开发和集成变得非常简单和灵活。

综上所述，Elasticsearch因其强大的全文搜索能力、分布式和高可用性特性、实时数据分析能力以及丰富的生态系统而成为一种流行的选择，适用于各种大规模数据处理和实时应用场景。

### 2 、ElasticSearch为什么快？

Elasticsearch之所以快速，主要有以下几个原因：

1.  倒排索引（Inverted Index）：Elasticsearch使用倒排索引来加速搜索过程。倒排索引是一种将词条与其出现位置的映射关系存储在索引中的数据构。通过倒排索引，Elasticsearch可以快速定位包含特定词条的文档，从而加搜索效率。
2.  分布式架构：Elasticsearch是一个分布式系统，它可以将数据分布在多个节点上进行存储和计算。这使得它具有横向扩展能力，能够处理大规模数据和高并发访问。通过将数据分片和分布式查询，Elasticsearch可以并行处理搜索请求，从而提高搜索效率。
3.  倒排索引的内存缓存：Elasticsearch使用内存缓存来提高搜索性能。它会将热门的词条和搜索结果存储在内存中，以便快速响应查询请求。通过利用内存缓存，Elasticsearch可以避免频繁的磁盘访问而加速搜索速度。
4.  集群化部署和负载均衡：Elasticsearch支持集群化部署，可以将索引和查询请求分布在多个节点上。它还提供了负载均衡机制，能够均衡地将请求分发给不同的节点，从而提高整体的处理能力和响应速度。
5.  后台实时刷新机制：Elasticsearch采用了近实时（Near Real-time）的刷新机制。当数据写入到Elasticsearch时，它会先写入内存缓冲区，然后异步地刷新到磁盘。这样可以避免频繁地磁盘写入，同时保证数据的可靠性和一致性。

综上所述，Elasticsearch通过倒排索引、分布式架构、内存缓存、负载均衡和实时刷新机制等技术手段，实现了高效的搜索和查询功能，从而使其具备快速响应和处理大规模数据的能力。

### 3 、倒排索引是什么？

倒排索引（Inverted Index）是一种将词条与其出现位置的映射关系存储在索引中的数据结构。它是一种反转（倒排）了文档-词条关系的索引方式。通常，一个正向索引（Forward Index）是通过文档ID来查找对应的词条，而倒排索引则是通过词条来查找对应的文档ID。

在倒排索引中，每个词条都会关联一个或多个文档。对于每个词条，倒排索引会记录下它在哪些文档中出现过以及出现的位置。这样，当需要搜索某个词条时，可以快速地找到包含该词条的文档。

倒排索引通常由两个主要部分组成：词典（Dictionary）和倒排列表（Inverted List）。词典以词条为键，记录了每个词条对应的倒排列表的位置。而倒排列表则包含了所有包含该词条的文档ID以及出现位置的信息。

倒排索引的结构使得搜索引擎能够快速定位包含特定词条的文档，从而加快搜索的速度。它是搜索引擎中常用的索引结构，被广泛应用于全文搜索、文本分析和信息检索等领域。

### 4 、如何保证ES和数据库的数据一致性？

为了保证Elasticsearch（ES）和数据库的数据一致性，可以采取以下几种方式：

1.  实时同步：在数据更新到数据库之后，立即将相应的数据同步到ES中。可以通过在应用程序的业务逻辑中，同时更新数据库和ES来实现实时同步。这样可以保证数据库和ES中的数据始终保持一致。
2.  延迟同步：在数据更新到数据库之后，通过定时任务或消息队列等机制，定期批量将更新的数据同步到ES中。这种方式可以降低对数据库写入操作的性能影响，并在一定程度上保证数据的同步性。
3.  双写模式：在数据更新时，同时向数据库和ES进行写入操作。这种方式可以确保数据同时写入到两个存储系统，从而保证数据的一致性。但是需要注意双写模式可能增加系统的复杂度和写入延迟。
4.  使用数据库的日志或触发器：数据库的日志或触发器可以捕获数据的变更操作，然后通过监听这些变更操作，将数据同步到ES中。这种方式可以避免对应用程序进行大量修改，但需要考虑数据库和ES之间的网络延迟和数据同步的顺序。

无论采取哪种方式，都需要确保数据库和ES的数据操作是原子的、可靠的，并且在故障恢复时能够保持数据的一致性。此外，还可以通过监控和日志记录来及时发现和解决数据同步的问题，确保数据的一致性和可靠性。



## 微服务、分布式

### 1、分布式和微服务的区别是什么？

分布式系统和微服务是两个相关但不同的概念，它们都涉及到软件架构中的组织和设计原则。以下是它们的区别：

1.  **定义和范围**：
    -   分布式系统：分布式系统是由多台计算机或服务器协同工作，通过网络通信来完成共同的任务。这些计算机可以分布在不同的地理位置，但它们通过网络连接进行协作。
    -   微服务：微服务是一种软件架构风格，将一个大型应用程序拆分成一组小型、独立的服务。每个微服务都专注于执行一个特定的业务功能，可以独立开发、部署和扩展。
2.  **关注点**：
    -   分布式系统：关注于如何将不同的计算机或服务器连接起来，以实现高性能、高可用性和负载均衡等目标。
    -   微服务：关注于如何将大型应用程序拆分成更小、更可管理的部分，并通过松耦合的方式来实现更灵活的开发、部署和维护。
3.  **通信方式**：
    -   分布式系统：分布式系统中的组件之间需要进行网络通信，常见的通信方式包括远程过程调用（RPC）、消息队列等。
    -   微服务：微服务之间通常使用HTTP等协议进行通信，可以通过RESTful API或其他通信方式来实现。
4.  **数据一致性**：
    -   分布式系统：在分布式系统中，确保数据一致性是一个挑战，需要考虑分布式事务、数据复制等问题。
    -   微服务：每个微服务可以拥有自己的数据存储，因此可以根据需求选择适当的数据库类型，并更容易管理数据一致性。
5.  **部署和扩展**：
    -   分布式系统：需要关注整体系统的部署和扩展，可能需要考虑多台服务器的管理和配置。
    -   微服务：每个微服务都可以独立部署和扩展，使得开发团队更容易管理和调整特定功能。

总的来说，分布式系统是一种基础架构模式，而微服务是一种架构风格。微服务通常可以在分布式系统中实现，但并不是所有分布式系统都采用微服务架构。微服务架构的主要目标是使开发、部署和维护更加灵活，适用于复杂的应用场景。

### 2、什么是微服务架构？优势？特点？

微服务架构是一种软件架构风格，将一个大型的应用程序拆分成多个小型、自治的服务单元，每个服务单元都专注于执行特定的业务功能。每个微服务可以独立开发、部署、扩展和维护，通过轻量级通信机制协同工作。微服务架构的优势和特点包括：

1.  **模块化与自治性**：微服务架构通过拆分应用为多个服务单元，使得开发团队可以更加专注于各自的业务领域。每个微服务都是独立的，有自己的代码、数据库、API等，可以在不影响其他服务的情况下进行修改和更新。
2.  **灵活性与快速交付**：微服务的自治性使得团队可以独立地开发、测试、部署和发布服务。这种独立性加速了开发周期，使团队能够更快地交付新功能和更新。
3.  **可扩展性**：微服务架构允许单独扩展每个服务，根据需求动态分配资源。这使得系统更具弹性，能够应对高负载和流量峰值。
4.  **技术多样性**：不同的微服务可以使用不同的技术栈，因为它们之间通过API通信。这允许团队选择最适合其任务的技术，而不受整个应用的技术限制。
5.  **容错性与隔离性**：由于微服务是自治的，一个服务的故障不会影响整个系统。故障在较小的范围内隔离，从而提高了整体系统的容错性。
6.  **持续集成与持续交付**：微服务架构有助于实现持续集成和持续交付，因为每个服务可以独立地构建、测试和发布。这有助于减少部署的风险，并快速响应用户需求。
7.  **灵活的团队组织**：微服务架构鼓励小团队负责特定的微服务，使得团队更加灵活，能够快速做出决策和调整。

然而，微服务架构也带来了一些挑战，如分布式系统的复杂性、服务间通信的管理、数据一致性等问题。对于不同的应用场景，需仔细权衡微服务的优势与挑战，以确定是否采用这种架构。

### 3、负载均衡算法、类型

**1、轮询法**
将请求按顺序轮流地分配到后端服务器上，它均衡地对待后端的每一台服务器，而不关心服务器实际的连接数和当前的系统负载。

**2、随机法**
通过系统的随机算法，根据后端服务器的列表大小值来随机选取其中的一台服务器进行访问。由概率统计理论可以得知，随着客户端调用服务端的次数增多，其实际效果越来越接近于平均分配调用量到后端的每一台服务器，也就是轮询的结果。

**3、源地址哈希法**
源地址哈希的思想是根据获取客户端的IP地址，通过哈希函数计算得到的一个数值，用该数值对服务器列表的大小进行取模运算，得到的结果便是客服端要访问服务器的序号。采用源地址哈希法进行负载均衡，同一IP地址的客户端，当后端服务器列表不变时，它每次都会映射到同一台后端服务器进行访问。

**4、加权轮询法**
不同的后端服务器可能机器的配置和当前系统的负载并不相同，因此它们的抗压能力也不相同。给配置高、负载低的机器配置更高的权重，让其处理更多的请；而配置低、负载高的机器，给其分配较低的权重，降低其系统负载，加权轮询能很好地处理这一问题，并将请求顺序且按照权重分配到后端。

**5、加权随机法**
与加权轮询法一样，加权随机法也根据后端机器的配置，系统的负载分配不同的权重。不同的是，它是按照权重随机请求后端服务器，而非顺序。

**6、最小连接数法**
最小连接数算法比较灵活和智能，由于后端服务器的配置不尽相同，对于请求的处理有快有慢，它是根据后端服务器当前的连接情况，动态地选取其中当前积压连接数最少的一台服务器来处理当前的请求，尽可能地提高后端服务的利用效率，将负责合理地分流到每一台服务器。

**类型：**
1、DNS 方式实现负载均衡
2、硬件负载均衡：F5 和 A10
3、软件负载均衡：Nginx 、 HAproxy 、 LVS&#x20;

其中的区别：
Nginx ：七层负载均衡，支持 HTTP、E-mail 协议，同时也支持 4 层负载均衡；
HAproxy ：支持七层规则的，性能也很不错。OpenStack 默认使用的负载均衡软件就是
HAproxy；
LVS ：运行在内核态，性能是软件负载均衡中最高的，严格来说工作在三层，所以更通用一些，
适用各种应用服务。

### 4、分布式架构下，Session 共享有什么方案

-   采用无状态服务，抛弃Session，使用中间件存储，比如MySQL/Redis等。

&#x20;    把 Session 放到 Redis 中存储，虽然架构上变得复杂，并且需要多访问一次 Redis ，但是这种方案带来的好处也是很大的。

-   存入cookie（要考虑跨域问题，且有安全风险）
-   Tomcat集群Session同步
-   使用Spring-Session
-   IP 绑定策略

&#x20;     使用 Nginx （或其他复杂均衡软硬件）中的 IP 绑定策略，同一个 IP 只能在指定的同一个机器访问，但是这样做失去了负载均衡的意义，当挂掉一台服务器的时候，会影响一批用户的使用，风险很大；

**实现了 Session 共享好处；**
1、可以水平扩展（增加 Redis 服务器）；
2、服务器重启 Session 不丢失（不过也要注意 数据在 Redis 中的刷新/失效机制）；
3、不仅可以跨服务器 Session 共享，甚至可以跨平台（例如网页端和 APP 端）；

### 5、CAP理论，BASE理论

**Consistency (一致性)：**
即更新操作成功并返回客户端后，所有节点在同一时间的数据完全一致。
对于客户端来说，一致性指的是并发访问时更新过的数据如何获取的问题。
从服务端来看，则是更新后如何复制分布到整个系统，以保证数据最终一致。

**Availability (可用性):**
即服务一直可用，而且是正常响应时间。系统能够很好的为用户服务，不出现用户操作失败或者访问超时等用户体验不好的情况。

**Partition Tolerance (分区容错性):**
即分布式系统在遇到某节点或网络分区故障的时候，仍然能够对外提供满足一致性和可用性的服务。分区容错性要求能够使应用虽然是一个分布式系统，而看上去却好像是在一个可以运转正常的整体。比如现在的分布式系统中有某一个或者几个机器宕掉了，其他剩下的机器还能够正常运转满足系统需求，对于用户而言并没有什么体验上的影响。

CP和AP：分区容错是必须保证的，当发生网络分区的时候，如果要继续服务，那么强一致性和可用性只能 2 选 1。

**BASE是Basically Available（基本可用）、Soft state（软状态）和Eventually consistent（最终一致性）**

BASE理论是对CAP中一致性和可用性权衡的结果，其来源于对大规模互联网系统分布式实践的总结，是基于CAP定理逐步演化而来的。BASE理论的核心思想是：即使无法做到强一致性，但每个应用都可以根据自身业务特点，采用适当的方式来使系统达到最终一致性。

**基本可用**：

-   响应时间上的损失: 正常情况下，处理用户请求需要 0.5s 返回结果，但是由于系统出现故障，处理用户请求的时间变为 3 s。
    系统功能上的损失：正常情况下，用户可以使用系统的全部功能，但是由于系统访问量突然剧增，系统的部分非核心功能无法使用。

**软状态：** 数据同步允许一定的延迟

**最终一致性：** 系统中所有的数据副本，在经过一段时间的同步后，最终能够达到一个一致的状态，不要求实时。

### 6、分布式Id生成方案

-   uuid

```text
1：当前日期和时间 时间戳
2：时钟序列。 计数器
3：全局唯一的IEEE机器识别号，如果有网卡，从网卡MAC地址获得，没有网卡以其他方式获得。

优点：代码简单，性能好（本地生成，没有网络消耗），保证唯一（相对而言，重复概率极低可以忽
略）
缺点：
1)每次生成的ID都是无序的，而且不是全数字，且无法保证趋势递增。
2)UUID生成的是字符串，字符串存储性能差，查询效率慢，写的时候由于不能产生顺序的append
操作，在进行insert操作，可能会导致频繁的页分裂，这种操作在记录占用空间比较大的情况下，性
能下降比较大，还会增加读取磁盘次数。
3)UUID长度过长，不适用于存储，耗费数据库性能。
4)ID无一定业务含义，可读性差。
```

-   数据库自增序列

```纯文本
单机模式： 
 优点： 
实现简单，依靠数据库即可，成本小。
ID数字化，单调自增，满足数据库存储和查询性能。
具有一定的业务可读性。（结合业务code）

 缺点： 
强依赖DB，存在单点问题，如果数据库宕机，则业务不可用。
DB生成ID性能有限，单点数据库压力大，无法扛高并发场景。
信息安全问题，比如暴露订单量，url查询改一下id查到别人的订单
分布式下生成的id会重复

 数据库高可用： 多主模式做负载，基于序列的起始值和步长设置，不同的初始值，相同的步长，步长大
于等于节点数。
 优点： 
解决了ID生成的单点问题，同时平衡了负载。
解决了分布式环境下id重复问题。
 缺点： 
系统扩容困难：系统定义好步长之后，增加机器之后调整步长困难。
主从同步的时候：电商下单->支付insert master db select数据 ，因为数据同步延迟导致
查不到这个数据。加cache(不是最好的解决方式)数据要求比较严谨的话查master主库。
```

-   基于redis、mongodb、zk等中间件生成
-   雪花算法

```纯文本
生成一个64bit的整性数字
第一位符号位固定为0，41位时间戳，10位workId，12位序列号
位数可以有不同实现。

 优点： 
每个毫秒值包含的ID值很多，不够可以变动位数来增加，性能佳（依赖workId的实现）。
时间戳值在高位，中间是固定的机器码，自增的序列在低位，整个ID是趋势递增的。
能够根据业务场景数据库节点布置灵活挑战bit位划分，灵活度高。

 缺点： 
强依赖于机器时钟，如果时钟回拨，会导致重复的ID生成，所以一般基于此的算法发现时钟回拨，
都会抛异常处 理，阻止ID生成，这可能导致服务不可用
```

### 7、分布式锁的解决方案

需要这个锁独立于每一个服务之外，而不是在服务里面。

**数据库**：利用主键冲突控制一次只有一个线程能获取锁，非阻塞、不可重入、单点、失效时间。
**Zookeeper分布式锁**：

```纯文本
zk通过临时节点，解决了死锁的问题，一旦客户端获取到锁之后突然挂掉（Session连接断开），那么这个临
时节点就会自动删除掉，其他客户端自动获取锁。临时顺序节点解决惊群效应
```

**Redis分布式锁**：setNX，单线程处理网络请求，不需要考虑并发安全性。
所有服务节点设置相同的key，返回为0、则锁获取失败

```纯文本
setnx
问题：
1、早期版本没有超时参数，需要单独设置，存在死锁问题（中途宕机）。
2、后期版本提供加锁与设置时间原子操作，但是存在任务超时，锁自动释放，导致并发问题，加锁与释
放锁不是同一线程问题。
```

删除锁：判断线程唯一标志，再删除。
可重入性及锁续期没有实现，通过redisson解决（类似AQS的实现，看门狗监听机制）
redlock：意思的机制都只操作单节点、即使Redis通过sentinel保证高可用，如果这个master节点由于
某些原因发生了主从切换，那么就会出现锁丢失的情况（redis同步设置可能数据丢失）。redlock从多
个节点申请锁，当一半以上节点获取成功、锁才算获取成功，redission有相应的实现。

### 8、实现一个分布式锁需要考虑哪些问题？

实现一个分布式锁时，需要考虑以下几个问题：

1.  锁的唯一性：在分布式环境下，需要确保同一把锁在不同的节点之间是唯一的。可以使用全局唯一标识符（例如基于ZooKeeper或Redis的分布式锁）来确保锁的唯一性。
2.  死锁和活锁：分布式环境下的死锁和活锁是需要避免的问题。死锁是指多个节点互相等待对方释放锁的情况，而活锁是指多个节点不断争夺锁资源，但没有一个节点能够成功获取锁。为了避免死锁和活锁，可以使用超时机制、重试机制、随机等待时间等策略来解决。
3.  锁的可重入性：分布式锁是否支持可重入是需要考虑的问题。可重入意味着同一个线程可以多次获取同一把锁，而不会发生死锁。在实现分布式锁时，需要考虑是否支持可重入，并在实现时进行相应的处理。
4.  锁的粒度：锁的粒度是指锁的范围，即锁定的是整个系统、模块、方法还是更细粒度的资源。在分布式环境下，锁的粒度需要根据实际需求进行选择，避免锁的范围大或过小。
5.  锁的性能和可靠性：分布式锁的性能和可靠性是需要考虑的问题。锁的获取和释放需要保证高效且可靠，同时要考虑网络延迟、节点故障等因素对锁性能和可靠性的影响。
6.  锁的容错和容量：在分布式环境下，需要考虑节点故障和网络分区等异常情况对锁的影响。可以使用多个节点进行容错和冗余，以确保锁的可用性和容量。

综上所述，实现一个分布式锁需要考虑锁的唯一性、死锁和活锁、锁的可重入性、锁的粒度、锁的性能和可靠性，以及锁的容错和容量等问题。根据具体需求选择适合的分布式锁方案，并在实现时合理处理这些问题。

### 9、什么是分布式事务

分布式事务是指在分布式系统中涉及多个独立的数据库或服务的事务操作，它需要确保这些操作要么全部成功执行，要么全部回滚，以保持数据的一致性和可靠性。分布式事务的目标是在不同的系统之间维护数据的一致性，即使在出现故障或部分操作失败的情况下也能够保持数据的正确性。

在传统的单一数据库事务中，事务是由数据库管理系统负责管理和保障的，但在分布式环境下，涉及到多个独立的数据库或服务，各自拥有独立的事务管理机制，因此需要特殊的方法来确保分布式事务的一致性。

分布式事务面临的挑战和问题包括：

原子性（Atomicity）： 分布式事务需要确保涉及的所有操作要么都成功执行，要么都回滚，不能出现部分操作成功而部分操作失败的情况。

一致性（Consistency）： 分布式事务需要保证各个参与方的数据保持一致性，即在事务开始和结束时，系统的数据状态应该满足特定的约束。

隔离性（Isolation）： 分布式事务的操作应该与其他事务隔离，避免不同事务之间的干扰和冲突。

持久性（Durability）： 分布式事务需要确保在事务提交后，其结果被可靠地持久化，以防止数据丢失。

为了实现分布式事务，有一些常见的方法和技术，包括两阶段提交（Two-Phase Commit，2PC）、三阶段提交（Three-Phase Commit，3PC）、补偿事务（Compensating Transaction）等。这些方法在不同的场景下有不同的适用性和权衡，开发人员需要根据系统的需求和复杂性选择适合的方法来处理分布式事务。同时，分布式事务的实现也需要考虑到性能、可靠性和复杂性等方面的因素。

### 10、分布式事务解决方案

XA规范：分布式事务规范，定义了分布式事务模型
四个角色：事务管理器(协调者TM)、资源管理器(参与者RM)，应用程序AP，通信资源管理器CRM。
全局事务：一个横跨多个数据库的事务，要么全部提交、要么全部回滚JTA事务时java对XA规范的实现，对应JDBC的单库事务

1、**两阶段协议：**

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\分布式\微服务、分布式\image\图片_Q25vZTPeSK.png)

**第一阶段**（ prepare ） ：每个参与者执行本地事务但不提交，进入 ready 状态，并通知协调者已经准备就绪。

**第二阶段**（ commit ） 当协调者确认每个参与者都 ready 后，通知参与者进行 commit 操作；如果有参与者 fail ，则发送 rollback 命令，各参与者做回滚。

问题：
**单点故障：** 一旦事务管理器出现故障，整个系统不可用（参与者都会阻塞住）**数据不一致**：在阶段二，如果事务管理器只发送了部分 commit 消息，此时网络发生异常，那么
只有部分参与者接收到 commit 消息，也就是说只有部分参与者提交了事务，使得系统数据不一
致。
**响应时间较长**：参与者和协调者资源都被锁住，提交或者回滚之后才能释放
**不确定性**：当协事务管理器发送 commit 之后，并且此时只有一个参与者收到了 commit，那么当该参与者与事务管理器同时宕机之后，重新选举的事务管理器无法确定该条消息是否提交成功。

**2、三阶段协议：** 主要是针对两阶段的优化，解决了2PC单点故障的问题，但是性能问题和不一致问题仍然没有根本解决。

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\分布式\微服务、分布式\image\图片_1nBse5EWEg.png)

引入了超时机制解决参与者阻塞的问题，超时后本地提交，2pc只有协调者有超时机制。

**第一阶段**：CanCommit阶段，协调者询问事务参与者，是否有能力完成此次事务。

-   如果都返回yes，则进入第二阶段：
-   有一个返回no或等待响应超时，则中断事务，并向所有参与者发送abort请求。

**第二阶段**：PreCommit阶段，此时协调者会向所有的参与者发送PreCommit请求，参与者收到后开始执行事务操作。参与者执行完事务操作后（此时属于未提交事务的状态），就会向协调者反馈“Ack”表示我已经准备好提交了，并等待协调者的下一步指令。

**第三阶段**：DoCommit阶段， 在阶段二中如果所有的参与者节点都返回了Ack，那么协调者就会从“预提交状态”转变为“提交状态”。然后向所有的参与者节点发送"doCommit"请求，参与者节点在收到提交请求后就会各自执行事务提交操作，并向协调者节点反馈“Ack”消息，协调者收到所有参与者的Ack消息后完成事务。 相反，如果有一个参与者节点未完成PreCommit的反馈或者反馈超时，那么协调者都会向所有的参与者节点发送abort请求，从而中断事务。

**3、TCC（补偿事务）**：Try、Confirm、Cancel
针对每个操作，都要注册一个与其对应的确认和补偿（撤销）操作Try操作做业务检查及资源预留，Confirm做业务确认操作，Cancel实现一个与Try相反的操作既回滚操作。TM首先发起所有的分支事务的try操作，任何一个分支事务的try操作执行失败，TM将会发起所有
分支事务的Cancel操作，若try操作全部成功，TM将会发起所有分支事务的Confirm操作，其中Confirm/Cancel操作若执行失败，TM会进行重试。

TCC模型对业务的侵入性较强，改造的难度较大，每个操作都需要有 try 、 confirm 、 cancel 三个接口实现。
confirm 和 cancel 接口还必须实现幂等性。

**4、消息队列的事务消息：**

-   发送prepare消息到消息中间件
-   发送成功后，执行本地事务
    如果事务执行成功，则commit，消息中间件将消息下发至消费端（commit前，消息不会被
    消费）
    如果事务执行失败，则回滚，消息中间件将这条prepare消息删除
    消费端接收到消息进行消费，如果消费失败，则不断重试。

需要注意的是，每种分布式事务处理方法都有其适用的场景和权衡。选择适当的方法取决于系统的要求、复杂性和可用技术栈。

### 11、 什么是TCC，和2PC有什么区别？

TCC（Try-Confirm-Cancel）和2PC（Two-Phase Commit）都是用于处理分布式事务的协议，但它们在处理方式和适用场景上存在一些区别。

TCC (Try-Confirm-Cancel): TCC是一种分布式事务处理方法，它将事务拆分为三个阶段：尝试（Try）、确认（Confirm）和取消（Cancel）。每个阶段都有相应的操作。在尝试阶段，参与者尝试执行事务操作，检查是否满足执行条件。如果所有参与者的尝试都成功，进入确认阶段，参与者确认执行事务。如果任何一个参与者的尝试失败或确认阶段失败，将进入取消阶段，执行事务的补偿操作来恢复系统到一致状态。TCC注重于事务的补偿机制，以确保数据的一致性。

2PC (Two-Phase Commit): 2PC是另一种分布式事务处理协议，它在全局协调器和多个参与者之间进行通信。它有两个阶段：准备（Prepare）和提交（Commit）。在准备阶段，全局协调器将询问所有参与者是否可以执行事务，参与者会回复“可以”或“不可以”。如果所有参与者都回复“可以”，则进入提交阶段，在此阶段全局协调器通知所有参与者提交事务。如果任何一个参与者回复“不可以”，全局协调器会通知所有参与者中止事务。2PC依赖于中心化的协调器，其缺点包括单点故障和阻塞的可能性。

区别:

处理方式： TCC采用尝试-确认-取消的模式，强调补偿机制，而2PC采用两阶段提交的方式，依赖全局协调器来决定提交或中止事务。

灵活性： TCC相对更加灵活，因为它允许开发人员在尝试和确认阶段之间插入补偿逻辑。2PC较为严格，需要参与者在准备阶段做出确定性的回应。

复杂性和性能： TCC通常比2PC更适用于高并发环境，因为它的操作相对较轻，而2PC的中心化协调可能导致性能瓶颈。

可用性： TCC通常在局部事务级别上具有更好的可用性，因为每个参与者可以独立决定是否尝试事务。

在选择TCC还是2PC时，需要根据系统的需求、复杂性和可靠性等因素进行权衡。

### 12、什么是柔性事务？

柔性事务（Flexible Transactions）是一种用于分布式系统中的事务处理模式，旨在处理跨多个参与者的分布式事务。在分布式环境中，事务涉及到多个资源或服务，需要保证数据的一致性和可靠性。柔性事务是为了在分布式系统中实现事务处理的灵活性和可扩展性而设计的。

柔性事务模式通常允许开发人员在事务的各个阶段插入逻辑，以便在出现错误或异常情况时进行处理。这种模式的核心思想是，将事务处理拆分为三个阶段：尝试（Try）、确认（Confirm）和取消（Cancel）。

尝试（Try）： 在这个阶段，事务的参与者尝试执行操作，并在操作完成之前不对外部资源产生影响。这是一个"预提交"的阶段，用于检查所有资源是否可用，并为后续的确认阶段做准备。

确认（Confirm）： 如果所有参与者的尝试阶段都成功，那么系统会进入确认阶段。在这个阶段，参与者提交事务，并将操作的结果应用到资源中。如果在这个阶段发生了错误，可以触发补偿逻辑，回滚之前的操作，以确保数据的一致性。

取消（Cancel）： 如果在确认阶段发生错误，系统会进入取消阶段。在这个阶段，参与者会执行回滚操作，将之前尝试阶段所做的更改撤销，以保持数据的一致性。

柔性事务相对于传统的两阶段提交（2PC）来说，具有更高的灵活性和可用性。它允许在不同的阶段插入补偿逻辑，以应对各种异常情况，同时减少了全局协调器的依赖，从而降低了性能瓶颈的风险。这使得柔性事务在高并发和复杂的分布式系统中更具优势。

### 13、如何基于本地消息表实现分布式事务？

当基于本地消息表实现分布式事务时，通常会采用一种称为“基于消息的最终一致性”或“最终一致性补偿”模式。这个模式可以帮助在分布式环境中处理事务性操作，同时保持数据的一致性。

以下是基于本地消息表实现分布式事务的一般步骤：

操作记录与消息发送： 当一个分布式事务发起时，主节点（或服务）将事务操作记录到本地数据库，并将一个消息发送到消息队列中。这个消息包含了执行的操作、事务标识以及其他必要的信息。

消息传递与处理： 其他参与者节点在收到消息后，根据消息中的操作类型执行相应的本地操作。这些本地操作可能会修改各个节点的数据状态，但在这个阶段不会立即确认事务的完成。

确认阶段： 在所有参与者节点执行完本地操作后，各节点会将一个确认消息发送回主节点。主节点根据收到的确认消息来判断是否可以提交事务。如果有任何错误发生，主节点可以触发补偿逻辑。

补偿阶段： 如果在确认阶段发生错误，主节点可以通过发送补偿消息来触发参与者节点执行相反的操作，以撤销之前的更改，从而保持数据的一致性。这就是所谓的“最终一致性补偿”。

完成或取消： 一旦确认阶段中的所有参与者节点都成功确认，事务被视为成功完成。如果在确认阶段有任何错误，主节点会触发取消操作，参与者节点会执行补偿操作，将数据状态还原到事务开始前的状态。

基于本地消息表的分布式事务实现主要依赖于消息队列的可靠性和分布式事务的补偿能力。这种模式可以提高分布式系统的可用性和容错性，但同时也需要在应用程序中实现正确的补偿逻辑来处理可能的异常情况。

### 14、什么是Seata？他有哪几种模式？

Seata是由阿里巴巴开源的一款分布式事务解决方案，旨在解决分布式系统中的数据一致性问题。Seata提供了一套事务管理的解决方案，支持对分布式事务进行管理和协调。

Seata有以下三种常见的模式：

1 AT模式（Automatic Transaction）：AT模式是Seata最常用的模式，它基于数据库的本地事务实现分布式事务的一致性。在AT模式下，Seata通过拦截数据访问层的SQL操作，并将这些操作封装在一个全局事务中。Seata通过将事务信息存储在全局事务上下文中，并协调各个分支事务的提交或回滚来实现式事务的一致性。

2 TCC模式（Try-Confirm-Cancel）：TCC模式是一种补偿型的分布式事务模式。在TCC模式下，Seata通过定义三个阶段的操作：Try阶段尝试执行业务操作、Confirm阶段确认执行操作、Cancel阶段撤销执行操作。Seata通过补偿机制来保证分布式事务的一致性，即使在异常情况下也能够进行回滚或补偿。

3 Saga模式：Saga模式是一种长事务的分布式事务模式，通过将业务操作分解为一系列的子事务来实现。每个子事务都有自己的回滚操作，从而实现了分布式事务的逐步提交和回滚。Saga模式通过异步消息和补偿机制来实现事务的提交和回滚。

这三种模式在不同的场景下可以根据实际需求进行选择和组合使用，以满足分布式系统的事务管理需求。

### 15、如何实现接口的幂等性

#### **1、token 机制**

1、服务端提供了发送 token 的接口。我们在分析业务的时候，哪些业务是存在幂等问题的，
就必须在执行业务前，先去获取 token，服务器会把 token 保存到 redis 中。
2、然后调用业务接口请求时，把 token 携带过去，一般放在请求头部。
3、服务器判断 token 是否存在 redis 中，存在表示第一次请求，然后删除 token,继续执行业
务。
4、如果判断 token 不存在 redis 中，就表示是重复操作，直接返回重复标记给 client，这样
就保证了业务代码，不被重复执行。

**危险性：**
1、先删除 token 还是后删除 token；
(1) 先删除可能导致，业务确实没有执行，重试还带上之前 token，由于防重设计导致，
请求还是不能执行。
(2) 后删除可能导致，业务处理成功，但是服务闪断，出现超时，没有删除 token，别
人继续重试，导致业务被执行两边
(3) 我们最好设计为先删除 token，如果业务调用失败，就重新获取 token 再次请求。
2、Token 获取、比较和删除必须是原子性
(1) redis.get(token) 、token.equals、redis.del(token)如果这两个操作不是原子，可能导
致，高并发下，都 get 到同样的数据，判断都成功，继续业务并发执行
(2) 可以在 redis 使用 lua 脚本完成这个操作。

```java
if redis.call('get', KEYS[1]) == ARGV[1] then return redis.call('del', KEYS[1]) else return 0 end
```

#### **2、各种锁机制**

**1、数据库悲观锁**

**2、数据库乐观锁**
这种方法适合在更新的场景中，
update t\_goods set count = count -1 , version = version + 1 where good\_id=2 and version = 1根据 version 版本，也就是在操作库存前先获取当前商品的 version 版本号，然后操作的时候带上此 version 号。我们梳理下，我们第一次操作库存时，得到 version 为 1，调用库存服务version 变成了 2；但返回给订单服务出现了问题，订单服务又一次发起调用库存服务，当订
单服务传如的 version 还是 1，再执行上面的 sql 语句时，就不会执行；因为 version 已经变
为 2 了，where 条件就不成立。这样就保证了不管调用几次，只会真正的处理一次。

**3、业务层分布式锁**
如果多个机器可能在同一时间同时处理相同的数据，比如多台机器定时任务都拿到了相同数
据处理，我们就可以加分布式锁，锁定此数据，处理完成后释放锁。获取到锁的必须先判断
这个数据是否被处理过。

#### 3、各种唯一约束

**1、数据库唯一约束**
插入数据，应该按照唯一索引进行插入，比如订单号，相同的订单就不可能有两条记录插入。
我们在数据库层面防止重复。
这个机制是利用了数据库的主键唯一约束的特性，解决了在 insert 场景时幂等问题。但主键
的要求不是自增的主键，这样就需要业务生成全局唯一的主键。
如果是分库分表场景下，路由规则要保证相同请求下，落地在同一个数据库和同一表中，要
不然数据库主键约束就不起效果了，因为是不同的数据库和表主键不相关。

**2、redis set 防重**
很多数据需要处理，只能被处理一次，比如我们可以计算数据的 MD5 将其放入 redis 的 set，
每次处理数据，先看这个 MD5 是否已经存在，存在就不处理。

#### **4、表防重**

使用订单号 orderNo 做为去重表的唯一索引，把唯一索引插入去重表，再进行业务操作，且
他们在同一个事务中。这个保证了重复请求时，因为去重表有唯一约束，导致请求失败，避
免了幂等问题。这里要注意的是，去重表和业务表应该在同一库中，这样就保证了在同一个
事务，即使业务操作失败了，也会把去重表的数据回滚。这个很好的保证了数据一致性。

### 16、微服务架构的服务治理有哪些实现方案？

微服务架构的服务治理有以下几种实现方案：

1.  服务注册与发现：使用服务注册表来管理所有微服务的信息，包括服务名称、地址、版本等。服务提供者将自己的信息注册到注册表中，服务消费者通过注册表来发现可用的服务。常见的服务注册与发现工具有Consul、ZooKeeper和etcd等。
2.  负载均衡：通过在服务提供者与服务消费者之间引入负载均衡器，将请求平均分配到多个服务实例上，以提高系统的可伸缩性和可用性。常见的负载均衡器有Nginx、HAProxy和Envoy等。
3.  健康检查与容错机制：通过定期的健康检查来监测服务的可用性和状态，并根据检查结果进行容错处理，比如自动剔除不可用的服务实例。常见的健康检查工具有Spring Cloud的Spring Boot Admin、Netflix的Hystrix和Istio等。
4.  熔断器与降级：在高并发或异常情况下，通过熔断器来控制请求的流量，避免服务的雪崩效应。同时可以通过降级策略，在服务不可用时返回默认值或者静态数据，保证系统的可用性。常见的熔断器和降级工具有Netflix的Hystrix和Sentinel等。
5.  配置中心：将微服务的配置集中管理，实现配置的动态更新和版本控制。通过配置中心，可以动态修改微服务的配置，而无需重启服务。常见的配置中心有Spring Cloud Config、Apollo和Consul等。
6.  API 网关：通过引入 API 网关来对外暴露微服务的统一接口，实现请求的路由、转发和过滤等功能。API 网关可以对请求进行鉴权和限流，提供统一的访问控制和监控。常见的 API 网关有Spring Cloud Gateway、Netflix的Zuul和Kong等。

以上是常见的微服务架构的服务治理实现方案，可以根据实际需求选择适合的方案进行使用。



## 线程、并发

### 1、什么是并发？

答:是指在一定时间内交替执行多任务的任务。操作时有多个线程CPU运行时间分为几个时间段，然后将时间段分配给每个线程执行。 当线程代码在一段时间内运行时，其他线程处于悬挂状。

### 2、并发和并行有什么区别？

答:并发和并行是一个很容易混淆的概念。并发是指多个任务的交替，而平行是指真正意义上的“同时进行”。事实上，如果系统中只有一个CPU，在实际系统环境中不能并行使用多线程，则只能通过切换时间片来交替执行任务。真正的平行只能出现在拥有多个CPU的系统中。

并发： 同时，许多任务正在执行中 (单位时间内不一定同时执行)；

并行： 在单位时间内，同时执行多项任务。

### 3、为什么要使用并发？

答:并发编程在一定程度上离不开多核CPU的发展。随着单核CPU的研发，无法遵循“摩尔定律”(摩尔定律是基于硬件开发的观测定律，也是基于“摩尔定律”的“反摩尔定律”，不过“反摩尔定律”是软件领域的定律，有兴趣的可以自己理解)，为了进一步提高计算速度，硬件工程师不再追求单独的计算单元，而是将多个计算单元集成在一起，即形成多核CPU。短短十几年，Intel等家用CPU i7可以达到4个甚至8个核心。短短十几年，Intel等家用CPU i7可以达到4个甚至8个核心。专业服务器通常可以达到几个独立的CPU，每个CPU甚至有8个以上的核心。因此，“摩尔定律”它似乎继续体验CPU的核心扩展。在多核CPU的背景下，并发编程的趋势应运而生。通过并发编程，可以充分发挥多核CPU的计算能力，提高其性能。

### 4、并发编程有哪些缺点？

答：（1)上下文切换频繁

时间片是CPU分配给每个线程的时间，因为时间很短，所以CPU不断切换线程，让我们觉得多个线程是同时执行的，时间片通常是几十毫秒。每次切换时，都需要保存当前状态，以恢复以前的状态。这种切换行为非常失去性能。过于频繁的切换不能充分发挥多线程编程的优势。无锁并发编程可用于通常减少上下文切换。 CAS算法，使用最少的线程和使用协程。

（2)线程的安全问题

多线程编程中最难把握的是临界区域的线程安全。如果你不注意，就会有死锁。一旦产生死锁，系统功能将不可用。

### 5、上下文切换是什么？

答：多线程编程中一般线程的数量大于 CPU 核心数，而一个 CPU 为了有效地执行这些线程，核心只能在任何时候使用一个线程，CPU 策略是将时间片分配到每个线程并旋转。当一个线程的时间片用完时，它将重新处于就绪状态，供其他线程使用。这个过程属于上下文切换。

上下文切换通常是计算密集型的。换句话说，它需要相当可观的处理器时间。在每秒几十次或数百次的切换中，每次切换都需要纳秒量级时间。因此，上下文切换意味着系统消耗了大量事实上，CPU时间可能是操作系统中时间消耗最大的操作。Linux与其他操作系统相比(包括其他类别)Unix系统有很多优点，其中之一就是上下文切换和模式切换的时间消耗很少。

### 6、使用多线程可能会带来什么问题？

答：并发编程的目的是提高程序执行效率和程序运行速度，但并发编程并不总是提高程序运行速度，并发编程可能会遇到内存泄漏、上下文切换、死锁、硬件和软件资源闲置等诸多问题。

### 7、简要总结线程与进程的关系？

答:一个进程中可以有多个线程，多个线程共享进程的堆叠和方法区 (JDK1.8 之后的元空间)资源，但每个线程都有自己的程序计数器、虚拟机栈和本地方法栈。综上所述，线程是过程划分为较小的操作单元。线程和进程最大的区别在于，每个进程基本上都是独立的，而每个线程都不一定，因为同一进程中的线程很可能相互影响。线程执行成本小，但不利于资源管理和保护；进程恰恰相反。

### 8、sleep()、wait()、join()、yield()的区别

**1.锁池**
所有需要竞争同步锁的线程都会放在锁池当中，比如当前对象的锁已经被其中一个线程得到，则其他线程需要在这个锁池进行等待，当前面的线程释放同步锁后锁池中的线程去竞争同步锁，当某个线程得到后会进入就绪队列进行等待cpu资源分配。

**2.等待池**
当我们调用wait（）方法后，线程会放到等待池当中，等待池的线程是不会去竞争同步锁。只有调用了notify（）或notifyAll()后等待池的线程才会开始去竞争锁，notify（）是随机从等待池选出一个线程放到锁池，而notifyAll()是将等待池的所有线程放到锁池当中。

1、sleep 是 Thread 类的静态本地方法，wait 则是 Object 类的本地方法。
2、sleep方法不会释放lock，但是wait会释放，而且会加入到等待队列中。
3、sleep方法不依赖于同步器synchronized，但是wait需要依赖synchronized关键字。
4、sleep不需要被唤醒（休眠之后推出阻塞），但是wait需要（不指定时间需要被别人中断）。
5、sleep 一般用于当前线程休眠，或者轮循暂停操作，wait 则多用于多线程之间的通信。
6、sleep 会让出 CPU 执行时间且强制上下文切换，而 wait 则不一定，wait 后可能还是有机会重新竞争到锁继续执行的。

yield（）执行后线程直接进入就绪状态，马上释放了cpu的执行权，但是依然保留了cpu的执行资格，所以有可能cpu下次进行线程调度还会让这个线程获取到执行权继续执行。

join（）执行后线程进入阻塞状态，例如在线程B中调用线程A的join（），那线程B会进入到阻塞队列，直到线程A结束或中断线程。

```java
public static void main(String[] args) throws InterruptedException {
Thread t1 = new Thread(new Runnable() {
@Override
public void run() {
try {
Thread.sleep(3000);
} catch (InterruptedException e) {

e.printStackTrace();
}
System.out.println("22222222");
}
});
t1.start();
t1.join();
// 这行代码必须要等t1全部执行完毕，才会执行
System.out.println("1111");
}
```

### 9、谈谈对线程安全的理解

不是线程安全、应该是内存安全，堆是共享内存，可以被所有线程访问。

```text
当多个线程访问一个对象时，如果不用进行额外的同步控制或其他的协调操作，调用这个对象的行为都可以获得正确的结果，我们就说这个对象是线程安全的。
```

**堆**是进程和线程共有的空间，分全局堆和局部堆。全局堆就是所有没有分配的空间，局部堆就是用户分配的空间。堆在操作系统对进程初始化的时候分配，运行过程中也可以向系统要额外的堆，但是用完了要还给操作系统，要不然就是内存泄漏。

```纯文本
在Java中，堆是Java虚拟机所管理的内存中最大的一块，是所有线程共享的一块内存区域，在虚
拟机启动时创建。堆所存在的内存区域的唯一目的就是存放对象实例，几乎所有的对象实例以及
数组都在这里分配内存。
```

**栈**是每个线程独有的，保存其运行状态和局部自动变量的。栈在线程开始的时候初始化，每个线程的栈互相独立，因此，栈是线程安全的。操作系统在切换线程的时候会自动切换栈。栈空间不需要在高级语言里面显式的分配和释放。

目前主流操作系统都是多任务的，即多个进程同时运行。为了保证安全，每个进程只能访问分配给自己的内存空间，而不能访问别的进程的，这是由操作系统保障的。

在每个进程的内存空间中都会有一块特殊的公共区域，通常称为堆（内存）。进程内的所有线程都可以访问到该区域，**这就是造成问题的潜在原因。**

### 10、Thread和Runnable的区别

Thread和Runnable的实质是继承关系，没有可比性。无论使用Runnable还是Thread，都会newThread，然后执行run方法。用法上，如果有复杂的线程操作需求，那就选择继承Thread，如果只是简单的执行一个任务，那就实现runnable。

```java
//会卖出多一倍的票
public class Test {
    public static void main(String[] args) {
        // TODO Auto-generated method stub
        new MyThread().start();
        new MyThread().start();
        }
            static class MyThread extends Thread{
                private int ticket = 5;
                public void run(){
                while(true){
                System.out.println("Thread ticket = " + ticket--);
                if(ticket < 0){
                    break;
                }
            }
        }
    }
}
```

```java
//正常卖出
public class Test2 {
public static void main(String[] args) {
// TODO Auto-generated method stub
MyThread2 mt=new MyThread2();
new Thread(mt).start();
new Thread(mt).start();
}
static class MyThread2 implements Runnable{
private int ticket = 5;
public void run(){
while(true){
System.out.println("Runnable ticket = " + ticket--);
if(ticket < 0){
break;
}
}
}
}
}
```

原因是：MyThread创建了两个实例，自然会卖出两倍，属于用法错误。

### 11、谈谈对守护线程的理解

**守护线程：** 为所有非守护线程提供服务的线程；任何一个守护线程都是整个JVM中所有非守护线程的保姆；
守护线程类似于整个进程的一个默默无闻的小喽喽；它的生死无关重要，它却依赖整个进程而运行；哪天其他线程结束了，没有要执行的了，程序就结束了，理都没理守护线程，就把它中断了；

注意： 由于守护线程的终止是自身无法控制的，因此千万不要把IO、File等重要操作逻辑分配给它；因为它不靠谱；

**守护线程的作用是什么？**
举例， GC垃圾回收线程：就是一个经典的守护线程，当我们的程序中不再有任何运行的Thread,程序就不会再产生垃圾，垃圾回收器也就无事可做，所以当垃圾回收线程是JVM上仅剩的线程时，垃圾回收线程会自动离开。它始终在低级别的状态中运行，用于实时监控和管理系统中的可回收资源。

**应用场景：**

（1）来为其它线程提供服务支持的情况；

（2） 或者在任何情况下，程序结束时，这个线程必须正常且立刻关闭，就可以作为守护线程来使用；反之，如果一个正在执行某个操作的线程必须要正确地关闭掉否则就会出现不好的后果的话，那么这个线程就不能是守护线程，而是用户线程。通常都是些关键的事务，比方说，数据库录入或者更新，这些操作都是不能中断的。

thread.setDaemon(true)必须在thread.start()之前设置，否则会跑出一个IllegalThreadStateException异常。你不能把正在运行的常规线程设置为守护线程。

在Daemon线程中产生的新线程也是Daemon的。
守护线程不能用于去访问固有资源，比如读写操作或者计算逻辑。因为它会在任何时候甚至在一个操作的中间发生中断。

Java自带的多线程框架，比如ExecutorService，会将守护线程转换为用户线程，所以如果要使用后台线程就不能用Java的线程池。

### 12、ThreadLocal的原理和使用场景

每一个 Thread 对象均含有一个 ThreadLocalMap 类型的成员变量 threadLocals ，它存储本线程中所有ThreadLocal对象及其对应的值ThreadLocalMap 由一个个 Entry 对象构成Entry 继承自 WeakReference\<ThreadLocal\<?>> ，一个 Entry 由 ThreadLocal 对象和 Object 构成。由此可见， Entry 的key是ThreadLocal对象，并且是一个弱引用。当没指向key的强引用后，该
key就会被垃圾收集器回收。

当执行set方法时，ThreadLocal首先会获取当前线程对象，然后获取当前线程的ThreadLocalMap对象。再以当前ThreadLocal对象为key，将值存储进ThreadLocalMap对象中。
get方法执行过程类似。ThreadLocal首先会获取当前线程对象，然后获取当前线程的ThreadLocalMap对象。再以当前ThreadLocal对象为key，获取对应的value。

由于每一条线程均含有各自私有的ThreadLocalMap容器，这些容器相互独立互不影响，因此不会存在线程安全性问题，从而也无需使用同步机制来保证多条线程访问容器的互斥性。

使用场景：
1、在进行对象跨层传递的时候，使用ThreadLocal可以避免多次传递，打破层次间的约束。
2、Spring框架进行事务操作，用于存储线程事务信息。
3、Spring框架数据库连接，Session会话管理。

4、SpringMVC框架的处理器请求管理。

```text
Spring框架在事务开始时会给当前线程绑定一个Jdbc Connection,在整个事务过程都是使用该线程绑定的connection来执行数据库操作，实现了事务的隔离性。Spring框架里面就是用的ThreadLocal来实现这种隔离
```

**例子：example:**

```java
package com.hzk.test.my;
/**
 * @Author huzhongkui
 * @Date 2022--04--20 21:14
 * 聪明出于勤奋,天才在于积累
 **/
public class Person {

    private ThreadLocal<String> name = new ThreadLocal<>();

    public void setName(String name) {
        this.name.set(name);
    }

    public String getName() {
        return this.name.get();
    }

    public void remove() {
        this.name.remove();
    }

}


```

```java
package com.hzk.test.my;

import java.util.concurrent.TimeUnit;

/**
 * @Author huzhongkui
 * @Date 2022--04--20 21:16
 * 聪明出于勤奋,天才在于积累
 **/
public class Test {

    public static void main(String[] args) {

        Person person = new Person();

        Thread thread1 = new Thread(new Runnable() {

            @Override
            public void run() {
              person.setName("hzk");
                try {
                    TimeUnit.SECONDS.sleep(3);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                System.out.println("线程1==="+person.getName());
            }
        });
        thread1.start();


        Thread thread2 = new Thread(new Runnable() {

            @Override
            public void run() {
                person.setName("hello");
                try {
                    TimeUnit.SECONDS.sleep(3);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                System.out.println("线程2==="+person.getName());
            }
        });
        thread2.start();


    }

}
```

### 13、ThreadLocal内存泄露原因，如何避免

**内存泄露**：为程序在申请内存后，无法释放已申请的内存空间，一次内存泄露危害可以忽略，但内存泄露堆积后果很严重，无论多少内存,迟早会被占光，不再会被使用的对象或者变量占用的内存不能被回收，就是内存泄露。

**强引用**：使用最普遍的引用(new)，一个对象具有强引用，不会被垃圾回收器回收。当内存空间不足，Java虚拟机宁愿抛出OutOfMemoryError错误，使程序异常终止，也不回收这种对象。

如果想取消强引用和某个对象之间的关联，可以显式地将引用赋值为null，这样可以使JVM在合适的时间就会回收该对象。

**弱引用**：JVM进行垃圾回收时，无论内存是否充足，都会回收被弱引用关联的对象。在java中，用java.lang.ref.WeakReference类来表示。可以在缓存中使用弱引用。

ThreadLocal的实现原理，每一个Thread维护一个ThreadLocalMap，key为使用弱引用的ThreadLocal实例，value为线程变量的副本。

ThreadLocalMap使用ThreadLocal的弱引用作为key，如果一个ThreadLocal不存在外部强引用时， Key(ThreadLocal)势必会被GC回收，这样就会导致ThreadLocalMap中key为null， 而value还存在着强引用，只有thead线程退出以后,value的强引用链条才会断掉，但如果当前线程再迟迟不结束的话，这些key为null的Entry的value就会一直存在一条强引用链（红色链条）

key使用强引用当ThreadLocalMap的key为强引用回收ThreadLocal时，因为ThreadLocalMap还持有ThreadLocal的强引用，如果没有手动删除，ThreadLocal不会被回收。

key 使用弱引用当ThreadLocalMap的key为弱引用回收ThreadLocal时，由于ThreadLocalMap持有ThreadLocal的弱引用，即使没有手动删除，ThreadLocal也会被回收。当key为null时，调用完set方法之后，在调用remove方法的时候会清除value值。

**因此，内存泄漏的根源是**：由于ThreadLocalMap的生命周期跟Thread一样长，如果没有手动删除对应key的value,就会导致内存泄漏，而不是因为弱引用。

ThreadLocal正确的使用姿势：每次使用完ThreadLocal都调用它的remove()方法清除数据 .

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\分布式\线程、并发\image\图片_dHnqcEF5-_.png)

### 14、并发的三大特征

-   **原子性：**

原子性是指在一个操作中cpu不可以在中途暂停然后再调度，即不被中断操作，要不全部执行完成，要不都不执行。就好比转账，从账户A向账户B转1000元，那么必然包括2个操作：从账户A减去1000元，往账户B加上1000元。2个操作必须全部完成。

```java
private long count = 0;
public void calc() {
count++;
}
```

1：将 count 从主存读到工作内存中的副本中
2：+1的运算
3：将结果写入工作内存
4：将工作内存的值刷回主存(什么时候刷入由操作系统决定，不确定的)

那程序中原子性指的是最小的操作单元，比如自增操作，它本身其实并不是原子性操作，分了3步的，包括读取变量的原始值、进行加1操作、写入工作内存。所以在多线程中，有可能一个线程还没自增完，可能才执行到第二部，另一个线程就已经读取了值，导致结果错误。那如果我们能保证自增操作是一个原子性的操作，那么就能保证其他线程读取到的一定是自增后的数据。

**关键字：synchronize**d

-   **可见性**

当多个线程访问同一个变量时，一个线程修改了这个变量的值，其他线程能够立即看得到修改的值。若两个线程在不同的cpu，那么线程1改变了i的值还没刷新到主存，线程2又使用了i，那么这个i值肯定还是之前的，线程1对变量的修改线程没看到这就是可见性问题。

```java
//线程1
boolean stop = false;
while(!stop){
doSomething();
}
//线程2
stop = true;
```

如果线程2改变了stop的值，线程1一定会停止吗？不一定。当线程2更改了stop变量的值之后，但是还没来得及写入主存当中，线程2转去做其他事情了，那么线程1由于不知道线程2对stop变量的更改，因此还会一直循环下去。

**关键字**：**volatile、synchronized、fina**l

-   **有序性**

虚拟机在进行代码编译时，对于那些改变顺序之后不会对最终结果造成影响的代码，虚拟机不一定会按照我们写的代码的顺序来执行，有可能将他们重排序。实际上，对于有些代码进行重排序之后，虽然对变量的值没有造成影响，但有可能会出现线程安全问题。

```java
int a = 0;
bool flag = false;
public void write() {
a = 2; //1
flag = true; //2
}
public void multiply() {
if (flag) { //3
int ret = a * a;//4
}
}
```

write方法里的1和2做了重排序，线程1先对flag赋值为true，随后执行到线程2，ret直接计算出结果，再到线程1，这时候a才赋值为2,很明显迟了一步。
**关键字：volatile、synchronized**

volatile本身就包含了禁止指令重排序的语义，而synchronized关键字是由“一个变量在同一时刻只允许一条线程对其进行lock操作”这条规则明确的。

**synchronized关键字同时满足以上三种特性，但是volatile关键字不满足原子性。**

在某些情况下，volatile的同步机制的性能确实要优于锁(使用synchronized关键字或
java.util.concurrent包里面的锁)，因为volatile的总开销要比锁低。

我们判断使用volatile还是加锁的唯一依据就是volatile的语义能否满足使用的场景(原子性)

### 15、JMM内存模型

Java内存模型(Java Memory Model简称JMM)是一**种抽象的概念，并不真实存在**，它描述的是一组规则或规范，通过这组规范定义了程序中各个变量（包括实例字段，静态字段）的访问方式。JVM运行程序的实体是线程，而每个线程创建时JVM都会为 其创建一个工作内存(有些地方称为栈空间)，用于存储线程私有的数据，而Java内存模型中规定**所有变量都存储在主内存，主内存是共享内存区域，所有线程都可以访问，但线程对变量的操作(读取赋值等)必须在工作内存中进行**，首先要将变量从主内存拷贝的自己的工作内存中，然后对变量进行操作，操作完成后再将变量写回主内存，**不能直接操作主内存中的变量**， 工作内存中存储着主内存中的变量副本拷贝，前面说过，工作内存是每个线程的私有数据区域，因此不同的线程间无法访问对方的工作内存，线程间的通信(传值)必须通过主内存来完成。

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\分布式\线程、并发\image\图片_R66erzjjFI.png)

JMM规定了内存主要划分为**主内存**和**工作内存**两种。

**主内存**：主要存储的是**Java实例对象**，所有线程创建的实例对象都存放在主内存中，当然也包括了共享的**类信息、常量、静态变量**。由于是共享数据区域，多条线程对同一个变量进行访问可能会发生线程安全问题。

**共享变量**：如果一个变量被多个线程使用，那么这个变量会在每个线程的工作内存中保有一个副本，这种变量就是共享变量。

**工作内存**：主要存储当前方法的所有本地变量信息(工作内存中存储着主内存中的变量副本拷贝)，每 个线程只能访问自己的工作内存，即线程中的本地变量对其它线程是不可见的，就算是两个线 程执行的是同一段代码，它们也会各自在自己的工作内存中创建属于当前线程的本地变量，当 然也包括了字节码行号指示器、相关Native方法的信息。注意由于工作内存是每个线程的私有数据，线程间无法相互访问工作内存，因此存储在工作内存的数据不存在线程安全问题。

模型入下图：（基于JMM规范）

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\分布式\线程、并发\image\图片_pts96onzfj.png)

```text
注意：

**JMM**不同于**JVM内存区域模型** 
JMM与JVM内存区域的划分是**不同的概念层次**，更恰当说JMM描述的是一组规则，
通过 这组规则控制程序中各个变量在共享数据区域和私有数据区域的访问方式，JMM是围绕原子性，有序性、可见性展开。
JMM与Java内存区域唯一相似点，都存在共享数据区域和私有数据区域，在JMM中主内存属于共享数据区域，
从某个程度上讲应该包括了堆和方法区，而工作内存数据线程私有数据区域，从某个程度上讲则应该包括程序计数器、虚拟机栈以及本地方法栈。
```

```纯文本
JMM对共享内存的操作做出了如下两条规定：
- 线程对共享内存的所有操作都必须在自己的工作内存中进行，不能直接从主内存中写；
- 不同线程无法直接访问其他线程工作内存中的变量，因此共享变量的值传递需要通过主内存完成。

```

### 16、JVM存在的必要性

由于JVM运行程序的实体是线程，而每个线程创建时JVM都会为其创建一个工作内存(有些地方称为栈空间)，用于存储线程私有的数据，线程与主内存中的变量操作必须通过工作内存间接完成，主要过程是将变量从主内存拷贝的每个线程各自的工作内存空间，然后对变量进行操作，操作完成后再将变量写回主内存，那么如果存在两个线程同时对一个主内存中的实例对象的变量进行操作就有可能诱发线程安全问题。

假设主内存中存在一个共享变量x（初始值为1），现在有A和B两条线程分别对该变量x=1进行操作， A/B线程各自的工作内存中存在共享变量副本x。假设现在A线程想要修改x的值为2，而B线程却想要读取x的值，那么B线程读取到的值是A线程更新后的值2还是更新前的值1呢？答案是，不确定。

即B线程有可能读取到A线程更新前的值1，也有可能读取到A线程更新后的值2，这是 因为工作内存是每个线程私有的数据区域，而线程A操作变量x时（**即将x=1拷贝到自己的工作内存中**），首先是将变量从主内存拷贝到A线程的工作内存中，然后对变量进行操作，操作完成后再将变量x写回主内存，而对于B线程的也是类似的，这样就有可能造成主内存与工作内存间数据存在一致性问题，假如A线程修改完后正在将数据写回主内存，而B线程此时正在读取主内存， 这样B线程读取到的值就是x=1，但如果A线程已将x=2写回主内存后，B线程才开始读取的话，那么此时B线程读取到的就是x=2。

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\分布式\线程、并发\image\图片_5hzzNKrzR3.png)

### 17、谈谈Volatile关键字的理解

#### 1、验证可见性

```java
public class VolatileDemo {

    static Integer int flag = 1;
    //static  volatile Integer int flag = 1;
    public static void main(String[] args) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                System.out.println("我是子线程A工作内存flag的值：" + flag);
                while (flag == 1) {

                }
                System.out.println("子线程结束:"+flag);
            }
        }, "A").start();
        try {
            Thread.sleep(1000);//让线程完全启动
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        flag = 2;
        System.out.println("我是主线程工作内存flag的值：" + flag);
    }
}
```

#### 2、验证有序性

```java
public class VolatileOrderDemo {
    static int x, y;
    static int a, b;
     //static int x, y;
    //static volatile int a, b;

    public static void main(String[] args) throws InterruptedException {
        int i = 0;
        while (true) {
            i++;
            a = b = x = y = 0;
            Thread thread1 = new Thread(() -> {
                a = 1;
                x = b;
            });

            Thread thread2 = new Thread(() -> {
                b = 1;
                y = a;
            });
            thread1.start();
            thread2.start();
             Thread.sleep(10);
            thread1.join();
            thread2.join();
            System.out.println("第" + i + "次打印：x=" + x + ",y=" + y);
            if (x == 0 && y == 0) {
                break;
            }
        }
        
    }
}
```

#### 3、不具备原子性

```java
class MyAtomic {
    private Integer number = 0;
    public int incr() {
      return number++;
    }
}

public class VolatileAtomicDemo {
    public static void main(String[] args) {
        MyAtomic myAtomic = new MyAtomic();

        for (int i = 0; i <1000 ; i++) {
            new Thread(()->{
                System.out.println(myAtomic.incr());
            }).start();
        }
    }
}
```

### 18、为什么用线程池？解释下线程池参数？

1、降低资源消耗；提高线程利用率，降低创建和销毁线程的消耗。
2、提高响应速度；任务来了，直接有线程可用可执行，而不是先创建线程，再执行。
3、提高线程的可管理性；线程是稀缺资源，使用线程池可以统一分配调优监控。

**线程池参数：****corePoolSize** 代表核心线程数，也就是正常情况下创建工作的线程数，这些线程创建后并不会
消除，而是一种常驻线程。

**maxinumPoolSize** 代表的是最大线程数，它与核心线程数相对应，表示最大允许被创建的线程数，比如当前任务较多，将核心线程数都用完了，还无法满足需求时，此时就会创建新的线程，但是线程池内线程总数不会超过最大线程数。
**keepAliveTime 、 unit** 表示超出核心线程数之外的线程的空闲存活时间，也就是核心线程不会
消除，但是超出核心线程数的部分线程如果空闲一定的时间则会被消除,我们可以通过
setKeepAliveTime 来设置空闲时间。

\*\*workQueue \*\*用来存放待执行的任务，假设我们现在核心线程都已被使用，还有任务进来则全部放
入队列，直到整个队列被放满但任务还再持续进入则会开始创建新的线程。

**ThreadFactory** 实际上是一个线程工厂，用来生产线程执行任务。我们可以选择使用默认的创建
工厂，产生的线程都在同一个组内，拥有相同的优先级，且都不是守护线程。当然我们也可以选择
自定义线程工厂，一般我们会根据业务来制定不同的线程工厂。

**Handler** 任务拒绝策略，有两种情况，第一种是当我们调用 shutdown 等方法关闭线程池后，这
时候即使线程池内部还有没执行完的任务正在执行，但是由于线程池已经关闭，我们再继续想线程
池提交任务就会遭到拒绝。另一种情况就是当达到最大线程数，线程池已经没有能力继续处理新提
交的任务时，这是也就拒绝。

### 19、JUC线程池的工作原理

1. 在创建了线程池后，线程池中的**线程数为零**。

2. 当调用execute()方法添加一个请求任务时，线程池会做出如下判断：

   1.  如果正在运行的线程数量**小于corePoolSize**，那么马上**创建线程**运行这个任务；
   2.  如果正在运行的线程数量**大于或等于corePoolSize**，那么**将这个任务放入队列**；
   3.  如果这个时候队列满了且正在运行的线程数量还**小于maximumPoolSize**，那么还是要**创建非核心线程**立刻运行这个任务；
   4.  如果队列满了且正在运行的线程数量**大于或等于maximumPoolSize**，那么线程池会**启动默认的拒绝策略**来执行。

3. 当一个线程完成任务时，它会从队列中取下一个任务来执行。

4. 当一个线程无事可做超过一定的时间（keepAliveTime）时，线程会判断：

   如果当前运行的线程数大于corePoolSize，那么这个线程就被停掉。

   所以线程池的所有任务完成后，**它最终会收缩到corePoolSize的大小**。

   ![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\分布式\线程、并发\image\图片_z_iqFdLZ0X.png)

**注意：提交一个Runnable时，不管当前线程池中的线程是否空闲，只要数量小于核心线程数就会创建新线程。**

**注意：ThreadPoolExecutor相当于是非公平的，比如队列满了之后提交的Runnable可能会比正在排队的Runnable先执行。**

### 20、线程池的五种状态是如何流转的

线程池有五种状态：

-   RUNNING：**会**接收新任务并且**会**处理队列中的任务
-   SHUTDOWN：**不会**接收新任务并且**会**处理队列中的任务
-   STOP：**不会**接收新任务并且**不会**处理队列中的任务，并且会中断在处理的任务。
-   TIDYING：所有任务都终止了，线程池中也没有线程了，这样线程池的状态就会转为TIDYING，一旦达到此状态，就会调用线程池的terminated()
-   TERMINATED：terminated()执行完之后就会转变为TERMINATED

这五种状态并不能任意转换，只会有以下几种转换情况：

1.  RUNNING -> SHUTDOWN：手动调用shutdown()触发，或者线程池对象GC时会调用finalize()从而调用shutdown()
2.  (RUNNING or SHUTDOWN) -> STOP：调用shutdownNow()触发，如果先调shutdown()紧着调shutdownNow()，就会发生SHUTDOWN -> STOP
3.  SHUTDOWN -> TIDYING：队列为空并且线程池中没有线程时自动转换
4.  STOP -> TIDYING：线程池中没有线程时自动转换（队列中可能还有任务）
5.  TIDYING -> TERMINATED：terminated()执行完后就会自动转换

### 21 **、线程池为什么一定得是阻塞队列？**

线程池中的线程在运行过程中，执行完创建线程时绑定的第一个任务后，就会不断的从队列中获取任务并执行，那么如果队列中没有任务了，线程为了不自然消亡，就会阻塞在获取队列任务时，等着队列中有任务过来就会拿到任务从而去执行任务。

通过这种方法能最终确保，线程池中能保留指定个数的核心线程数，关键代码：

```java
try {
    Runnable r = timed ?
        workQueue.poll(keepAliveTime, TimeUnit.NANOSECONDS) :
        workQueue.take();
    if (r != null)
        return r;
    timedOut = true;
} catch (InterruptedException retry) {
    timedOut = false;
}
```

某个线程在从队列获取任务时，会判断是否使用超时阻塞获取，我们可以认为非核心线程会poll()，核心线程会take()，非核心线程超过时间还没获取到任务后面就会自然消亡了。

### 22、**线程发生异常，会被移出线程池吗？**

答案是会的，那有没有可能核心线程数在执行任务时都出错了，导致所有核心线程都被移出了线程池？

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\分布式\线程、并发\image\图片_FD74SVkOhX.png)

在源码中，当执行任务时出现异常时，最终会执行processWorkerExit()，执行完这个方法后，当前线程也就自然消亡了，但是！processWorkerExit()方法中会额外再新增一个线程，这样就能维持住固定的核心线程数。

### 23、**线程池的核心线程数、最大线程数该如何设置？**

我们都知道，线程池中有两个非常重要的参数：

1.  corePoolSize：核心线程数，表示线程池中的常驻线程的个数
2.  maximumPoolSize：最大线程数，表示线程池中能开辟的最大线程个数

那这两个参数该如何设置呢？

我们对线程池负责执行的任务分为三种情况：

1.  CPU密集型任务，比如找出1-1000000中的素数
2.  IO密集型任务，比如文件IO、网络IO
3.  混合型任务

CPU密集型任务的特点时，线程在执行任务时会一直利用CPU，所以对于这种情况，就尽可能避免发生线程上下文切换。

比如，现在我的电脑只有一个CPU，如果有两个线程在同时执行找素数的任务，那么这个CPU就需要额外的进行线程上下文切换，从而达到线程并发的效果，此时执行这两个任务的总时间为：

任务执行时间\*2+线程上下文切换的时间

而如果只有一个线程，这个线程来执行两个任务，那么时间为：

任务执行时间\*2

所以对于CPU密集型任务，线程数最好就等于CPU核心数，可以通过以下API拿到你电脑的核心数：

```java
Runtime.getRuntime().availableProcessors()
```

只不过，为了应对线程执行过程发生异常导致线程阻塞的请求，我们可以额外在多设置一个线程，这样当某个线程暂时不需要CPU时，可以有替补线程来继续利用CPU。

所以，对于CPU密集型任务，我们可以设置线程数为：**CPU核心数+1**

我们在来看IO型任务，线程在执行IO型任务时，可能大部分时间都阻塞在IO上，假如现在有10个CPU，如果我们只设置了10个线程来执行IO型任务，那么很有可能这10个线程都阻塞在了IO上，这样这10个CPU就都没活干了，所以，对于IO型任务，我们通常会设置线程数为：**2\*CPU核心数**

不过，就算是设置为了**2\*CPU核心数**，也·不一定是最佳的，比如，有10个CPU，线程数为20，那么也有可能这20个线程同时阻塞在了IO上，所以可以再增加线程，从而去压榨CPU的利用率。

**通常，如果IO型任务执行的时间越长，那么同时阻塞在IO上的线程就可能越多，我们就可以设置更多的线程，但是，线程肯定不是越多越好**，我们可以通过以下这个公式来进行计算：

线程数 = CPU核心数   \*（ 1 + 线程等待时间 / 线程运行总时间 ）

-   线程等待时间：指的就是线程没有使用CPU的时间，比如阻塞在了IO
-   线程运行总时间：指的是线程执行完某个任务的总时间

我们可以利用jvisualvm抽样来估计这两个时间：

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\分布式\线程、并发\image\图片_VUefthp135.png)

图中表示，在刚刚这次抽样过程中，run()总共的执行时间为92567ms，利用了CPU的时间为11027ms，所以没有利用CPU的时间为92567ms-11027ms。

所以我们可以计算出：

线程等待时间 = 92567ms-11027ms。

线程运行总时间 =92567ms

所以：线程数 = 20 \*（ 1 + （92567ms-11027ms） / 92567ms ）= [37.xxx](http://37.xxx "37.xxx")

所以根据公式算出来的线程为37、38个线程左右。

按上述公式，如果我们执行的任务IO密集型任务，那么：线程等待时间 = 线程运行总时间，所以：

线程数 = CPU核心数 \*（ 1 + 线程等待时间 / 线程运行总时间 ）

\= CPU核心数 \*（ 1 + 1 ）

\= CPU核心数 \* 2

以上只是理论，实际工作中情况会更复杂，比如一个应用中，可能有多个线程池，除开线程池中的线程可能还有很多其他线程，或者除开这个应用还是一些其他应用也在运行，所以实际工作中如果要确定线程数，最好是压测。

```java
@RestController
public class HzkController {

    @GetMapping("/test")
    public String test() throws InterruptedException {
        Thread.sleep(1000);
        return "success";
    }

}
```

这个接口会执行1s，我现在利用apipost来压：

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\分布式\线程、并发\image\图片_fMbUlb-G1y.png)

这是在Tomcat默认最大200个线程的请求下的压测结果。

当我们把线程数调整为500：

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\分布式\线程、并发\image\图片_RCdvsOQwcf.png)

发现执行效率提高了一倍，假如再增加线程数到1000：

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\分布式\线程、并发\image\图片_6BxT9tlpIO.png)

提升就不那么高了。

总结，我们再工作中，对于：

1.  CPU密集型任务：CPU核心数+1，这样既能充分利用CPU，也不至于有太多的上下文切换成本
2.  IO型任务：建议压测，或者先用公式计算出一个理论值（理论值通常都比较小）
3.  对于核心业务（访问频率高），可以把核心线程数设置为我们压测出来的结果，最大线程数可以等于核心线程数，或者大一点点，比如我们压测时可能会发现500个线程最佳，但是600个线程时也还行，此时600就可以为最大线程数
4.  对于非核心业务（访问频率不高），核心线程数可以比较小，避免操作系统去维护不必要的线程，最大线程数可以设置为我们计算或压测出来的结果。

### 24、Tomcat是如何自定义线程池的？

Tomcat中用的线程池为org.apache.tomcat.util.threads.ThreadPoolExecutor，注意类名和JUC下的一样，但是包名不一样。

Tomcat会创建这个线程:

```java
public void createExecutor() {
    internalExecutor = true;
    TaskQueue taskqueue = new TaskQueue();
    TaskThreadFactory tf = new TaskThreadFactory(getName() + "-exec-", daemon, getThreadPriority());
    executor = new ThreadPoolExecutor(getMinSpareThreads(), getMaxThreads(), 60, TimeUnit.SECONDS,taskqueue, tf);
    taskqueue.setParent( (ThreadPoolExecutor) executor);
}
```

注意传入的队列为TaskQueue，它的入队逻辑为:

```java
public boolean offer(Runnable o) {
    //we can't do any checks
    if (parent==null) {
        return super.offer(o);
    }

    //we are maxed out on threads, simply queue the object
    if (parent.getPoolSize() == parent.getMaximumPoolSize()) {
        return super.offer(o);
    }

    //we have idle threads, just add it to the queue
    if (parent.getSubmittedCount()<=(parent.getPoolSize())) {
        return super.offer(o);
    }

    //if we have less threads than maximum force creation of a new thread
    if (parent.getPoolSize()<parent.getMaximumPoolSize()) {
        return false;
    }

    //if we reached here, we need to add it to the queue
    return super.offer(o);
}
```

特殊在：

-   入队时，如果线程池的线程个数等于最大线程池数入队。
-   入队时，如果线程池有闲置线程，任务依旧入队。
-   入队时，如果线程池的线程个数小于最大线程池数，会返回false，表示入队失败，则去创建线程。

这样就控制了，Tomcat的这个线程池，在提交任务时：

1.  不会先判断线程个数是否小于核心线程数，而是提前创建10个核心线程。
2.  如果等于最大线程数，会入队，但是线程个数小于最大线程数会入队失败，从而会去创建线程

所以随着任务的提交，会优先创建线程，直到线程个数等于最大线程数才会入队。

当然其中有一个比较细的逻辑是：在提交任务时，如果正在处理的任务数小于线程池中的线程个数，那么也会直接入队，而不会去创建线程，也就是上面源码中getSubmittedCount的作用。

### 25、volatile变量和atomic变量有什么区别？

答：首先，volatile变量看起来像atomic变量，但功能不同。Volatile变量可以保证先行关系，即后续读操作前会发生写操作， 但它不能保证原子性。例如，如果用volatile修改count变量，那么counttile++ 操作不是原子性的。Atomicinteger类提供的Atomic方法可以使该操作具有原子性，如getandincrement()方法可以增加原子性，并添加当前值，其他数据类型和引用变量也可以进行类似的操作。





#                                                缓存

## Redis

### 1 、Redis是AP的还是CP的？

Redis是一个支持多种数据结构的内存数据库，它可以根据配置和使用方式在AP和CP之间做出选择。具体来说，Redis可以在不同的场景下提供不同的一致性级别：

1\. 在默认情况下，Redis追求最高的性能和可用性，更倾向于AP模型（即可用性优先）。它使用主从复制和哨兵机制来实现高可用性，但在出现网络分区或节点故障时，可能会导致数据的不一致性。

2\. 但是，Redis也提供了一些支持一致性的特性，例如Redis Cluster和Redis Sentinel。通过使用这些特性，Redis可以在需要更高一致性的场景下选择CP模型（即一致性优先）。在Redis Cluster中，数据被分片存储在不同的节点上，并使用Gossip协议来保持数据的一致性。Redis Sentinel则提供了监控和自动故障转移的功能，以保证高可用性和数据的一致性。

因此，根据具体的配置和使用方式，Redis可以在AP和CP之间进行选择。

### 2 、介绍一下Redis的集群方案？

**1、主从模式：**

**2、哨兵模式：**
sentinel，哨兵是 redis 集群中非常重要的一个组件，主要有以下功能：

-   集群监控：负责监控 redis master 和 slave 进程是否正常工作。
-   消息通知：如果某个 redis 实例有故障，那么哨兵负责发送消息作为报警通知给管理员。
-   故障转移：如果 master node 挂掉了，会自动转移到 slave node 上。
-   配置中心：如果故障转移发生了，通知 client 客户端新的 master 地址。

哨兵用于实现 redis 集群的高可用，本身也是分布式的，作为一个哨兵集群去运行，互相协同工作。

-   故障转移时，判断一个 master node 是否宕机了，需要大部分的哨兵都同意才行，涉及到了分布式选举
-   即使部分哨兵节点挂掉了，哨兵集群还是能正常工作的
-   哨兵通常需要 3 个实例，来保证自己的健壮性
-   哨兵 + redis 主从的部署架构，是不保证数据零丢失的，只能保证 Redis 集群的高可用性。
    对于哨兵 + redis 主从这种复杂的部署架构，尽量在测试环境和生产环境，都进行充足的测试和演练。

**3、Redis Cluster模式：**

Redis Cluster是一种服务端Sharding技术，3.0版本开始正式提供。采用slot(槽)的概念，一共分成16384个槽。将请求发送到任意节点，接收到请求的节点会将查询请求发送到正确的节点上执行。

**方案说明**：

-   通过哈希的方式，将数据分片，每个节点均分存储一定哈希槽(哈希值)区间的数据，默认分配了16384 个槽位
-   每份数据分片会存储在多个互为主从的多节点上
-   数据写入先写主节点，再同步到从节点(支持配置为阻塞同步)
-   同一分片多个节点间的数据不保持强一致性
-   读取数据时，当客户端操作的key没有分配在该节点上时，redis会返回转向指令，指向正确的节点
-   扩容时需要需要把旧节点的数据迁移一部分到新节点

在 Redis Cluster 架构下，每个 Redis 要放开两个端口号，比如一个是 6379，另外一个就是加1w 的端口号，比如 16379。
16379 端口号是用来进行节点间通信的，也就是 cluster bus 的通信，用来进行故障检测、配置更新、故障转移授权。cluster bus 用了另外一种二进制的协议，gossip 协议，用于节点间进行高效的数据交换，占用更少的网络带宽和处理时间。

**优点：**

-   无中心架构，支持动态扩容，对业务透明
-   具备Sentinel的监控和自动Failover(故障转移)能力
-   客户端不需要连接集群所有节点，连接集群中任何一个可用节点即可
-   高性能，客户端直连redis服务，免去了proxy代理的损耗

**缺点：**

-   运维也很复杂，数据迁移需要人工干预
-   只能使用0号数据库
-   不支持批量操作(pipeline管道操作)
-   分布式逻辑和存储模块耦合等

Redis Sharding是Redis Cluster出来之前，业界普遍使用的多Redis实例集群方法。其主要思想是采用
哈希算法将Redis数据的key进行散列，通过hash函数，特定的key会映射到特定的Redis节点上。Java
redis客户端驱动jedis，支持Redis Sharding功能，即ShardedJedis以及结合缓存池的
ShardedJedisPool

**优点:**
优势在于非常简单，服务端的Redis实例彼此独立，相互无关联，每个Redis实例像单服务器一样运行，非常容易线性扩展，系统的灵活性很强
**缺点:**
由于sharding处理放到客户端，规模进一步扩大时给运维带来挑战。
客户端sharding不支持动态增删节点。服务端Redis实例群拓扑结构有变化时，每个客户端都需要更新调整。连接不能共享，当应用规模增大时，资源浪费制约优化

### 3 、什么是Redis的数据分片？

Redis的数据分片是一种数据分布在多个节点上的技术，用于实现水平扩展和负载均衡。在Redis中，数据分片是通过哈希槽（Hash Slot）来实现的。

具体而言，数据分片的过程如下：

1\. 哈希槽的定义：Redis将整个数据空间划分为固定数量的哈希槽，通常是16384个。每个哈希槽都有一个唯一的标识符，从0到16383。

2\. 数据的映射：当客户端发送一个命令请求时，Redis Cluster通过对的哈希值进行计算，将键值对映射到一个特定的哈希槽中。这样，每个键值对就被分配到了一个特定的哈希槽中。

3\. 哈希槽的分配：Redis Cluster将所有的哈希槽均匀地分配给各个节点，每个节点负责存储一部分哈希槽对应的数据。这样，数据就被分片存储在了多个节点上。

4\. 数据的查找：当客户端需要访问某个键值对时，它首先计算键的哈希值，然后根据哈希值找到对应的哈希槽。客户端根据哈希槽的信息找到负责该哈希槽的节点，并将请求发送给该节点。

5\. 数据的迁移：当需要添加或删除节点时，Redis Cluster会进行数据的迁移，以保持各个节点负载均衡。数据迁移的过程中，哈希槽会从一个节点移动到另一个节点，保证数据的分片均匀和一致。通过数据分片，Redis可以在多个节点上并行处理请求，提高了系统的吞吐量和容量。

同时，数据分片还实现了负载均衡和故障隔离，当某个节点故障时，其他节点仍然可以继续提供服务。总的来说，Redis的数据分片通过哈希槽的方式，将数据分布在多个节点上，实现了水平扩展、负载均衡和故障隔离。

### 4 、Redis为什么这么快？

Redis之所以被认为是快速的，主要有以下几个原因：

1.  内存存储：Redis将数据存储在内存中，而不是磁盘上。相比于磁盘访问内存访问速度更快，可以实现很低的延迟和高吞吐量。
2.  单线程模型：Redis采单线程模型，避免了多线程间的竞争和上下文切换的开销。线程模型简化了并发控制，减少了锁的使用，提高了处理请求的效率。
3.  高效的数据结构：Redis提供了多种高效的数据结构，如字符串、哈希表、跳跃表、集合和有序集合等。这些数据结构在内部实现上都经过了优化，能够快速地进行插入、删除、查找和遍历操作。
4.  异步操作：Redis支持异步操作，可以在后台执行一些耗时的操作，如持久化、复制和集群的同步等。这样可以减少客户端的等待时间，提高系统的响应速度。
5.  **高效的网络通信**（**核心**）：Redis自定义的RESP协议进行网络通信，协议本身简单而高效。Redis的网络通信采用非阻塞I/O多路复用机制和事件驱动的方式，可以处理大量的并发连接，提高了系统的并发性能。
6.  优化的算法和数据结构：Redis在内部实现中使用了许多优化的算法和数据结构。例如，使用跳跃表（Skip List）来实现有序集合，使用压缩列表（ziplist）来存储小规模的列表和哈希表等。这些优化可以减少内存占用和提高数据操作的效率。

总的来说，Redis之所以快速，是因为它使用内存存储、采用单线程模型、提供高效的数据结构、支持异步操作、优化网络通信和使用优化的算法和数据结构等。这些特性使得能够在处理大量请求时保持低延迟和高吞吐量。

### 5、 Redis 的事务机制是怎样的？

**1、事务开始**
MULTI命令的执行，标识着一个事务的开始。MULTI命令会将客户端状态的 flags 属性中打开
REDIS\_MULTI 标识来完成的。

**2、命令入队**
当一个客户端切换到事务状态之后，服务器会根据这个客户端发送来的命令来执行不同的操作。如果客户端发送的命令为MULTI、EXEC、WATCH、DISCARD中的一个，立即执行这个命令，否则将命令放入一个事务队列里面，然后向客户端返回 QUEUED 回复

-   如果客户端发送的命令为 EXEC、DISCARD、WATCH、MULTI 四个命令的其中一个，那么服务器
    立即执行这个命令。
-   如果客户端发送的是四个命令以外的其他命令，那么服务器并不立即执行这个命令。
    首先检查此命令的格式是否正确，如果不正确，服务器会在客户端状态（RedisClient）的 flags 属性关闭 REDIS\_MULTI 标识，并且返回错误信息给客户端。

如果正确，将这个命令放入一个事务队列里面，然后向客户端返回 QUEUED 回复

**3、事务执行**

客户端发送 EXEC 命令，服务器执行 EXEC 命令逻辑。

-   如果客户端状态的 flags 属性不包含 REDIS\_MULTI 标识，或者包含 REDIS\_DIRTY\_CAS 或者
    REDIS\_DIRTY\_EXEC 标识，那么就直接取消事务的执行。
-   否则客户端处于事务状态（flags 有 REDIS\_MULTI 标识），服务器会遍历客户端的事务队列，然后执行事务队列中的所有命令，最后将返回结果全部返回给客户端；

Redis 不支持事务回滚机制，但是它会检查每一个事务中的命令是否错误。
Redis 事务不支持检查那些程序员自己逻辑错误。例如对 String 类型的数据库键执行对HashMap 类型的操作！

**WATCH** 命令是一个乐观锁，可以为 Redis 事务提供 check-and-set （CAS）行为。可以监控一个或多个键，一旦其中有一个键被修改（或删除），之后的事务就不会执行，监控一直持续到EXEC命令。

**MULTI**命令用于开启一个事务，它总是返回OK。MULTI执行之后，客户端可以继续向服务器发送任意多条命令，这些命令不会立即被执行，而是被放到一个队列中，当EXEC命令被调用时，所有队列中的命令才会被执行。

**EXEC：** 执行所有事务块内的命令。返回事务块内所有命令的返回值，按命令执行的先后顺序排
列。当操作被打断时，返回空值 nil 。
通过调用DISCARD，客户端可以清空事务队列，并放弃执行事务， 并且客户端会从事务状态中退
出。

**UNWATCH**命令可以取消watch对所有key的监控

### 6 、Redis的持久化机制是怎样的？

Redis提供了两种方式的持久化机制，分别是RDB快照和AOF日志。

**RDB：Redis DataBase**
在指定的时间间隔内将内存中的数据集快照写入磁盘，实际操作过程是fork一个子进程，先将数据集写入临时文件，写入成功后，再替换之前的文件，用二进制压缩存储。

**优点：**
1、整个Redis数据库将只包含一个文件 dump.rdb，方便持久化。
2、容灾性好，方便备份。
3、性能最大化，fork 子进程来完成写操作，让主进程继续处理命令，所以是 IO 最大化。使用单独子进程来进行持久化，主进程不会进行任何 IO 操作，保证了 redis 的高性能
4.相对于数据集大时，比 AOF 的启动效率更高。

**缺点：**
1、数据安全性低。RDB 是间隔一段时间进行持久化，如果持久化之间 redis 发生故障，会发生数据丢失。所以这种方式更适合数据要求不严谨的时候)
2、由于RDB是通过fork子进程来协助完成数据持久化工作的，因此，如果当数据集较大时，可能会导致整个服务器停止服务几百毫秒，甚至是1秒钟。

**AOF：Append Only File**
以日志的形式记录服务器所处理的每一个写、删除操作，查询操作不会记录，以文本的方式记录，可以打开文件看到详细的操作记录。

**优点：**
1、数据安全，Redis中提供了3中同步策略，即每秒同步、每修改同步和不同步。事实上，每秒同步也是异步完成的，其效率也是非常高的，所差的是一旦系统出现宕机现象，那么这一秒钟之内修改的数据将会丢失。而每修改同步，我们可以将其视为同步持久化，即每次发生的数据变化都会被立即记录到磁盘中。。
2、通过 append 模式写文件，即使中途服务器宕机也不会破坏已经存在的内容，可以通过 redis-
check-aof 工具解决数据一致性问题。
3、AOF 机制的 rewrite 模式。定期对AOF文件进行重写，以达到压缩的目的

**缺点：**
1、AOF 文件比 RDB 文件大，且恢复速度慢。
2、数据集大的时候，比 rdb 启动效率低。
3、运行效率没有RDB高。

**AOF和RDB对比：**

-   AOF文件比RDB更新频率高，优先使用AOF还原数据。
-   AOF比RDB更安全也更大
-   RDB性能比AOF
-   如果两个都配了优先加载AOF

| **比较**       | **AOF**            | **RDB**            |
| -------------- | ------------------ | ------------------ |
| 默认选择       | No                 | Yes                |
| 数据格式       | RESP格式所有写命令 | 压缩的二进制文件   |
| 数据的安全性   | 三种写回策略决定   | 分钟级别数据的丢失 |
| 文件大小       | 大                 | 小                 |
| 恢复速度       | 慢                 | 快                 |
| 重写机制       | Yes                | No                 |
| 重写阻塞主线   | No                 | No                 |
| Redis的性能    | 三种写回策略决定   | 分钟级别的快照     |
| 数据恢复的选择 | Yes                | No                 |

### 7、 Redis 的过期策略是怎么样的？

Redis是key-value数据库，我们可以设置Redis中缓存的key的过期时间。Redis的过期策略就是指当Redis中缓存的key过期了，Redis如何处理。

**惰性过期**：只有当访问一个key时，才会判断该key是否已过期，过期则清除。该策略可以最大化地节省CPU资源，却对内存非常不友好。极端情况可能出现大量的过期key没有再次被访问，从而不会被清除，占用大量内存。

**定期过期**：每隔一定的时间，会扫描一定数量的数据库的expires字典中一定数量的key，并清除其中已过期的key。该策略是一个折中方案。通过调整定时扫描的时间间隔和每次扫描的限定耗时，可以在不同情况下使得CPU和内存资源达到最优的平衡效果。

(expires字典会保存所有设置了过期时间的key的过期时间数据，其中，key是指向键空间中的某个键的指针，value是该键的毫秒精度的UNIX时间戳表示的过期时间。键空间是指该Redis集群中保存的所有键。)

Redis中同时使用了惰性过期和定期过期两种过期策略。

### 8 、Redis的内存淘汰策略是怎么样的？

Redis 4.0 之前一共实现了 6 种内存淘汰策略，在 4.0 之后，又增加了 2 种策略。我们可以按照是否会进行数据淘汰把它们分成两类：

-   不进行数据淘汰的策略，只有 noeviction 这一种。
-   会进行淘汰的 7 种其他策略。
    -

会进行淘汰的 7 种策略，再进一步根据淘汰候选数据集的范围把它们分成两类：

-   在设置了过期时间的数据中进行淘汰，包括 volatile-random、volatile-ttl、volatile-lru、volatile-lfu（Redis 4.0 后新增）四种。
-   在所有数据范围内进行淘汰，包括 allkeys-lru、allkeys-random、allkeys-lfu（Redis 4.0 后新增）三种。

具体解释下各个策略：

默认情况下，Redis 在使用的内存空间超过 maxmemory 值时，并不会淘汰数据，也就是设定的 noeviction 策略。对应到 Redis 缓存，也就是指，一旦缓存被写满了，再有写请求来时，Redis 不再提供服务，而是直接返回错误。Redis 用作缓存时，实际的数据集通常都是大于缓存容量的，总会有新的数据要写入缓存，这个策略本身不淘汰数据，也就不会腾出新的缓存空间，我们不把它用在 Redis 缓存中。

接着 volatile-random、volatile-ttl、volatile-lru 和 volatile-lfu 这四种淘汰策略。它们筛选的候选数据范围，被限制在已经设置了过期时间的键值对上。也正因为此，即使缓存没有写满，这些数据如果过期了，也会被删除。

比如我们使用 EXPIRE 命令对一批键值对设置了过期时间后，无论是这些键值对的过期时间是快到了，还是 Redis 的内存使用量达到了 maxmemory 阈值，Redis 都会进一步按照 volatile-ttl、volatile-random、volatile-lru、volatile-lfu 这四种策略的具体筛选规则进行淘汰

-   volatile-ttl 在筛选时，会针对设置了过期时间的键值对，根据过期时间的先后进行删除，越早过期的越先被删除。
-   volatile-random 就像它的名称一样，在设置了过期时间的键值对中，进行随机删除。
-   volatile-lru 会使用 LRU 算法筛选设置了过期时间的键值对。
-   volatile-lfu 会使用 LFU 算法选择设置了过期时间的键值对。

相对于 volatile-ttl、volatile-random、volatile-lru、volatile-lfu 这四种策略淘汰的是设置了过期时间的数据，allkeys-lru、allkeys-random、allkeys-lfu 这三种淘汰策略的备选淘汰数据范围，就扩大到了所有键值对，无论这些键值对是否设置了过期时间。它们筛选数据进行淘汰的规则是：

-   allkeys-random 策略，从所有键值对中随机选择并删除数据
-   allkeys-lru 策略，使用 LRU 算法在所有数据中进行筛选。
-   allkeys-lfu 策略，使用 LFU 算法在所有数据中进行筛选。

这也就是说，如果一个键值对被删除策略选中了，即使它的过期时间还没到，也需要被删除。当然，如果它的过期时间到了但未被策略选中，同样也会被删除。

### 9、 **Redis的LRU算法**

LRU 算法的全称是 Least Recently Used，从名字上就可以看出，这是按照最近最少使用的原则来筛选数据，最不常用的数据会被筛选出来，而最近频繁使用的数据会留在缓存中。

那具体是怎么筛选的呢？LRU 会把所有的数据组织成一个链表，链表的头和尾分别表示 MRU 端和 LRU 端，分别代表最近最常使用的数据和最近最不常用的数据。

我们现在有数据 6、3、9、20、5。如果数据 20 和 3 被先后访问，它们都会从现有的链表位置移到 MRU 端，而链表中在它们之前的数据则相应地往后移一位。因为，LRU 算法选择删除数据时，都是从 LRU 端开始，所以把刚刚被访问的数据移到 MRU 端，就可以让它们尽可能地留在缓存中。

如果有一个新数据 15 要被写入缓存，但此时已经没有缓存空间了，也就是链表没有空余位置了，那么，LRU 算法做两件事：

-   数据 15 是刚被访问的，所以它会被放到 MRU 端；
-   算法把 LRU 端的数据 5 从缓存中删除，相应的链表中就没有数据 5 的记录了。

其实，LRU 算法背后的想法非常朴素：它认为刚刚被访问的数据，肯定还会被再次访问，所以就把它放在 MRU 端；长久不访问的数据，肯定就不会再被访问了，所以就让它逐渐后移到 LRU 端，在缓存满时，就优先删除它。

不过，LRU 算法在实际实现时，需要用链表管理所有的缓存数据，这会带来额外的空间开销。而且，当有数据被访问时，需要在链表上把该数据移动到 MRU 端，如果有大量数据被访问，就会带来很多链表移动操作，会很耗时，进而会降低 Redis 缓存性能。

所以，在 Redis 中，LRU 算法被做了简化，以减轻数据淘汰对缓存性能的影响，Redis 默认会记录每个数据的最近一次访问的时间戳（由键值对数据结构 RedisObject 中的 lru 字段记录）。然后，Redis 在决定淘汰的数据时，第一次会随机选出 N 个数据，把它们作为一个候选集合。接下来，Redis 会比较这 N 个数据的 lru 字段，把 lru 字段值最小的数据从缓存中淘汰出去。

当需要再次淘汰数据时，Redis 需要挑选数据进入第一次淘汰时创建的候选集合。这儿的挑选标准是：能进入候选集合的数据的 lru 字段值必须小于候选集合中最小的 lru 值。当有新数据进入候选数据集后，如果候选数据集中的数据个数达到了 maxmemory-samples，Redis 就把候选数据集中 lru 字段值最小的数据淘汰出去。

这样一来，Redis 缓存不用为所有的数据维护一个大链表，也不用在每次数据访问时都移动链表项，提升了缓存的性能。

### 10、 Redis的淘汰策略的选择

**建议：**

优先使用 allkeys-lru 策略。这样，可以充分利用 LRU 这一经典缓存算法的优势，把最近最常访问的数据留在缓存中，提升应用的访问性能。如果你的业务数据中有明显的冷热数据区分，我建议你使用 allkeys-lru 策略。如果业务应用中的数据访问频率相差不大，没有明显的冷热数据区分，建议使用 allkeys-random 策略，随机选择淘汰的数据就行。

如果你的业务中有置顶的需求，比如置顶新闻、置顶视频，那么，可以使用 volatile-lru 策略，同时不给这些置顶数据设置过期时间。这样一来，这些需要置顶的数据一直不会被删除。

### 11、 什么是热Key问题，如何解决热key问题

热Key问题是指在Redis中，某个或某些特定的键被频繁访问，导致对这些键的操作成为系统的性能瓶颈。热Key问题可能会导致Redis负载过高，响应时间延长，甚至造成系统崩溃。

为了解决热Key问题，可以采取以下一些策略：

1.  增加缓存容量：扩大Redis内存容量可以提高缓存命中率，减少对热Key的访问次数，从而缓解热Key问题。可以考虑升级Redis服务器或增加Redis集群节点来增加内存容量。
2.  分片：将热Key均匀地分散到多个Redis实例中，每个实例处理一部分热Key的请求。这样可以降低单个Redis实例的负载压力，提系统整体的吞吐量。
3.  缓存预热：在系统启动或流量低峰期，提前加载热Key的数据到缓存中，使得这些热Key的数据在实际访问时已经存在于缓存中，减少对后端存储的访问。
4.  数据分片：对于热Key所对的数据量较大的情况，可以考虑将数据进行分片存储，将不同片段的数据存放在不同的键上，从而减轻单个键的访问压力。
5.  缓存降级：对于某些热Key，可以考虑将其缓存时间设置较短，或者不缓存，直接访问后端存储。这样可以避免热Key对缓存系统的过度压力，同时确保其他非热Key正常缓存。
6.  使用Redis集群：通过搭建Redis集群，将热Key分散到多个节点上，实现负载均衡和高可用性，提高系统的整体性能和稳定性。

综合考虑具体业务场景和系统需求，可以采取不同的策略或组合使用来解决热Key问题。

### 12、 什么是大Key问题，如何解决？

大Key问题是指在Redis数据库中存储了过大的数据结构，如大型列表、哈希、集合等，导致内存占用过高，影响Redis性能的情况。这可能会导致以下问题：

内存占用过高： 大Key占用了大量的内存空间，导致其他数据无法被缓存，从而影响Redis的性能和响应速度。

数据加载时间延长： 由于大Key的加载和传输需要较长时间，会导致读取和写入操作的延迟。

持久化问题： 在进行数据持久化（如RDB快照、AOF日志）时，大Key会增加持久化的时间和磁盘空间占用。

解决大Key问题的方法包括：

数据分片： 将大数据拆分成多个小数据，分别存储在不同的Key中。例如，将一个大型哈希表分成多个小型哈希表。

使用分布式存储： 将大数据存储在分布式数据库中，如Redis Cluster或其他分布式存储系统。

合理选择数据结构： 根据实际需求，选择合适的数据结构，避免在单个Key中存储过大的数据。

数据压缩： 对于可以压缩的数据，使用Redis提供的数据压缩功能，减小存储占用。

使用大Key分析工具： Redis提供了一些工具可以用于识别和处理大Key问题，例如Redis内存分析工具和命令。

定期清理： 周期性地检查数据库，发现并处理大Key，例如将大Key转移至其他存储系统。

合理设置过期时间： 对于不再需要的数据，设置适当的过期时间，让Redis可以自动淘汰这些数据。

综合使用这些方法可以有效地解决大Key问题，提高Redis的性能和稳定性。

### 13、 什么是缓存击穿、缓存穿透、缓存雪崩？

击穿、缓存穿透和缓存雪崩都是与缓存相关的常见问题现象。

**缓存击穿**：是指缓存中没有但数据库中有的数据（一般是缓存时间到期），这时由于并发用户特别多，同时读缓存没读到数据，又同时去数据库去取数据，引起数据库压力瞬间增大，造成过大压力。

**解决方案**：

-   设置热点数据永远不过期。
-   加互斥锁

**缓存穿透**：是指缓存和数据库中都没有的数据，导致所有的请求都落到数据库上，造成数据库短时间内承受大量请求而崩掉。

**解决方案：**

1）固定值攻击：缓存一个空对象key-null或者任意一个数据，比如缓存key-"x"

2）随机值攻击：

1、接口层增加校验，如用户鉴权校验，id做基础校验，id<=0的直接拦截；

2、全量缓存：将数据库的数据全部缓存到Redis。

3、缓存id:  将数据库全部数据的id(id要具有唯一性)全部缓存到Redis。

4、布隆过滤器：在项目一启动的时，将数据库中所有的数据全部缓存到布隆过滤器（本地或者分布式版本都可以，根据服务的实例数决定）中。布隆过滤器一个足够大的 bitmap ，一个一定不存在的数据会被这个 bitmap 拦截掉，从而避免了对底层存储系统的查询压力。

5、Redis自带的bitmap

**缓存雪崩**：是指缓存同一时间大面积的失效，所以，后面的请求都会落到数据库上，造成数据库短时间内承受大量请求而崩掉。

**解决方案：**

-   缓存数据的过期时间设置随机，防止同一时间大量数据过期现象发生。
-   给每一个缓存数据增加相应的缓存标记，记录缓存是否失效，如果缓存标记失效，则更新数据缓存。
-   搭建高可用Redis集群架构比如哨兵模式
-   业务服务层面使用降级、熔断、限流手段。（注意这是三套具体的解决方案落地）

### 14、 什么情况下会出现数据库和缓存不一致的问题？

数据库和缓存不一致的问题可能会出现在以下几种情况下：

1.  写操作未更新缓存：当应用程序对数据库进行写操作时，如果没有及时更新相关的缓存数据，就会导致数据库和缓存的数据不一致。这通常发生在缓存和数据库的更新操作没有保持同步的情况下。
2.  缓存过期和数据库更新：当缓存中的数据过期时，如果此时有大量的并发请求查询该数据，而后端数据库正在进行更新操作，就有可能导致缓存中的旧数据被读取，与数据库中的新数据不一致。
3.  多级缓存不一致：在多级缓存架构中，不同层级的缓存可能会出现数据不一致的情况。例如，一级缓存（本地缓存）和二级缓存（分布式缓存）之间的数据同步问题，如果没有及时更新或失效旧的缓存数据，就会导致数据库和缓存数据的不一致。
4.  数据库异常和缓存更新失败：当数据库发生异常或写操作失败时，如果缓存更新操作也失败了，就会导致数据库和缓存的数据不一致。例如，数据库写操作成功了，但是缓存更新失败，导致缓存中的数据是旧的或不一致的。

**最终一句话：不管哪种方式，在高并发（读读 读写）情况下都可能导致数据库数据和缓存数据不一致问题。**

### 15、 如何解决Redis和数据库的一致性问题？

**解决方案一：双写模式**

-   在写数据库的同时 去将数据写入Redis
-   在无并发的情况下，重试即可。
-   在并发的情况下可能会数据不一致
-   **慢的线程旧数据居然把新数据覆盖** 这是暂时性的脏数据问题，但是在数据稳定，缓存过期以后，又能得到最新的正确数据。

**双写模式下的：数据实时更新**

当更新数据库的时候，同步更新缓存，并且加锁。

优点：数据一致性强

缺点：有耦合性，并且写和读的操作成为了串行，牺牲了高并发读数据的能力。

适用环境：适用于数据一致性要求高的场景，比如银行业务，证券交易业务。

**双写模式下的：数据准实时更新**

当更新数据库的同时，异步去更新缓存，比如更新数据库后把一条消息发送到mq中去。

优点：修改数据库数据的业务和修改缓存的数据业务完成了解耦。

缺点：有较短的延迟，并且可能无法保证最终一致性，需要补偿机制。【保证消息百分百投递】

适用环境：对数据实时性要求不严格的场景，比如对一些商品热度值的统计。

**解决方案二：失效模式：**

-   先删缓存 在写数据库或者在写数据库的同时，去删除缓存，
-   在并发的情况下也可能出现不一致

会有两种情况：

情况一：先删除缓存，再更新数据库。

若异常情况：删除缓存成功了，更新数据库失败了。

-   无并发的情况下，重试修改数据库操作即可解决，保证最终的一致性。
-   有并发的情况下，给缓存数据设置过期时间，但是在缓存数据失效的这一段时间内，缓存数据仍然和数据库数据是不一致的。因此还可以在写完数据库之后主动在来删除缓存。（双删）。思想：【主动删除缓存+缓存key的被动失效】

情况二：先更新数据库值，再删除缓存值。

若异常情况：更新数据库成功了，删除缓存失败了。

-   无并发的情况下，重试修删除缓存操作即可解决，保证最终的一致性。
-   有并发（读）的情况下，可以不用管，因为等待缓存删除完成，下一次在来读的时候，发现缓存缺失，就会将数据最新的数据读到并同步到缓存中。在等待删除缓存期间也会有一段时间不一致
-   有并发（读、写）的情况下，仍然会出现缓存数据和数据库数据不一致问题，因此还需要通过缓存数据的失效机制+主动删缓存的机制来保证缓存数据和数据库数据的一致性。（在删除缓存和缓存数据失效期间仍然会出现不一致）
    -

**解决方案三：缓存失效机制**

基于缓存本身的失效机制，具体实现方式为设置缓存失效时间，如果有缓存就从缓存中取数据，如果没缓存就从数据库中取数据，并且重新设置缓存。

优点：实现方式简单，与业务完美解耦，不影响正常业务。

缺点：在缓存失效期间仍然会出现不一致，所以有数据一致性有延迟。

适用环境：能接受一定的数据延迟场景，比如对商品的热度值统计。

**解决方案四：延时双删（主要是针对失效模式）**

情况一：先删除缓存，再更新数据库。

在线程A更新完数据库值以后，我们可以让它先sleep一小段时间，再进行一次缓存删除操作。

之所以要加上sleep的这段时间，就是为了让线程B能够先从数据库读取数据，再把缺失的数据写入缓存，然后，线程A再进行删除。所以，线程A sleep的时间，就需要大于线程B读取数据再写入缓存的时间。这个时间怎么确定呢？建议你在业务程序运行的时候，统计下线程读数据和写缓存的操作时间，以此为基础来进行估算。 redis.delKey(X) db.update(X) Thread.sleep(N) redis.delKey(X)

情况二：先更新数据库值，再删除缓存值。

如果线程A删除了数据库中的值，但还没来得及删除缓存值，线程B就开始读取数据了，那么此时，线程B查询缓存时，发现缓存命中，就会直接从缓存中读取旧值。不过，在这种情况下，如果其他线程并发读缓存的请求不多，那么，就不会有很多请求读取到旧值。而且，线程A一般也会很快删除缓存值，这样一来，其他线程再次读取时，就会发生缓存缺失，进而从数据库中读取最新值。所以，这种情况对业务的影响较小 db.update(X)

redis.delKey(X)

Thread.sleep(N) redis.delKey(X)

**解决方案五：** 引入Canal中间件，类似于MySQL的主从数据同步。

大致的流程如下：

1）读Redis：热数据基本都在Redis

2）写MySQL:增删改都是操作MySQL

3）更新Redis数据：MySQ的数据操作binlog，来更新到Redis

第一次将数据全部写入到redis中做一个全量备份，接这mysql中的insert update delet

作为增量进行实时更新。当读取到binglog后分析，利用消息对列，推送到各个redis实例中去，对redis进行更新。

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\缓存\Redis\image\图片_l9V18CxJPo.png)

优点：类似于MySQL的主从模式，因为MySQL的主从也是通过订阅binlog日志来实现的数据一致性。

缺点： 引入中间件，代码开发难度较大，成本较高。

### 16、 Redis如何实现延迟消息？

Redis本身并不提供延迟消息的特性，但可以通过一些技术手段实现延迟消息的功能。以下是一种基于Redis的延迟消息实现方法：

1.  使用有序集合（Sorted Set）：将延迟消息的到期时间作为有序集合的分数(score)，消息内容作为有序集合的成员(member)。
2.  将延迟消息添加到有序集合中：将延迟消息按照到期时间添加到有序集合中。
3.  定时检查有序集合：通过定时任务或者后台线程，定期检查有序集合中的消息，找到到期的消息。
4.  处理到期的消息：当有序集合中的消息到期时，将其从有序集合中移除，并进行相应的处理，可以将消息发送到消息队列或者进行其他业务操作。

通过以上方法，可以实现延迟消息的功能。需要注意的是，在实现过程中需要考虑以下几点：

-   需要保证定时检查的频率，以确保消息能够及时被处理。
-   可以使用多个有序集合来支持不同延迟时间的消息，将消息按照不同的延迟时间分组存储。
-   可以使用Redis的发布/订阅功能将到期的消息发送到其他服务进行处理。
-   需要考虑消息的可靠性，如处理失败时的重试机制等。

需要根据具体的业务需求和系统架构选择合适的延迟消息方案，以上方法只是其中一种常见的实现方式之一。

### 17、 除了做缓存，Redis还能用来干什么？

除了做缓存，Redis还可以用来实现以下几个功能：

1.  数据存储：Redis支持多种数据结构，如字符串、哈希、列表、集合、有序集合等。可以将Redis作为主要的数据存储，用于存储和查询数据。例如，可以将用户会话信息、配置信息、计数器等数据存储在Redis中。
2.  消息队列：Redis的发布/订阅功能可以用作简单的消息队列系统。发布者将消息发布到指定的频道，订阅者可以监听频道并接收消息。这种方式可以用于实现异步任务、事件驱动等场景。
3.  分布式锁：利用Redis的原子性操作和过期时间特性，可以实现分布式锁。通过在Redis中存储一个特定键值对作为锁标识可以实现对共享资源的互斥访问，避免并发问题。
4.  计数器：Redis的自增和自减操作可以用于实现计数器功能。可以用于统计网站的访问量、点赞数量、订单数量等场景。
5.  地理位置应用：Redis理位置数据结构（Geo）可以存储和查询地理位置信息，如地理坐标、半径查询等。可以用于实现附近的人、地理位置搜索等功能。
6.  实时排行榜：利用Redis的有序集合数据结构，可以实现实时的排行榜功能。可以根据特定的规则将成员和分数存储在有序集合中，并根据分数进行排名。
7.  分布式缓存：Redis可以作为分布式缓存系统，通过集群和主从复制等机制，提供高可用性和高性能的缓存服务。

总之，Redis不仅仅是一个缓存系统还可以用于实现多种功能和应用场景，包括数据存储、消息队列、分布式锁、计数器、地理位置应用、实时排行榜等。

### 18、 如何用SETNX实现分布式锁？

使用Redis的SETNX命令可以实现简单的分布式锁。下面是使用SETNX实现分布式锁的基本步骤：

1. 获取：当一个进程或线程需要获取锁时，使用SETNX命令尝试设置一个指定的键（作为锁的标识）。

   ```bash
   SETNX lock_key 1
   ```

   如果返回值为1，表示成功获取锁；如果返回值为0，表示锁已被其他进程或线程持有，获取锁失败。

2. 释放锁：当持有锁的进程或线程需要释放锁时，使用DEL命令删除对应的键。

   ```bash
   DEL lock_key
   ```

通过以上步骤，可以实现简单的分布式锁。需要注意的是，分布式锁的实现需要考虑以下几点：

-   锁的粒度：需要明确锁的范围，即确定需要保护的共享资源。可以使用不同的锁标识来实现对不同资源的锁定。
-   锁的超时：为了避免死锁，可以为获取到的锁设置一个超时时间，避免锁被长时间持有。
-   锁的可重入性：如果同一个进程或线程多次获取同一个锁，需要确保锁的可重入性，即能够正常释放锁。
-   锁的可靠性：需要考虑锁的可靠性，如处理锁的异常情况、网络分区等。
-   锁的误删：B线程加入的锁，可能被A线程删除
-   锁的原子性：加锁设置过期时间和判断删除锁

需要根据具体的业务场景和系统需求，综合考虑以上因素来设计和实现分布式锁。

### 19、 什么是RedLock，他解决了什么问题？

RedLock是一个用于解决分布式系统中的锁竞争问题的算法。它是由Redis作者Antirez提出的一种算法，旨在解决Redis的分布式锁在网络分区等异常情况下可能出现的问题。

在分布式系统中使用Redis的SETNX命令来实现锁时，可能会遇到网络分区（例如主节点与从节点之间的网络断开）等故障情况，导致锁的可靠性受到影响。RedLock算法通过引入多个独立的Redis实例，使得锁在多个Redis实例上创建，增加了锁的可靠性。

RedLock算法的基本思想是，使用多个Redis实例（理论上最少需要3个以上）来创建锁。在获取锁时，需要在多个Redis实例上尝试获取锁，并使用大部分Redis实例都获取到锁才算成功。这样即使其中一个实例出现故障或网络分区，仍然可以保证锁的可用性。

RedLock算法的步骤如下：

1.  获取当前时间戳timestamp及随机字符串nonce。
2.  在多个Redis实例上依次尝试获取锁，使用SET命令设置锁标识，设置过期时间为锁的超时时间（一般为较短的时间，避免长时间锁定）。
3.  统计成功获取到锁的Redis实例数。
4.  如果成功获取到锁的Redis实例数大于等于大部分实例数（例如大于等于N/2+1，N为总实例数），则认为获取锁成功。
5.  如果获取锁失败，则需要在已获取锁的Redis实例上释放锁。

RedLock算法并不是用所有场景的通用解决方案，仍然存在一些局限性，例如对于时钟不同步的Redis实例、网络延迟等情况可能会导致锁的可靠性下降。因此，在使用RedLock算法时需要根据具体的业务需求和系统环境进行评估和测试。

### 20、 如何用Redisson实现分布式锁？

Redisson是一个基Redis的分布式对象和服务的框架，它提供了一种简单且可靠的方式来实现分布式锁。下面是使用Redisson实现分布式锁的基本步骤：

1.  引入Redisson依赖：在项目的构建文件中引入Redisson的依赖，例如Maven的pom.xml文件中添加以下依赖：

```xml
<dependency>
    <groupId>org.redisson</groupId>
    <artifactId>redisson</artifactId>
    <version>3.15.5</version>
</dependency>
```

1.  创建Redisson客户端：实例化Redisson客户端，并配置连接信息，例如Redis的地址和密码等。

```java
Config config = new Config();
config.useSingleServer().setAddress("redis://127.0.0.1:6379").setPassword("your_password");
RedissonClient redisson = Redisson.create(config);
```

1.  获取分布式锁：通过Redisson的getLock方法获取一个分布式锁对象。

```java
RLock lock = redisson.getLock("myLock");
```

1.  加锁和解锁：使用lock方法加锁，并在锁定的代码块执行完毕后使用unlock方法解锁。

```java
lock.locktry {
    // 执行需要加锁的代码块
} finally {
    lock.unlock();
}
```

通过以上步骤，就可以使用Redisson实现分布式锁。Redisson还提供了一些其他的功能，如可重入锁、公平锁、读写锁等，可以根据具体的需求选择合适的锁类型。此外，Redisson还支持异步执行和监听锁状态的功能，提供了更多灵活和便捷的方法来操作分布式锁。

需要注意的是，在Redisson实现分布式锁时，仍然需要考虑锁的超时时间、可重入性、互斥性和可靠性等因素，以确保分布式锁的正确和性能优化。





#                                         热门领域概念

## 云计算

### 1、什么是云计算？

云计算是一种基于互联网的计算模式，它通过将计算资源（例如服务器、存储、数据库、网络、软件等）提供给用户，使用户能够根据需要获得灵活的、可扩展的计算能力，而无需购买、配置和维护物理硬件设备。云计算的主要特点包括：

1.  **按需服务：** 用户可以根据实际需求随时获得所需的计算资源，无需事先购买或预留。
2.  **资源共享：** 多个用户可以共享同一组物理资源，通过虚拟化技术将资源划分为多个虚拟实例，从而提高资源利用率。
3.  **可扩展性：** 用户可以根据业务需求快速扩展或缩减计算资源，以适应不断变化的工作负载。
4.  **灵活性：** 用户可以选择不同类型的计算资源和服务，根据实际需求进行配置，从而满足不同的应用场景。
5.  **付费模式：** 通常采用按使用量付费的方式，用户只需支付实际使用的资源量，避免了高昂的起始投资和维护成本。
6.  **自动化管理：** 云计算平台通常提供自动化管理功能，例如自动扩展、备份、监控等，减少了用户的管理工作量。

云计算可以分为三种主要模式：基础设施即服务（IaaS）、平台即服务（PaaS）和软件即服务（SaaS）。

-   **IaaS：** 提供基本的计算、存储和网络基础设施，用户可以在此基础上构建和管理自己的应用程序和环境。
-   **PaaS：** 在IaaS的基础上，还提供了开发和部署应用程序所需的平台和工具，使开发者能够专注于应用逻辑而无需担心底层基础设施。
-   **SaaS：** 提供完整的应用程序作为服务，用户可以直接通过互联网访问和使用，无需安装和维护。

总之，云计算通过提供灵活、高效、经济的计算资源，为个人和企业提供了一种更便捷的方式来开发、部署和管理应用程序和服务。

### 2、什么是公有云、私有云、混合云？

公有云、私有云和混合云是云计算中常用的部署模式，它们在云资源的管理和访问权限上有所不同：

-   **公有云（Public Cloud）：** 公有云是由第三方提供商建立和管理的云基础设施，供多个用户共享。这些提供商会提供各种计算、存储、网络和应用服务，用户可以根据需要按需购买和使用。公有云通常具有高度的可扩展性和灵活性，适用于各种规模的企业和个人用户。
-   **私有云（Private Cloud）：** 私有云是一种基于云计算概念的部署模式，但它是为单个组织或企业独立建立和管理的。私有云通常在组织内部的数据中心中部署，提供更高的安全性和定制性，因为云资源仅供特定组织使用。这种模式适用于有特殊安全和合规需求的企业，或者需要更多控制权的情况。
-   **混合云（Hybrid Cloud）：** 混合云是将公有云和私有云结合起来的部署模式。在混合云中，组织可以将某些工作负载部署在公有云上，同时将敏感数据或合规性要求较高的工作负载部署在私有云中。这种模式可以充分利用公有云的弹性和灵活性，同时满足特定的安全和隐私需求。

综上所述，公有云、私有云和混合云是根据云资源的共享性质和管理控制程度来划分的不同云计算部署模式，组织可以根据自身需求选择适合的模式。

### 3、什么是IaaS、PaaS、SaaS？

IaaS、PaaS 和 SaaS 是云计算中常见的服务模型，用于描述不同层次的云服务提供方式：

-   **IaaS（基础设施即服务，Infrastructure as a Service）：** 在这种模型下，提供的是基础的计算资源，如虚拟机、存储、网络等。用户可以在这些基础设施上构建、管理和运行自己的应用程序，拥有更高的灵活性和控制权。但用户需要自己管理操作系统、中间件、应用等层面的内容。
-   **PaaS（平台即服务，Platform as a Service）：** PaaS 提供了比 IaaS 更高层次的抽象，除了基础设施，还提供了开发、部署和管理应用程序所需的平台和工具。用户可以将注意力集中在应用程序的开发和部署上，而不必过多关注底层的基础设施管理。PaaS 通常包括运行时环境、开发工具、数据库管理等。
-   **SaaS（软件即服务，Software as a Service）：** 在这种模型下，提供的是完整的应用程序作为服务。用户无需关心底层的基础设施、平台，只需通过网络浏览器或其他客户端访问应用程序。常见的 SaaS 包括电子邮件服务、在线办公套件、客户关系管理系统等。

这些服务模型从底层基础设施到应用程序层面提供了不同层次的抽象和服务，使用户能够根据需求选择合适的模型来构建、部署和使用应用程序。

### 4、什么是Serverless？

Serverless（无服务器）是一种计算模型，旨在让开发者能够更专注于编写代码和功能，而无需显式管理服务器和基础设施。虽然名称中带有“无服务器”，但实际上并不意味着没有服务器存在，而是指开发者无需关心服务器的管理细节。

在传统的应用部署中，开发人员需要管理服务器的配置、扩展性、负载平衡等方面。而在Serverless模型中，这些管理任务由云服务提供商来处理。开发者只需上传包含其代码的函数或服务，然后在需要时触发这些函数。云提供商会根据请求自动分配和释放资源，使开发者只需为实际使用的计算资源付费。

Serverless模型的特点包括：

1.  **按需付费：** 开发者只需为实际使用的计算资源付费，避免了不必要的资源浪费。
2.  **自动扩展：** 云服务提供商会根据请求的负载自动扩展资源，确保应用程序始终具有所需的性能。
3.  **事件驱动：** Serverless架构通常是基于事件驱动的，函数会在特定事件发生时被触发执行，如HTTP请求、数据库更改等。
4.  **无状态：** 每个函数执行都是独立的，不会保留状态，这使得函数更易于扩展和管理。

常见的Serverless服务包括 AWS Lambda、Azure Functions、Google Cloud Functions等。开发者可以使用这些服务来部署单个函数或更复杂的应用程序逻辑，而无需直接管理底层的服务器基础设施。









#                                         场景题

## 场景题

### 1、如果你的业务量突然提升100倍QPS你会怎么做？

面对业务量突然提升100倍的情况，我会采取以下一些措施来应对：

1.  **性能优化：** 首先，我会仔细分析系统瓶颈，寻找性能瓶颈并进行优化。这可能涉及到代码优化、数据库查询优化、缓存的使用等。确保系统能够高效地处理更多的请求。
2.  **扩容：** 如果性能优化无法满足需求，我会考虑增加系统的计算资源，比如扩展服务器集群，使用负载均衡器来分担流量。这可以提高系统的容量和并发处理能力。
3.  **缓存策略：** 我会审查系统中的缓存策略，确保数据可以合理地被缓存，从而减轻数据库的压力。使用适当的缓存方案可以提高响应速度。
4.  **异步处理：** 对于一些可以延迟处理的任务，我会考虑将其改为异步处理，这可以减少实时请求的压力，提高系统的稳定性。
5.  **限流和排队：** 为了防止系统过载，我会引入限流机制，控制每秒处理的请求数量。对于超出处理能力的请求，可以引入排队机制，以避免系统崩溃。
6.  **数据库优化：** 数据库通常是系统的瓶颈之一。我会考虑数据库分库分表、索引优化等措施，以提高数据库的承载能力和查询效率。
7.  **监控和警报：** 增加监控和警报系统，实时监测系统的性能指标，如CPU、内存、网络等。一旦达到预定阈值，系统可以自动触发警报，让维护团队可以及时采取措施。
8.  **紧急计划：** 虽然我们希望一切都能顺利处理，但是突发情况仍然可能发生。我会制定紧急计划，包括回滚方案、灾难恢复策略等，以应对意外情况。

总之，面对业务量大幅提升的情况，综合考虑系统的性能、资源、架构等各个方面，采取一系列综合措施，以确保系统能够稳定、高效地应对挑战。

### 2、让你设计一个订单号生成服务，该怎么做?

设计一个订单号生成服务需要考虑多个方面，包括唯一性、可扩展性、性能和易用性。以下是一个基本的设计方案：

**1. 唯一性保证：** 订单号必须保证唯一性，可以通过以下几种方式来实现：

-   **自增序列：** 使用数据库自增序列来生成订单号。每次插入一条订单记录时，自增序列会自动递增，生成唯一的订单号。
-   **UUID（通用唯一标识符）：** 使用UUID作为订单号，几乎可以保证全局唯一性。但是，UUID相对较长，可能影响存储和索引效率。

**2. 分布式生成：** 如果系统需要处理大量订单，可以考虑分布式生成订单号，以避免单点性能瓶颈。一种方法是引入分布式ID生成器，如Snowflake算法，保证在多个节点上生成唯一的ID。

**3. 编码信息：** 在订单号中可以包含一些有意义的信息，比如订单类型、时间戳等，以便快速识别订单属性。

**4. 缓存机制：** 为了提高性能，可以引入缓存机制。将最近生成的订单号缓存起来，避免频繁地访问数据库或分布式ID生成器。

**5. 生成算法：** 设计一个高效的生成算法，以避免长时间的等待或计算开销。算法应该在保证唯一性的前提下，尽量减小订单号的长度。

**6. 高可用性：** 考虑实现多个订单号生成服务的实例，以提供高可用性。可以使用负载均衡来分配请求，同时保证各实例之间的订单号唯一性。

**7. 错误处理：** 考虑异常情况，如数据库连接断开或分布式ID生成器不可用。设计适当的错误处理机制，确保系统的稳定性。

**8. 订单号格式：** 定义订单号的格式，使其易于阅读和管理。可以使用前缀、日期、随机数等方式。

**9. 日志记录：** 记录每个生成的订单号，包括生成时间、相关信息等，以便后续追踪和排查问题。

最终的设计取决于具体业务需求和技术栈。在设计过程中，需要综合考虑系统的性能、可靠性和易用性，确保订单号生成服务能够满足预期需求。

### 3、订单到期关闭如何实现

订单到期关闭是许多业务系统中常见的功能之一，通常涉及到以下步骤和考虑：

1.  **订单到期时间设定：** 首先，你需要在订单的数据模型中添加一个到期时间字段。这个字段可以是订单创建时间加上一个固定的时限，或者根据业务需求进行动态设置。
2.  **定期检查：** 设计一个定期的任务或者后台服务，以便在每个订单的到期时间到来时进行检查。这可以使用定时任务、消息队列等机制来实现。
3.  **关闭过期订单：** 当检查到订单的到期时间已经过了当前时间，系统应该将这些订单标记为已过期或者关闭状态。具体的操作可能包括更改订单状态、发送通知给相关人员，或者执行其他业务逻辑。
4.  **通知用户：** 对于用户，及时地通知订单的过期状态是很重要的。你可以通过电子邮件、短信、推送通知等方式通知用户，让他们知道订单已经关闭或者过期。
5.  **清理和归档：** 过期订单可能占用数据库空间或者内存资源。根据实际需求，你可以考虑定期清理或者归档这些已关闭或者过期的订单，以释放资源。
6.  **日志和监控：** 在订单到期关闭的过程中，记录相关的日志信息以便后续排查问题。同时，建立监控机制，及时发现和处理因订单到期引起的异常情况。
7.  **恢复和处理：** 有时候订单过期后，用户可能会要求恢复订单或者进行一些特殊处理。你需要设计相应的流程和界面来支持这些需求，以便管理员或客户支持人员可以进行干预。
8.  **测试和优化：** 在实际运行中，不断测试和优化订单到期关闭的流程。这可以帮助你发现潜在的问题并进行改进，确保系统在各种情况下都能正确地处理订单的到期关闭。

综上所述，订单到期关闭涉及到多个环节，需要在系统设计中充分考虑这些步骤，并根据业务需求和技术架构进行适当的实现。

### 4、如何设计一个购物车功能？

设计购物车功能涉及到使用户能够方便地添加、管理和结算所选商品，以及提供良好的用户体验。以下是一个基本的购物车功能设计概述：

1.  **添加商品：** 在商品页面上，为每个商品提供一个“添加到购物车”按钮。当用户点击该按钮时，将选定的商品添加到购物车。
2.  **购物车图标和总览：** 在页面的适当位置显示一个购物车图标，以及显示当前购物车中的商品数量和总金额的总览区域。这样用户可以随时查看购物车的状态。
3.  **购物车页面：** 提供一个单独的购物车页面，用户可以通过点击购物车图标或导航链接访问。在购物车页面上，列出已添加的商品、数量、单价和小计。还可以提供移除商品、更改数量以及清空购物车的选项。
4.  **商品数量和编辑：** 在购物车中，为每个商品提供一个数量字段，允许用户手动输入或使用增减按钮调整数量。还可以提供一个“编辑”选项，以便用户查看和修改商品的属性（如颜色、尺寸等）。
5.  **小计和总计：** 对于每个商品，显示小计金额（数量 × 单价）。在购物车底部显示所有商品的总金额，以及可能的运费和税费等附加费用，计算出订单的总金额。
6.  **结算流程：** 提供一个“去结算”或“结算”按钮，引导用户进入结算流程。在结算页面，用户可以选择收货地址、支付方式等，并进行最终确认。
7.  **登录和账户关联：** 如果你的网站或应用需要用户登录，可以将购物车与用户账户关联，使用户可以在不同设备间同步购物车内容。
8.  **保存购物车状态：** 在用户离开网站或关闭浏览器后，保留购物车中的商品，使用户下次访问时可以继续购物。
9.  **库存管理：** 在用户添加商品到购物车时，需要实时检查库存，以避免售罄情况。如果商品在用户结算前被其他用户购买，应及时更新购物车信息。
10.  **提供推荐：** 在购物车页面或结算页面，可以显示相关的商品推荐，鼓励用户继续浏览和购买其他商品。
11.  **移动端适配：** 确保购物车功能在移动设备上的用户体验良好，可以考虑采用折叠式购物车侧边栏等方式。
12.  **安全和隐私：** 确保用户的购物车信息安全，并遵循相关的隐私政策和法规。

最终的设计应该根据你的业务需求、用户画像和技术架构进行调整和定制。购物车功能不仅是一个交易过程，还能影响用户对你产品的整体印象，所以提供一个流畅、直观且安全的购物车体验至关重要。

### 5、每天100w次登录请求，4C8G机器如何做JVM调优？

对于每天100万次的登录请求，针对4核8GB的机器进行JVM调优可以有以下一些建议：

1.  **内存分配：** 确保为JVM分配足够的内存，但不要超过机器可用内存的合理范围。可以使用启动参数 `-Xms` 和 `-Xmx` 来设置初始堆内存和最大堆内存，例如 `-Xms4G -Xmx4G`。
2.  **垃圾回收策略：** 选择合适的垃圾回收策略以平衡吞吐量和延迟。对于高吞吐量的场景，可以考虑使用 G1 垃圾回收器。启用G1可以通过参数 `-XX:+UseG1GC`。
3.  **并发线程数：** 调整并发线程数以充分利用多核CPU。对于4核的机器，可以考虑设置参数 `-XX:ParallelGCThreads=4 -XX:ConcGCThreads=2`。
4.  **内存回收周期：** 根据应用的特点和负载，调整垃圾回收的时间间隔。可以使用参数 `-XX:G1NewSizePercent` 和 `-XX:G1MaxNewSizePercent` 来控制新生代的内存分配百分比。
5.  **堆区域划分：** G1垃圾回收器允许将堆内存划分为多个区域，可以通过参数 `-XX:G1HeapRegionSize` 来调整每个区域的大小，以优化垃圾回收的效率。
6.  **元空间设置：** 对于大量的类加载和反射操作，需要适当调整元空间的大小。可以使用参数 `-XX:MetaspaceSize` 和 `-XX:MaxMetaspaceSize`。
7.  **JVM日志和监控：** 开启JVM的日志和监控可以帮助你实时了解JVM的运行状态和性能指标，以便及时调整参数。可以使用参数 `-XX:+PrintGC -XX:+PrintGCTimeStamps -XX:+PrintGCDateStamps` 来输出垃圾回收日志。
8.  **硬件资源利用：** 考虑将登录请求分散到多个实例上，以充分利用硬件资源，降低单个实例的负载。

以上建议仅供参考，实际的调优策略需要根据你的应用特点、负载情况和机器配置进行调整。建议在调优过程中逐步引入变更，并使用监控工具来评估性能的变化。

### 6、不用redis分布式锁， 如何防止用户重复点击？

不使用 Redis 分布式锁时，你仍然可以采取其他方法来防止用户重复点击。以下是一些可能的替代方案：

1.  **前端防御：** 在前端实现一些防御措施，例如在用户点击后禁用相应的按钮或链接，直到后台处理完成。这可以通过 JavaScript 来实现。虽然前端控制不是绝对可靠的方法（用户可能通过浏览器开发工具绕过），但可以防止大部分普通用户的重复点击。
2.  **请求队列：** 在后端服务中实现一个请求队列，当用户发起请求时，将请求放入队列中进行处理，并且确保同一个用户的相同请求在队列中只有一个。这可以通过用户标识（如用户ID）来实现。在请求处理完成之前，拒绝队列中同一用户的相同请求。
3.  **记录请求时间：** 对于每个用户，记录其最近一次请求的时间戳。当用户发起请求时，先检查距离上一次请求的时间间隔是否足够，如果不够则拒绝处理。这可以防止用户在短时间内连续点击。
4.  **限制请求频率：** 设置一个全局的请求频率限制，确保同一个用户在一段时间内只能发起有限次数的请求。这可以通过限制 IP 地址、用户标识等来实现。
5.  **使用数据库锁：** 尽管不如 Redis 分布式锁高效，但你可以在数据库中使用行级锁或者悲观锁来防止并发修改，从而防止用户重复点击。

需要注意的是，这些方法并不能完全消除用户重复点击的可能性，因为客户端和网络环境复杂多变，总会存在一些特殊情况。综合使用多种方法可以提高防御效果。最终的选择应该基于你的应用需求、可用技术以及风险承受能力来确定。

### 7、让你设计一个秒杀系统，你会考虑哪些问题？

当设计一个秒杀系统时，需要考虑以下一些关键问题：

1.  **高并发处理：** 秒杀活动通常会引起巨大的并发请求，系统需要能够处理大量用户同时发起的请求，确保系统稳定运行，不会因为负载过重而崩溃。
2.  **数据一致性：** 在秒杀过程中，多个用户可能会竞争有限的资源，如商品库存。需要确保并发操作不会导致数据不一致或超卖现象。
3.  **库存管理：** 如何高效地管理商品库存，避免超卖和卖完的情况，同时能够迅速更新库存状态，是一个关键问题。
4.  **限流和防刷：** 需要采取措施限制用户频繁的请求，以防止恶意刷单和重复点击。
5.  **队列和异步处理：** 使用队列技术可以将请求缓冲起来，然后异步处理，以减轻数据库和服务器压力，提高系统性能。
6.  **缓存策略：** 合理使用缓存可以减轻数据库压力，提高数据访问速度，但需要注意缓存的更新策略，以确保数据的实时性和准确性。
7.  **分布式架构：** 考虑采用分布式架构，将不同功能模块分散在不同的服务器上，以提高系统的扩展性和可用性。
8.  **安全性和防护：** 防止恶意攻击、SQL 注入、XSS 等安全问题，保障用户数据安全和系统稳定。
9.  **用户体验：** 设计友好的用户界面和流程，确保用户能够顺利参与秒杀活动，同时避免因为系统问题造成用户体验不佳。
10.  **监控和调优：** 设置合适的监控系统，实时监测系统运行状态、性能指标和异常情况，及时进行调优和处理故障。
11.  **容灾和备份：** 考虑系统的容灾和备份方案，确保系统在故障时能够快速恢复，并保障数据不会丢失。
12.  **业务流程设计：** 定义清晰的秒杀流程，包括商品展示、下单、支付、发货等环节，确保整个流程顺畅运行。

这些只是设计秒杀系统时需要考虑的一些关键问题，具体方案需要根据业务需求和技术栈来定制。

### 8、如果让你实现消息队列，会考虑哪些问题？

如果要设计和实现一个消息队列，需要考虑以下问题：

1.  **消息传递方式：** 确定消息是通过什么方式进行传递，常见的方式包括点对点传递和发布-订阅模式。
2.  **消息持久化：** 考虑消息是否需要被持久化，以防止消息在系统故障时丢失。可以选择将消息存储在数据库、文件系统或者其他持久化存储中。
3.  **消息顺序性：** 某些场景下，消息的顺序性非常重要。设计时需要确保相同的消息顺序被保留，并且不同消息之间的顺序不会混淆。
4.  **消息传递的可靠性：** 系统应该能够保证消息的可靠传递，即使在网络不稳定或者其他异常情况下也能够确保消息的送达。
5.  **消息重试机制：** 考虑在消息处理失败时的重试机制，以确保消息最终被成功处理，避免因为一次失败就丢失了重要信息。
6.  **消息格式与序列化：** 确定消息的格式以及如何进行序列化和反序列化，以便消息能够在不同组件之间进行传递和解析。
7.  **消息过滤与路由：** 考虑如何根据消息的内容对消息进行过滤和路由，确保消息被正确地发送到目标处理程序。
8.  **性能和吞吐量：** 根据预期的负载和性能需求，选择合适的消息队列实现，并进行性能测试和优化。
9.  **扩展性：** 系统应该能够方便地进行横向扩展，以适应日益增长的消息量。
10.  **监控和管理：** 设计合适的监控系统，实时监测消息队列的状态和性能指标，同时提供管理工具来管理消息的发送、消费和处理。
11.  **安全性：** 考虑消息队列的安全性，防止未经授权的访问和消息篡改。
12.  **集成和支持：** 考虑消息队列与其他系统的集成，提供适当的API和文档，以便开发人员能够方便地使用消息队列。

这些是设计和实现消息队列时需要考虑的一些关键问题，具体方案会根据实际需求和技术选择进行定制。

### 9、库存扣减如何避免超卖和少卖？

针对库存扣减避免超卖和少卖的问题，你可以结合消息队列的设计和实现来解决。以下是一个基本的思路：

1.  **库存管理系统：** 首先，你需要一个库存管理系统来跟踪每个商品的库存数量。这个系统应该能够及时更新库存数量，记录每次的库存变动。
2.  **消息队列应用：** 对于库存扣减操作，你可以将其转化为消息队列的任务。每次有订单需要扣减库存时，将一个消息发送到消息队列。
3.  **消费者服务：** 在消息队列中，你可以有一个或多个消费者服务，负责实际的库存扣减操作。这样做的好处是，你可以控制同时进行库存扣减的并发量，从而避免超卖和少卖的问题。
4.  **事务处理：** 在库存扣减操作中，确保消息队列中的每个消息都被消费者服务原子性地处理。这可以使用消息队列的事务特性或者结合数据库事务来实现。如果扣减库存和订单的状态更新在不同系统中进行，确保这两个操作要么同时成功，要么同时失败，以保持数据的一致性。
5.  **库存预检查：** 在处理消息之前，消费者服务可以进行库存预检查，检查库存是否足够以执行扣减操作。如果库存不足，可以将消息退回到队列或者将其标记为失败。
6.  **库存补偿机制：** 如果发生了少卖的情况，你可以设计一个库存补偿机制。例如，定期检查库存和实际销售情况，如果有差异，则自动增加库存以补偿。
7.  **监控和报警：** 针对库存扣减过程，设计监控系统来实时监测消息队列状态和性能，同时监控库存的变化。设置报警机制，如果出现异常情况（比如消息积压、库存异常等），及时通知相关人员进行处理。
8.  **安全性和集成：** 确保消息队列的安全性，只允许授权的操作访问消息队列。同时，提供集成接口和文档，让开发人员能够方便地使用消息队列进行库存扣减。

总之，通过合理的消息队列设计、事务处理、预检查和监控机制，你可以有效地避免库存的超卖和少卖问题，保证系统的稳定和一致性。具体的实现会根据你所选择的消息队列系统和技术栈有所不同。

### 10、如何用Redis实现朋友圈点赞功能？

当使用Redis来实现朋友圈点赞功能时，可以按照以下步骤进行设计和实现：

1.  **存储点赞关系：** 使用Redis的数据结构，例如Set，来存储点赞关系。对于每篇朋友圈动态，可以使用一个Set来存储点赞的用户ID。每个用户ID只能在Set中出现一次，确保每个用户只能点赞一次。
2.  **点赞计数：** 可以使用Redis的Sorted Set来存储点赞计数信息。每篇朋友圈动态都对应一个Sorted Set，其中成员是用户ID，分数是点赞的时间戳。这样可以实现点赞时间的排序，并且可以通过Sorted Set的长度来获取点赞的总数。
3.  **取消点赞：** 如果用户取消点赞，只需从点赞关系的Set中移除相应的用户ID，同时从Sorted Set中删除对应的成员。
4.  **查看点赞状态：** 通过判断用户ID是否在点赞关系的Set中，可以确定用户是否已经点赞。
5.  **获取点赞列表：** 如果需要展示最近点赞的用户列表，可以通过获取Sorted Set中的成员（用户ID）和分数（时间戳），然后根据时间戳排序，得到最近点赞的用户列表。

以下是一个简化的示例代码

```纯文本
public class RedisLikeDemo {

      private static final String LIKE_PREFIX = "like:";
      private static final String USER_PREFIX = "user:";

       //点赞
      public static void likePost(String postId, String userId, Jedis jedis) {
          
           String key = LIKE_PREFIX + postId;
           Long now = System.currentTimeMillis();
           jedis.zadd(key, now.doubleValue(), userId);// 将用户ID及当前时间戳加入有序集合
            
      }
        //取消点赞
       public static void unlikePost(String postId, String userId, Jedis jedis) {
          String key = LIKE_PREFIX + postId;
          jedis.zrem(key, userId);// 将用户ID从有序集合中移除
       }
       //查看点赞列表
       public List<String> getLikes(String postId, Jedis jedis) {
         
          String key = LIKE_PREFIX + postId;
          ZParams zParams = new ZParams().asc();
          return jedis.zrangeByScoreWithScores(key, "+inf", "-inf", 0, -1, zParams)
          .stream()
           .map(tuple -> {
             String userId = tuple.getElement();
             return userId;
          }).collect(Collectors.toList());
        }
       }

}
```

请注意，这只是一个基本的示例，实际应用中可能需要考虑更多的异常情况和优化。同时，为了保证数据的一致性和安全性，可能需要进一步的设计和措施。

### 11、Redis的zset实现排行榜，实现分数相同按照时间顺序排序，怎么做？

要在Redis的ZSET（有序集合）中实现分数相同情况下按时间顺序排序，可以借助一些技巧和额外的字段来实现。以下是一种可能的实现方法：

假设你要存储帖子的排行榜，分数表示点赞数，时间戳表示点赞时间。

1. 添加帖子点赞时，使用ZADD命令将帖子的ID作为成员，点赞时间戳作为分数添加到ZSET中。

   `ZADD post_likes:<post_id> <timestamp> <user_id>`

2. 当多个用户点赞同一帖子时，由于分数是点赞时间戳，相同分数的成员会按照字典序排序。

3. 查询排行榜时，使用ZREVRANGE命令按分数（时间戳）倒序获取排行榜列表。

   `ZREVRANGE post_likes:<post_id> 0 -1`

   这将返回按时间倒序的点赞列表，如果多个用户的点赞时间戳相同，它们会按照插入顺序排列，符合你的要求。

需要注意的是，由于Redis的ZSET是基于分数排序的，所以我们将时间戳作为分数存储，这样就能够实现相同分数情况下的时间顺序排序。在实际应用中，你可能还需要考虑数据清理、数据同步等问题，以确保系统的稳定性和一致性。

### 12、如何实现"查找附近的人"功能？

实现"查找附近的人"功能通常涉及到地理位置数据和距离计算。在这里，我将为你提供一个基本的思路和步骤，使用Redis的地理位置数据结构（Geospatial Indexes）来实现这个功能。

在Redis中，地理位置数据可以使用有序集合（Sorted Set）的功能来存储和查询。每个成员都有一个经度（longitude）和纬度（latitude）的坐标，可以通过这些坐标来计算距离并进行查询。

以下是一个基本的实现步骤：

1. **存储用户地理位置信息：** 对于每个用户，使用`GEOADD`命令将其地理位置信息存储在一个有序集合中，键可以是类似于 "user\_locations" 的标识。

   `GEOADD user_locations <longitude> <latitude> <user_id>`

2. **查询附近的人：** 使用`GEORADIUS`命令来查询附近的人。你可以指定一个中心点的坐标（比如当前用户的位置），然后指定一个距离范围，命令会返回在这个范围内的用户列表。

   `GEORADIUS user_locations <center_longitude> <center_latitude> <radius> m WITHDIST`

   这将返回一组用户及其与中心点的距离。

3. **筛选结果：** 你可以根据需要对查询结果进行进一步的筛选和处理，比如根据距离排序、限制结果数量等。

请注意，这只是一个简单的实现示例，实际情况可能会更加复杂。在实际应用中，你还需要考虑数据的更新、清理、错误处理以及性能优化等问题。

另外，随着技术的不断发展，可能会有其他更高级的方法和工具来实现类似的功能，例如使用地理信息数据库或专门的地理位置服务。

### 13、消息队列使用拉模式好还是推模式好？为什么？

消息队列可以采用拉模式（Pull）或推模式（Push）来处理消息传递。选择哪种模式取决于你的应用场景和需求。

**拉模式（Pull）：** 在拉模式中，消费者主动从消息队列中拉取消息。消费者决定何时获取消息以及获取多少消息。这种模式的优势在于消费者可以控制消息的处理速率，以适应自己的处理能力。拉模式适用于以下情况：

1.  **消费者处理能力不稳定：** 如果消费者的处理速度波动较大，拉模式可以避免消息积压问题。
2.  **消费者需要灵活控制：** 如果消费者希望在特定时间获取消息，或者根据自身逻辑选择性地获取特定消息，拉模式更适合。

**推模式（Push）：** 在推模式中，消息队列将消息主动推送给消费者。消费者只需提供一个回调函数或处理方法，消息队列会在有消息到达时调用该回调函数。推模式的优势在于即时性，适用于以下情况：

1.  **低延迟要求：** 如果你需要实现低延迟的消息传递，推模式可以更快地将消息发送给消费者。
2.  **实时通知：** 如果你需要及时通知消费者进行某些操作，推模式可以满足这种即时性的需求。

选择拉模式还是推模式取决于你的应用需求和场景：

-   **拉模式适用于：**
    -   需要灵活控制消息获取的场景。
    -   消费者处理能力波动较大的情况。
    -   对消息处理的顺序有严格要求。
-   **推模式适用于：**
    -   需要低延迟和实时性的场景。
    -   需要及时通知和即时反馈的情况。
    -   消费者处理能力稳定，不容易被消息积压。

需要注意的是，有些消息队列系统甚至允许在同一个应用中同时使用拉模式和推模式，以满足不同消息处理需求。在实际应用中，根据业务需求来选择适合的模式是非常重要的。

### 14、如果让你实现一个Dubbo，会考虑用哪些技术解决哪些问题？

要实现类似于Dubbo这样的分布式服务框架，需要考虑多个方面的技术和问题。以下是一些可能的考虑和解决方案：

1.  **服务注册与发现：** 使用类似Zookeeper、Etcd或Consul等分布式系统作为服务注册中心，用于服务提供者注册自己的服务，并供消费者发现可用的服务。
2.  **远程通信协议：** 选择合适的远程通信协议，如RPC（Remote Procedure Call）协议，可以使用基于TCP的协议，如Netty，或者HTTP/2等。
3.  **序列化与反序列化：** 选用高效的序列化方式，如Google Protocol Buffers、Apache Avro或者MessagePack，以减少网络传输时的数据体积。
4.  **负载均衡：** 实现负载均衡策略，确保服务消费者能够均匀地调用不同的服务提供者，可考虑使用轮询、随机、权重等策略。
5.  **容错与熔断：** 实现容错机制，处理服务提供者不可用或者网络故障等情况，可以引入熔断器，如Hystrix，以避免级联故障。
6.  **并发与线程池：** 考虑到服务提供者可能会被大量请求同时调用，需要使用线程池等技术来管理并发请求，避免资源耗尽。
7.  **超时与重试：** 实现超时机制，避免长时间等待，同时可以引入重试机制，确保在某些网络瞬时问题导致的失败情况下，能够进行自动重试。
8.  **跨语言支持：** 如果需要支持不同编程语言间的服务调用，可以使用通用的IDL（接口定义语言）来定义接口，再根据不同语言生成对应的客户端和服务端代码。
9.  **监控与治理：** 引入监控和管理工具，如Dubbo-admin、Prometheus等，用于实时监控服务的调用情况、性能指标等，并能进行故障排查和性能优化。
10.  **安全与认证：** 考虑数据传输的安全性，可以使用SSL/TLS加密通信，另外还可以引入认证和授权机制，确保只有合法的服务消费者能够调用服务。
11.  **分布式事务：** 如果需要支持分布式事务，可以考虑使用分布式事务管理器，如Seata或TCC（Try-Confirm-Cancel）等机制。
12.  **扩展性：** 构建可扩展的架构，允许根据业务需求动态添加新的服务提供者，同时保持系统的稳定性。

最终的选择会依赖于具体的业务需求、技术栈以及团队的经验和技术偏好。以上列举的技术和问题只是其中的一部分，实际实现时还需要根据具体情况进行详细的设计和调优。

### 15、Kafka，单分区单消费者实例，如何提高吞吐量

针对 Kafka 单分区单消费者实例如何提高吞吐量的问题，以下是一些可能的优化策略：

1.  **增加分区数：** Kafka 的吞吐量与分区数相关，增加分区数可以充分利用多个消费者并行处理消息。但需要注意，分区数的调整可能需要对生产者和消费者的代码进行适当的修改。
2.  **调整消费者数：** 尽可能多地创建消费者实例，每个实例处理一个分区。这样可以最大化地利用 CPU 和网络资源，提高并行处理能力。
3.  **调整消费者的并行处理能力：** 在消费者代码中，确保消息的处理逻辑能够高效运行。可以考虑使用多线程或异步处理，以提高并行处理的能力。
4.  **提高消费者端的配置：** 调整消费者的配置参数，例如 `fetch.min.bytes`、`fetch.max.wait.ms` 等，以优化拉取消息的性能。
5.  **使用批量处理：** 将多条消息批量处理，而不是逐条处理，可以减少网络开销和处理开销，从而提高吞吐量。
6.  **调整服务器端的配置：** 调整 Kafka 服务器端的配置参数，例如 `num.io.threads`、`num.network.threads` 等，以适应高吞吐量的需求。
7.  **考虑使用压缩：** 如果网络带宽有限，可以考虑在生产者端启用消息压缩，以减少传输的数据量。
8.  **使用更快的硬件和网络：** 升级硬件和网络设备，以提供更大的计算和通信能力。
9.  **监测性能和瓶颈：** 使用监控工具监测 Kafka 集群、消费者和生产者的性能指标，找出可能的瓶颈，并针对性地进行优化。
10.  **版本更新：** 确保使用了较新的 Kafka 版本，因为每个版本都可能对性能进行了改进和优化。

需要注意的是，上述优化策略的效果取决于具体的使用情境和环境，因此建议在应用这些策略之前，先进行充分的测试和评估，以确保其对吞吐量的提升效果符合预期。同时，持续的性能监测和调优也是保持高吞吐量的关键。

### 16、一个订单，在11:00超时关闭，但在11:00也支付成功了，怎么办？

在这种情况下，处理订单超时和支付成功的冲突可能需要以下步骤：

1.  **确认订单状态：** 首先，需要确保订单状态的准确性。检查订单数据库或系统，确认订单在11:00是否确实被标记为超时关闭，同时也确认支付是否在11:00之前成功完成。
2.  **审查日志：** 查看相关系统的日志记录，尤其是订单处理和支付流程的日志。这可以帮助你了解事件发生的确切时间以及可能的问题。
3.  **恢复订单状态：** 如果支付在11:00之前成功完成，并且订单被错误地标记为超时关闭，你可能需要通过后台操作或管理员权限来恢复订单状态。将订单状态重新设置为已支付或待处理，以便继续订单的后续流程。
4.  **通知用户：** 如果出现了这种情况，及时通知相关用户。向用户解释发生的问题，向其确认订单的实际状态，并道歉为带来的不便。
5.  **系统改进：** 这种问题可能暴露出订单处理系统或支付系统的一些潜在问题。你需要分析为什么会出现这种错误，以避免类似问题再次发生。可能需要对系统流程、数据库事务处理和事件触发机制进行审查和改进。
6.  **测试与验证：** 在进行任何更改之前，务必进行全面的测试。模拟类似的情况，确保订单状态和支付能够正确处理，以避免再次出现类似的问题。

总之，处理订单超时和支付成功冲突需要综合考虑数据的准确性、用户体验和系统流程。及时纠正错误，通知用户，并采取措施防止未来类似问题的发生是关键步骤。

### 17、一个支付单，多个渠道同时支付成功了怎么办？

如果出现一个支付单被多个渠道同时支付成功的情况，需要采取以下步骤来解决这个问题：

1.  **确认支付状态：** 首先，确保支付状态的准确性。检查系统记录，确认是否真的存在多个渠道同时支付成功的情况，或者是系统记录出现了错误。
2.  **数据处理：** 如果确认多个渠道确实同时支付成功，需要对支付数据进行处理。通常情况下，系统会自动处理相同订单的多次支付，将多余的支付金额退还给用户。确保这个过程是自动化的，以减少用户的不便。
3.  **用户通知：** 如果需要进行退款或其他处理，务必及时通知用户。解释情况，并说明后续的操作步骤，例如退款的时间和方式。
4.  **系统改进：** 类似于上面提到的订单超时问题，这种情况可能也暴露出支付系统的潜在问题。分析为什么会出现这种冲突，检查支付系统的流程和事件处理机制，确保类似问题不会再次发生。
5.  **测试与验证：** 在进行任何系统改进之前，进行全面的测试和验证。模拟多个渠道同时支付的情况，确保系统能够正确处理，并防止类似问题的再次发生。
6.  **监测与预防：** 建立监测机制，定期检查支付系统的表现，以及是否出现类似的问题。预防措施可能包括对并发支付的处理机制进行优化，确保数据的一致性和准确性。

总之，解决一个支付单多渠道同时支付成功的问题需要综合考虑数据处理、用户通知、系统改进以及未来预防措施。确保用户的权益不受损害，同时优化系统以避免类似问题的再次发生。

### 18、如何解决消息重复消费、重复下单等问题？

要解决消息重复消费、重复下单等问题，通常可以采取以下一些方法：

1.  **消息去重：** 在消息队列中，你可以实现消息的唯一标识。当消费者从队列中获取消息时，首先检查该消息的唯一标识是否已经被处理过。如果已经处理过，就可以跳过该消息，避免重复消费。
2.  **幂等性设计：** 在系统中引入幂等性概念，即使同一个操作被多次执行，结果也保持一致。对于下单操作，可以设计成幂等操作，确保多次重复请求只会产生一次订单。可以通过为每个订单生成一个唯一的订单号，使用订单号来识别订单的唯一性。
3.  **事务控制：** 在涉及到多个操作的情况下，使用事务来确保操作的原子性。例如，在创建订单的同时扣减库存，可以将这两个操作放在同一个事务中，如果其中一个操作失败，整个事务会回滚，保证数据的一致性。
4.  **幂等性校验：** 在处理请求之前，可以先查询系统的状态，判断该请求是否已经被处理过。如果已经处理过，可以直接返回之前的结果，避免重复操作。
5.  **定时任务清理：** 可以设置定时任务来清理过期的数据，如未支付的订单或已经处理过的消息。这样可以确保系统中不会长期存在无效数据。
6.  **消息确认机制：** 在消息队列中，可以使用消息确认机制来确保消息被成功消费。只有在消费者确认后，消息才会被标记为已消费，避免消息在处理失败时被重复消费。
7.  **日志记录与审计：** 记录每个操作的日志，并建立审计机制。这样可以追踪操作的历史，及时发现异常情况并进行处理。

综合使用上述方法，可以有效地解决消息重复消费、重复下单等问题，保证系统的稳定性和数据的一致性。

### 19、你是如何进行SQL调优的？

进行SQL调优时，通常可以采取以下步骤来优化查询性能和提高数据库操作效率：

1.  **分析查询执行计划：** 使用数据库管理工具或命令，获取SQL查询的执行计划。执行计划将显示查询的执行路径，包括表的连接方式、索引的使用情况等。通过分析执行计划，可以确定查询中存在的性能瓶颈。
2.  **索引优化：** 确保表中的字段上存在适当的索引，以加快数据检索速度。然而，不宜过度索引，因为索引也会增加数据写入的开销。使用复合索引来覆盖多个查询条件，避免使用过多的单列索引。
3.  **合理编写SQL语句：** 编写高效的SQL查询语句是调优的关键。避免使用"SELECT \*”，而是只选择需要的列；合理使用JOIN操作，避免多余的连接；使用子查询时，确保子查询返回的数据量有限。
4.  **缓存数据：** 对于频繁查询的数据，可以使用缓存技术，如Redis，将结果缓存起来，减少对数据库的频繁访问。
5.  **分区表和分表：** 如果数据表过大，可以考虑使用分区表或分表的方式，将数据分散存储，提高查询效率。
6.  **定期维护和统计：** 定期进行数据库的维护工作，如重新生成索引、更新统计信息等，以保持数据库的优化状态。
7.  **避免全表扫描：** 尽量避免全表扫描操作，可以通过适当的索引、条件过滤等方式来减少数据量，提高查询速度。
8.  **优化数据库参数配置：** 根据数据库类型，调整数据库的参数配置，如缓冲池大小、连接数等，以适应实际业务负载。
9.  **使用合适的存储引擎：** 根据具体的应用需求，选择合适的数据库存储引擎，如InnoDB、MyISAM等。
10.  **使用慢查询分析工具：** 数据库管理工具提供了慢查询分析功能，可以帮助你识别哪些查询语句执行较慢，从而有针对性地进行优化。

综合考虑上述方法，根据具体的业务需求和数据库特点，可以进行有效的SQL调优，提升数据库性能和查询效率。

### 20、不使用synchronized和Lock如何设计一个线程安全的单例？

不使用 `synchronized` 和 `Lock` 来设计一个线程安全的单例可以考虑使用一些其他方式，例如基于静态内部类的单例模式，或者使用双重检查锁定（Double-Checked Locking）等技术来实现。以下是两种常见的线程安全单例实现方法：

**1. 静态内部类单例模式：**

这种方法利用了类加载的特性，保证了只有在第一次使用单例的时候才会加载内部类，从而实现懒加载，同时又保证线程安全。

```纯文本
public class Singleton {
    private Singleton() { /* 私有构造方法 */ }

    private static class SingletonHolder {
        private static final Singleton INSTANCE = new Singleton();
    }

    public static Singleton getInstance() {
        return SingletonHolder.INSTANCE;
    }
}
```

**2. CAS：**

CAS是项乐观锁技术，当多个线程尝试使用CAS同时更新同一个变量时，只有其中一个线程能更新变量的值，而其它线程都失败，失败的线程并不会被挂起，而是被告知这次竞争中失败，并可以再次尝试。实现单例的方式如下：

```纯文本
public class Singleton {
     private static final AtomicReference<Singleton> INSTANCE = new AtomicReference<Singleton>();
 
     private Singleton() {}
 
     public static Singleton getInstance() {
         for (;;) {
             Singleton singleton = INSTANCE.get();
             if (null != singleton) {
                 return singleton;
             }
 
             singleton = new Singleton();
             if (INSTANCE.compareAndSet(null, singleton)) {
                 return singleton;
             }
         }
     }
}
    

```

用CAS的好处在于不需要使用传统的锁机制来保证线程安全,CAS是一种基于忙等待的算法,依赖底层硬件的实现,相对于锁它没有线程切换和阻塞的额外消耗,可以支持较大的并行度。

CAS的一个重要缺点在于如果忙等待一直执行不成功(一直在死循环中),会对CPU造成较大的执行开销。

另外，如果N个线程同时执行到singleton = new Singleton();的时候，会有大量对象创建，很可能导致内存溢出。

### 21、索引失效的问题是如何排查的，有那些种情况？

索引失效是数据库性能调优中常见的问题之一，通常会导致查询变慢甚至超时。排查索引失效问题需要仔细分析查询语句、表结构、索引设计以及数据库统计信息等因素。以下是一些可能导致索引失效的情况以及排查方法：

1.  **查询条件与索引不匹配：** 如果查询条件中使用的列与索引的列不匹配，数据库可能无法使用索引来加速查询。检查查询条件是否涵盖了索引的前缀，或者是否需要重新设计索引以更好地匹配查询。
2.  **索引选择性低：** 索引的选择性是指索引中不同值的数量与总行数的比率。如果索引选择性很低，意味着索引中的值重复较多，数据库可能会选择全表扫描而不是使用索引。可以通过查看统计信息，比如索引的基数（distinct值的数量）来评估索引的选择性。
3.  **数据分布不均匀：** 如果索引列的数据分布不均匀，一些值的数量过多，而另一些值很少，那么在查询时可能会导致部分索引失效。考虑重新设计索引或者优化查询条件以解决这个问题。
4.  **数据类型不匹配：** 查询条件中使用的数据类型与索引列的数据类型不匹配时，索引可能无法被使用。确保查询条件的数据类型与索引列的数据类型相同。
5.  **隐式类型转换：** 如果在查询条件中进行了隐式类型转换，可能会导致索引失效。数据库无法在索引上执行隐式类型转换，因此尽量避免在查询条件中进行类型转换。
6.  **OR 条件：** 当查询条件中使用了多个 OR 条件时，如果这些条件涉及不同的列，可能会导致索引失效。尽量将 OR 条件转换为使用 UNION 或其他方式，以避免索引失效。
7.  **函数操作：** 在查询条件中使用函数操作，比如对索引列进行函数操作，可能会导致索引失效。数据库无法使用索引来加速函数操作，因此尽量避免在索引列上进行函数操作。
8.  **统计信息过期：** 数据库使用统计信息来选择查询计划，如果统计信息过期或者不准确，可能会导致数据库做出错误的优化决策。定期更新统计信息以确保数据库选择正确的查询计划。

排查索引失效问题时，可以通过数据库的执行计划、索引状态、统计信息以及查询语句的优化来识别问题所在，并采取相应的措施进行优化。

### 22、40亿个QQ号，限制1G内存，如何去重？

对于在限制为1GB内存的情况下对40亿个QQ号进行去重，可以考虑使用外部排序（External Sorting）的方法来处理。外部排序是一种适用于数据量大于内存可容纳的情况的排序方法，它将数据分成小块，每次处理一块数据，最终将这些有序的小块合并成一个有序的完整数据集。

下面是一个基本的思路，你可以根据实际情况进行调整：

1.  **分割数据块：** 将40亿个QQ号按照一定的规则划分成多个小块。每个小块的大小要适合你的内存限制，比如可以选择将每个小块限制在100MB左右。
2.  **对每个小块进行内部排序：** 将每个小块加载到内存中，使用一种高效的排序算法（比如快速排序、归并排序等）对每个小块进行排序。
3.  **逐一合并小块：** 在内存中维护一个小块合并的队列，每次从每个小块中取出一个最小的QQ号，将其写入输出文件，并从对应的小块中取出下一个QQ号填充进队列。重复这个步骤直到所有小块都被处理完毕。
4.  **重复合并过程：** 如果输出文件仍然过大，可以将输出文件继续分割成更小的块，然后进行多次合并，直到得到一个完整的有序数据集。

需要注意的是，外部排序过程需要额外的磁盘空间来存储临时数据块和合并结果。同时，选择合适的小块大小和合并策略也会影响整体性能。

在实际操作中，你可能需要使用一些编程语言或工具来实现外部排序，比如使用Python的`heapq`库来维护小块合并的队列，以及逐步处理数据块。由于数据量庞大，整个过程可能会比较耗时，所以耐心和合理的资源规划都是必要的。

另外，如果你的情况允许，也可以考虑使用分布式计算框架，将数据分布到多台机器上进行处理，以加快去重的速度。

23、说一说多级缓存是如何应用的？

多级缓存是计算机体系结构中常用的一种优化技术，旨在加速数据访问并提高系统性能。它利用不同容量和速度的存储设备来缓存数据，以降低CPU访问主存储器的频率，从而减少访问延迟。

多级缓存通常分为三级，分别是L1、L2和L3缓存，它们按照从最近到最远的访问距离进行层次划分。以下是多级缓存的应用方式：

1.  **L1缓存**：位于CPU内部，速度最快但容量最小。通常用于存储当前正在执行的指令和相关数据。由于其位置接近CPU核心，可以迅速提供数据，适用于对访问延迟敏感的任务。
2.  **L2缓存**：位于CPU核心外部，容量较大，速度较快。它承担了L1缓存无法容纳的数据，并提供更大的缓存空间。L2缓存可以通过一些高效的算法来预测数据的使用模式，从而更好地满足CPU的数据需求。
3.  **L3缓存**：位于CPU芯片上但多个核心共享，容量更大，速度相对较慢。L3缓存通常用于存储多个核心之间共享的数据，以及更大规模的工作负载。它有助于降低多核处理器之间的数据传输延迟。

多级缓存的应用方式包括以下几个方面：

-   **缓存命中和缓存失效**：当CPU需要访问数据时，会首先在最小的L1缓存中查找，如果找到则为缓存命中，否则会在更大的L2或L3缓存中查找。如果所有缓存层都没有找到需要的数据，就会发生缓存失效，需要从主存储器中加载数据。
-   **缓存替换算法**：当缓存空间不足时，会采用一些算法来决定替换哪些数据。常见的替换算法包括LRU（最近最少使用）、LFU（最不常用）等，以及一些变种。
-   **数据预取**：缓存控制器可能会根据访问模式预测未来可能需要的数据，并提前将其加载到缓存中，以提高命中率。

总之，多级缓存通过提供不同层次的缓存存储，有效地提高了计算机系统的数据访问速度和整体性能。在设计中，需要权衡容量、速度和成本等因素，以达到最佳的性能提升效果。

### 23、从B+树的角度分析为什么单表2000万要考虑分表？

从B+树的角度分析为什么单表2000万要考虑分表涉及数据库性能和查询效率的考虑。B+树是一种常用于数据库索引的数据结构，用于加速数据的插入、更新和查询操作。当单表数据量逐渐增大，可能会出现以下几个问题，从而考虑分表：

1.  **查询性能下降**：随着数据量的增加，B+树的高度可能会增加，导致查询操作的时间复杂度增加。较深的B+树意味着需要更多的磁盘I/O操作，从而影响查询的效率。
2.  **索引维护成本增加**：当数据量大时，B+树的维护成本也会增加。插入、更新和删除操作可能需要频繁地调整B+树结构，这可能导致性能下降。
3.  **内存压力增大**：单表数据量增加会增加B+树节点的数量，从而需要更多的内存来存储索引。如果内存无法容纳足够多的索引节点，就可能导致频繁的磁盘访问，进而影响查询性能。
4.  **数据备份和恢复困难**：单表数据量庞大时，数据备份和恢复变得更加复杂和耗时。分表可以使数据管理和维护变得更加灵活，有助于更好地进行备份和恢复操作。

因此，当单表数据量达到2000万这个数量级时，可能需要考虑分表来缓解上述问题。通过将数据拆分为多个表，每个表的数据量减少，B+树的高度降低，查询性能和索引维护成本可以得到改善。同时，分表还有助于更好地利用内存、简化数据管理和提高数据备份恢复的效率。然而，分表也需要综合考虑业务需求、查询模式等因素，避免出现过度分表导致的查询性能下降或连接操作复杂的问题。

25、InnoDB为什么不用跳表，Redis为什么不用B+树？

InnoDB 和 Redis 都是流行的数据库或数据存储引擎，它们在设计和实现上有各自的考虑和特点，这也影响了它们在数据结构选择方面的决策。

**InnoDB 不使用跳表的原因**： InnoDB 是 MySQL 数据库的默认存储引擎，它采用了 B+ 树作为主要的索引数据结构。B+ 树在数据库领域广泛应用，因为它对范围查询、排序等操作有着良好的支持，适合于数据库的多样化查询需求。相比之下，跳表在某些方面可能表现出色，但在数据库场景下，它的性能和特点可能不如 B+ 树。

跳表适用于有序数据的搜索，它可以在某些情况下实现快速查找，但相对于 B+ 树，跳表的实现和维护可能更为复杂，而且跳表对于范围查询的性能可能不如 B+ 树。此外，B+ 树在磁盘存储和内存管理方面也有优势，这在数据库中尤为重要。

**Redis 不使用 B+ 树的原因**： Redis 是一个内存存储数据库，它主要用于缓存和快速数据存取。在这样的场景下，B+ 树不一定是最优选择。B+ 树的设计和优势更多地与磁盘存储相关，而 Redis 的数据通常完全存储在内存中，磁盘访问并不是主要瓶颈。

Redis 使用了一种称为「跳跃表」（Skip List）的数据结构来实现有序集合。跳跃表在内存中的实现相对简单，适用于 Redis 的高速内存存储和快速读写操作。它在某些情况下可以提供良好的性能，尤其是在不需要像 B+ 树那样复杂的平衡和维护操作时。

总之，InnoDB 和 Redis 在选择数据结构上考虑了各自的使用场景、性能需求以及存储特点。虽然跳表在某些情况下可能表现得很好，但在数据库和内存存储引擎的背景下，B+ 树和跳跃表分别被选择以满足不同的性能和设计要求。

### 24、线上接口如果响应很慢如何去排查定位问题呢？

线上接口响应缓慢可能涉及多个因素，需要逐步排查和定位问题。以下是一些可能的步骤和方法：

1.  **监控和日志分析**：
    -   检查系统监控指标，例如 CPU 使用率、内存占用、网络流量等，以确定是否存在资源瓶颈。
    -   分析应用程序日志和性能监控数据，查找是否有异常或错误信息，以及哪些操作或查询导致响应变慢。
2.  **数据库查询性能**：
    -   如果接口涉及数据库查询，检查数据库性能。使用数据库性能分析工具（如EXPLAIN查询计划）来评估查询的性能，查看是否存在慢查询。
    -   确保数据库索引的正确性和有效性。
3.  **代码审查**：
    -   仔细审查接口的代码，检查是否有低效或冗余的操作。特别关注循环、递归、不必要的IO操作等。
    -   确保代码中没有阻塞、死锁或竞争条件。
4.  **网络延迟**：
    -   检查网络延迟，特别是在分布式系统中。使用网络分析工具，查看是否存在网络瓶颈或连接问题。
5.  **缓存使用**：
    -   如果应用程序使用缓存（如 Redis），确保缓存的正确使用。检查缓存是否过期，是否频繁失效，以及缓存命中率等。
6.  **第三方服务**：
    -   如果接口依赖于其他第三方服务，检查这些服务是否正常运行。可能的问题包括第三方服务响应变慢、不稳定或不可用。
7.  **性能测试**：
    -   进行性能测试，模拟高负载情况，观察接口在负载下的表现。这可以帮助确定是否存在扩展性问题。
8.  **代码优化和重构**：
    -   基于分析结果，进行代码优化或重构。可能需要改进算法、减少数据库查询次数、使用缓存等手段来提高性能。
9.  **横向扩展**：
    -   如果系统瓶颈主要来自资源限制，考虑横向扩展，增加服务器数量以分担负载。
10.  **监控和警报**：
     -   设置实时监控和警报机制，以便在出现性能问题时能够及时采取行动。

总之，排查和解决线上接口响应缓慢的问题需要综合考虑多个因素，并逐步进行分析和改进。及时的监控和持续的性能优化是保障系统稳定和高效运行的关键。

### 25、怎么做数据对账？

当需要进行数据对账时，通常涉及比较两个或多个数据源之间的差异，以确保数据的一致性和准确性。以下是一般的数据对账步骤：

1.  **确定对账目标**： 确定要对账的数据源和目标，例如两个不同系统之间的数据、两个时间点的数据等。
2.  **数据提取**： 从每个数据源中提取需要对账的数据。这可能涉及数据库查询、API调用、文件导出等。
3.  **数据转换**： 将提取的数据转换成统一的格式，以便于后续比较。确保数据字段名、数据类型等匹配。
4.  **数据比较**： 对转换后的数据进行比较。比较的方法可以包括逐行比对、使用哈希函数生成数据指纹后进行比对等。
5.  **差异分析**： 如果数据源之间存在差异，进行详细的差异分析。确定哪些数据不一致，并找出造成差异的原因。
6.  **差异解决**： 根据差异分析结果，采取适当的措施来解决数据差异。可能需要更新数据、纠正错误等。
7.  **记录和报告**： 记录对账过程的结果，包括哪些数据一致，哪些数据不一致，以及差异的原因和解决方案。这可以作为后续审计和改进的依据。
8.  **自动化对账**（可选）： 对于频繁进行的对账任务，可以考虑建立自动化对账流程。这可以减少人工错误和时间成本。
9.  **定期重复对账**： 数据对账不是一次性任务，应该定期重复执行，以确保数据一致性的持续性。

值得注意的是，数据对账可能会因应用场景和数据的不同而有所不同，上述步骤提供了一个通用的框架，可以根据实际情况进行调整和扩展。此外，对于大规模数据，可能需要考虑性能和效率问题，选择合适的工具和算法来进行对账操作。

### 26、MySQL千万级大表如何做数据清理？

清理MySQL千万级大表的数据可以采取以下几种方法：

1.  分区表：如果你的表支持分区，可以根据时间范围将数据分散到不同的分区中。这样，当需要清理数据时，只需删除相应的分区即可，而不需要扫描整个表。这种方法可以提高清理数据的效率。
2.  分批删除：将要删除的数据分成多个较小的批次进行删除，而不是一次性删除整个表的数据。可以使用LIMIT和OFFSET子句来限制每个批次的删除数量，并使用循环或脚本来逐批删除数据。这样可以减少对数据库的负载，避免一次性删除大量数据时的性能问题。
3.  使用索引：确保表中的字段上有适当的索引。索引可以加快删除操作的速度，特别是在大表中。根据删除条件创建适当的索引，这样数据库可以更快地定位到要删除的数据。
4.  优化删除语句：使用DELETE语句删除数据时，可以优化语句的性能。避免在删除操作中使用不必要的子查询或复杂的条件，这可能会导致查询执行时间过长。确保删除语句的WHERE条件能够充分利用索引，以提高删除操作的效率。
5.  数据归档：如果你需要保留历史数据但不经常查询，可以考虑将旧数据归档到其他表或存储介质中，例如归档表、归档文件或其他数据库。这样可以减小主表的大小，提高查询性能。
6.  定期维护：定期进行数据库维护操作，例如优化表结构、重建索引、收集统计信息等。这些操作可以提高数据库的性能，并减少数据清理的需要。

在进行数据清理操作之前，请务必备份数据库以防止意外数据丢失。此外，根据你的具体情况，可能需要结合其他方法或工具来进行数据清理，例如使用分布式数据库、数据分片或数据迁移等。最好在测试环境中进行测试和验证，以确保清理操作的安全性和效果。

### 27、为什么MySQL用B+树，MongoDB用B树？

MySQL和MongoDB使用不同的树结构（B+树和B树）作为其索引数据结构，这是基于它们的设计目标和特点而做出的选择。

B树（B-Tree）： &#x20;
B树是一种多路搜索树，用于在数据库中实现索引。它的主要特点是每个节点可以有多个子节点，适用于磁盘存储的数据库系统。B树的特点包括：

1.  平衡性：B树保持了树的平衡性，使得在查找操作时，最坏情况下的搜索时间仍然是O(log n)。这对于磁盘存储系统来说非常重要，因为它减少了磁盘I/O次数，提高了查询效率。
2.  节点包含键值和数据：B树的每个节点既包含键值，也包含数据。这意味着在叶子节点上即可找到实际的数据记录，而不需要再次跳转到另一个位置。56

MongoDB使用B树作为索引数据结构，因为它被设计为一种灵活的文档数据库，支持丰富的数据模型。B树适用于在磁盘上存储大量数据，适合MongoDB这种需要处理大量文档的情况。然而，MongoDB在某些情况下可能也使用B+树的变体，比如Compound Indexes，以提高查询性能。

B+树（B-Plus Tree）： &#x20;
B+树是B树的变体，在B树的基础上进行了一些优化。它的主要特点是内部节点不存储数据，而只存储键值，实际的数据都存储在叶子节点上。B+树的特点包括：

1.  更适合范围查询：由于B+树的数据都存储在叶子节点上，并且叶子节点之间使用指针连接，因此范围查询更高效。这对于数据库系统非常重要，因为范围查询是数据库常见的查询类型之一。
2.  适合磁盘存储：B+树的叶子节点形成了一个有序链表，便于顺序访问。这对于磁盘存储来说非常高效，因为可以减少磁盘的随机I/O操作。

MySQL使用B+树作为其索引数据结构，这是因为MySQL通常处理关系型数据，B+树适合在关系型数据库中进行范围查询和有序遍历。此外，B+树的结构使得它更适合支持聚簇索引（将数据和索引存储在一起），这在关系型数据库中非常常见。

综上所述，MySQL选择B+树作为索引结构，以适应其关系型数据模型和范围查询的需求，而MongoDB则选择B树，以适应其面向文档的数据模型。虽然两者的索引结构不同，但都旨在提供高效的数据访问和查询性能。

### 28、高并发的积分系统，在数据库增加积分，怎么实现？

在高并发的积分系统中，实现数据库增加积分的方式可以采用以下几种方法：

1.  乐观锁（Optimistic Locking）：使用乐观锁机制可以在不加锁的情况下实现并发操作。在数据库表中添加一个版本号（或时间戳）字段，每次更新积分时检查版本号，如果版本号匹配，则更新积分并增加版本号；如果版本号不匹配，则表示其他并发操作已修改数据，需要进行冲突处理。
2.  悲观锁（Pessimistic Locking）：使用悲观锁可以在操作期间锁定数据，防止其他并发操作对数据进行修改。在更新积分之前，对相关的数据行或表进行加锁，确保只有一个线程可以修改数据。但悲观锁可能会导致性能下降，因为其他线程需要等待锁的释放。
3.  分布式锁（Distributed Lock）：使用分布式锁可以实现多个应用程序实例之间的协调，确保只有一个实例可以执行增加积分的操作。可以使用基于数据库的分布式锁，如在MySQL中使用行级锁或表级锁，或者使用分布式锁服务，如Redis的分布式锁。
4.  队列（Queue）：将增加积分的请求放入队列中，由单个线程或多个工作线程按顺序处理请求。这样可以避免并发冲突，并提供顺序处理的能力。常见的队列系统包括RabbitMQ、Kafka等。
5.  事务（Transaction）：在数据库操作中使用事务可以确保操作的原子性和一致性。将增加积分的操作放在一个事务中，当多个并发操作同时进行时，数据库会自动处理并发冲突，保证数据的正确性。

无论采用哪种方法，都需要根据具体的业务需求和系统架构来选择合适的方案。同时，还需要考虑数据库的性能和扩展性，以及并发操作可能带来的性能瓶颈和资源竞争。在设计和实现时，可以结合使用以上的方法，以满足高并发积分系统的需求。

### 29、MySQL热点数据更新会带来哪些问题？

当MySQL中的热点数据频繁更新时，可能会导致以下问题：

1.  锁竞争：多个并发事务同时更新同一行或同一组数据时，会引发锁竞争。如果没有合适的锁策略和并发控制机制，可能会导致事务等待和阻塞，降低系统的并发性能。
2.  死锁：如果多个事务之间存在循环依赖的更新操作，并且没有正确处理锁的顺序，可能会导致死锁的发生。死锁会导致事务无法继续执行，需要通过超时或者手动干预来解决。
3.  数据不一致：当热点数据频繁更新时，如果没有正确的事务隔离级别和并发控制策略，可能会导致数据不一致的问题。例如，读取到未提交的数据或者读取到部分更新的数据。
4.  性能瓶颈：频繁的热点数据更新可能会导致数据库性能瓶颈，特别是在高并发的情况下。数据库需要处理大量的更新操作，可能会增加CPU和磁盘的负载，导致响应时间延长和吞吐量下降。
5.  数据库压力：热点数据更新可能会导致数据库的存储空间增加和磁盘IO的负载增加。如果没有及时的数据库优化和调整，可能会导致数据库性能下降和存储资源的消耗。

为了解决这些问题，可以采取以下措施：

1.  优化查询和更新语句：通过合理的索引设计、查询优化和更新批量处理等方式，减少对热点数据的频繁更新操作，降低锁竞争和数据库负载。
2.  选择合适的事务隔离级别：根据业务需求和数据一致性要求，选择合适的事务隔离级别，避免读取到脏数据或不可重复读的问题。
3.  使用合理的并发控制策略：通过锁机制、乐观锁或悲观锁等方式，控制并发事务对热点数据的访问和更新，避免锁竞争和死锁的发生。
4.  数据库优化和扩展：通过合理的数据库配置、硬件升级、分库分表、读写分离等方式，提升数据库的性能和扩展性，以应对高并发的热点数据更新。

综上所述，热点数据的频繁更新可能会带来锁竞争、死锁、数据不一致、性能瓶颈和数据库压力等问题。通过合理的数据库设计、并发控制和优化策略，可以有效地解决这些问题，并提升系统的性能和可靠性。

### 30、和外部机构交互如何防止被外部服务不可用而拖垮

与外部机构交互时，为了防止外部服务不可用导致自身服务受到影响，可以采取以下一些策略：

1.  **超时设置和重试机制：** 在与外部服务进行交互时，设置合适的超时时间。如果在预定时间内未收到响应，可以触发重试机制，多次尝试与外部服务建立连接。但是要注意避免无限制的重试，以免对自身系统造成过多负担。
2.  **限流和熔断：** 使用限流和熔断机制来控制与外部服务的交互频率。当外部服务不可用或响应时间过长时，可以暂时停止或降低对该服务的请求，防止过多的请求集中到不可用的服务上，从而拖垮自身服务。
3.  **服务降级：** 在外部服务不可用的情况下，可以采取服务降级策略，提供一个备用的功能或响应，确保自身系统的基本功能仍然可用。例如，展示缓存数据、提供默认值等。
4.  **异步处理：** 将与外部服务的交互设计为异步操作，不会直接阻塞主要流程。将请求放入消息队列或异步任务中，从而减少直接依赖外部服务的耦合。
5.  **多地域部署：** 如果外部服务支持多地域部署，可以选择将自身服务部署在多个地理位置，以减少单一地区外部服务不可用对整体系统的影响。
6.  **监控和报警：** 实施有效的监控和报警系统，及时检测外部服务的可用性和性能。一旦发现问题，可以迅速采取措施，如切换到备用服务、通知相关人员等。
7.  **合理的容错策略：** 在代码中实施合理的容错策略，例如处理异常情况、优雅降级和自动恢复机制，确保系统在外部服务不稳定时也能正常运行。
8.  **预案和应急准备：** 制定与外部服务不可用时的应急预案，明确责任人员和处理流程，以便在发生问题时能够迅速应对。
9.  **合作伙伴选择：** 在选择外部服务供应商时，要考虑其稳定性和可靠性。选择有良好服务记录和强大基础设施的供应商，减少不可用风险。

总之，通过合理的设计和应对策略，可以最大程度地降低外部服务不可用对自身服务造成的影响，保障系统的稳定性和可用性。

### 31、MySQL 里有 2000W 数据，Redis 中只存 20W 的数据，如何保证 Redis 中的数据都是热点数据?

要确保Redis中存储的数据都是热点数据，可以考虑以下策略：

1.  **缓存策略选择：** 选择合适的缓存策略，如LRU（最近最少使用）、LFU（最不经常使用）或基于时间过期等。这些策略可以根据数据的访问频率和使用情况来淘汰冷数据，确保Redis中存储的数据都是热点数据。
2.  **数据预热：** 在系统启动或负载低峰期，可以通过预热的方式将热点数据加载到Redis中。预热可以通过批量读取数据库中的热点数据，并将其存储到Redis中，以提前缓存热点数据，减少后续访问时的延迟。
3.  **数据更新时同步更新Redis：** 当MySQL中的数据发生更新时，及时将更新的数据同步到Redis中。可以通过在应用程序中实现数据更新的逻辑，保持MySQL和Redis中数据的一致性。这样可以确保Redis中存储的数据是最新的热点数据。
4.  **定期更新数据：** 定期更新Redis中的数据，将最新的热点数据加载到Redis中。可以通过定时任务或者触发器来实现定期更新，以保证Redis中的数据与MySQL中的热点数据保持同步。
5.  **监控和自动清理：** 监控Redis中的数据访问情况和存储空间占用情况。根据实际情况，自动清理不再是热点数据的缓存，以释放存储空间并保持Redis中存储的数据都是热点数据。
6.  **合理设置过期时间：** 对于不再频繁访问的数据，可以设置较短的过期时间，以便在一段时间内没有被访问时自动从Redis中淘汰。这样可以确保Redis中存储的数据都是当前较为活跃的热点数据。

通过以上策略，可以有效地保证Redis中存储的数据都是热点数据，提高数据访问的性能和响应速度。但需要根据具体业务场景和数据访问模式来选择和调整策略，以达到最佳效果。



## 项目上线问题排查

### 1、RT飙高问题排查过程

当遇到实时（RT）飙高的问题时，可以按照以下步骤进行排查：

1.  **确认问题现象：** 首先，需要明确实时飙高的具体表现和受影响的方面。例如，是CPU使用率飙高还是网络延迟增加，是某个特定服务的响应时间增长，还是整个系统的吞吐量下降等。
2.  **监测系统指标：** 使用系统监控工具或性能分析工具来收集系统的关键指标。这些指标包括CPU使用率、内存使用率、网络吞吐量、磁盘IO等。通过监测这些指标，可以了解系统在实时飙高期间的状态。
3.  **查看日志和错误信息：** 检查系统日志和错误日志，寻找与实时飙高相关的任何错误或异常信息。这些信息可能会提供有关问题原因的线索，例如异常堆栈跟踪、错误消息等。
4.  **分析负载和请求模式：** 研究实时飙高期间的负载和请求模式。检查是否有异常的请求频率或请求量增加，是否有突发的负载压力，以及是否有特定的请求类型或资源导致了飙高问题。
5.  **检查系统配置和资源限制：** 检查系统的配置和资源限制，包括服务器硬件配置、操作系统参数、应用程序配置等。确保系统的配置与实际需求相匹配，并且没有过度限制资源的设置。
6.  **排查代码问题：** 检查应用程序的代码，寻找可能导致实时飙高的问题。这可能包括低效的算法、循环中的死循环、资源泄漏、线程阻塞等。使用性能分析工具来确定代码中的瓶颈和性能热点。
7.  **排查第三方服务：** 如果系统依赖于第三方服务，检查这些服务是否出现故障或延迟。可能需要联系第三方服务提供商来了解是否存在与实时飙高相关的问题。
8.  **进行压力测试和负载测试：** 使用压力测试工具模拟实际负载，并观察系统在高负载情况下的表现。这有助于确定系统的性能极限和可能的瓶颈。
9.  **逐步回退变更：** 如果实时飙高问题与最近的系统变更相关，可以逐步回退这些变更，以确定是否有特定的变更引起了飙高问题。
10.  **寻求专家帮助：** 如果以上步骤无法解决问题，可以寻求专家的帮助，例如系统管理员、开发人员或性能工程师。他们可能有更深入的知识和经验来解决实时飙高问题。

通过以上排查步骤，可以逐步缩小问题范围，找到实时飙高问题的根本原因，并采取相应的措施来解决问题。

### 2、CPU飙高问题排查过程

排查 CPU 飙高问题的过程可以分为以下步骤：

1.  **确认问题：** 首先，要明确 CPU 飙高的问题是否真实存在。可以通过监控工具、系统日志等途径来验证 CPU 使用率是否异常升高。
2.  **确定影响范围：** 确定是整个系统的 CPU 使用率升高还是特定进程/应用程序导致的。这可以通过查看系统级别的监控数据和进程级别的监控数据来判断。
3.  **分析进程和应用程序：** 如果是特定进程或应用程序导致的 CPU 飙高，就需要分析这些进程/应用程序的行为。可以使用工具如 `top`、`htop`、`ps` 等来查看进程的 CPU 使用率、内存占用、线程数等信息。
4.  **查看系统资源使用情况：** 检查内存、磁盘、网络等资源的使用情况，因为资源竞争也可能导致 CPU 飙高。特别注意内存的使用情况，过多的交换（swap）可能会导致 CPU 使用率升高。
5.  **检查日志：** 查看系统日志、应用程序日志以及可能的错误日志，以便找到任何异常或错误信息。有时候某些异常事件可能导致 CPU 使用率升高。
6.  **性能分析工具：** 使用性能分析工具，如 `perf`、`strace`、`dtrace` 等，来跟踪进程的系统调用、函数调用和事件，以帮助确定是哪些操作导致了 CPU 飙高。
7.  **检查代码：** 如果问题与特定应用程序相关，可能需要检查应用程序的代码，查找可能的瓶颈或死循环。代码中可能存在的资源竞争、不合理的循环等问题都可能导致 CPU 使用率升高。
8.  **硬件问题排除：** 考虑硬件故障可能导致的问题，如散热不足、硬件损坏等，这些问题也可能导致 CPU 飙高。
9.  **升级和优化：** 如果确定问题是由于某个应用程序或组件的性能问题导致的，可以尝试升级软件版本，应用性能优化技巧，或者调整配置参数来缓解问题。
10.  **监控和预防：** 一旦问题解决，建议设置持续的监控来跟踪系统和应用程序的性能，以便及时发现并预防类似问题的再次发生。

在排查 CPU 飙高问题时，关键是收集足够的信息，从多个角度进行分析，以便确定问题的根本原因。根据不同的情况，可能需要结合多种方法和工具来解决问题。

### 3、数据库连接池满排查过程

数据库连接池满的报警，报错信息如下

应用报警：4103.ERR\_ATOM\_CONNECTION\_POOL\_FULL，应用数据库连接池满。

陆续出现 4200.ERR\_GROUP\_NOT\_AVALILABLE、4201.ERR\_GROUP\_NO\_ATOM\_AVAILABLE、4202.ERR\_SQL\_QUERY\_TIMEOUT等数据库异常报警。

当数据库连接池满时，可以按照以下步骤进行排查：

1.  **确认连接池满的迹象：** 监控数据库连接池的指标，例如连接数、活动连接数、空闲连接数等。如果这些指标达到连接池的最大限制，说明连接池已满。
2.  **查看数据库连接池配置：** 检查连接池的配置参数，包括最大连接数、最小空闲连接数、连接超时时间等。确保这些参数的设置合理，并且能够满足系统的需求。
3.  **分析连接池使用情况：** 查看连接池的使用情况，包括连接的获取和释放过程。记录下频繁获取连接的代码路径和时间点，以及连接释放是否及时。这有助于找出连接泄露或者连接使用不当的问题。
4.  **检查数据库连接资源：** 检查数据库服务器的连接资源情况。查看数据库服务器的最大连接数设置，以及当前连接数是否接近最大限制。如果数据库服务器也存在连接数限制，可以考虑增加最大连接数的配置。
5.  **检查数据库性能：** 检查数据库服务器的性能指标，例如 CPU 使用率、内存使用率、磁盘 I/O 等。如果数据库服务器的性能达到瓶颈，可能导致连接池满。优化数据库性能可以缓解连接池满的问题。
6.  **检查数据库操作：** 检查应用程序中的数据库操作，包括查询语句、事务处理等。优化数据库操作可以减少连接的占用时间，从而减少连接池的压力。
7.  **检查应用程序并发访问：** 检查应用程序的并发访问情况，特别是在高峰时段。如果并发访问量过大，可能会导致连接池满。可以考虑增加连接池的大小或者优化应用程序的并发处理能力。
8.  **查看日志和异常信息：** 检查应用程序的日志和异常信息，查找是否有连接池相关的错误或异常。这些信息可以帮助定位连接池满的原因。
9.  **性能分析工具：** 使用性能分析工具来跟踪应用程序的数据库连接使用情况，例如连接的创建、销毁、使用时间等。这有助于找出连接使用不当或者泄露的问题。
10.  **优化和调整：** 根据排查结果，进行相应的优化和调整。可以调整连接池的配置参数，增加连接池的大小，优化数据库操作，或者增加数据库服务器的性能。

通过以上步骤的排查，可以找出数据库连接池满的原因，并采取相应的措施来解决问题。重要的是收集足够的信息，从多个角度进行分析，以便确定问题的根本原因。

### 4、数据库CPU被打满排查过程

开发经常收到数据库的报警，提示我们的数据库的CPU有异常飙高的情况，通过top命令发现，经常把CPU打满了。

![](C:\Users\Admin\Desktop\尚硅谷Java技术之高频面试题-v2023.9\场景题\项目上线问题排查\image\image_EA4lcUqgLZ.png)

排查数据库CPU被打满的问题通常需要一系列步骤来定位和解决。下面是一般的排查过程：

1.  **确认CPU使用率高**: 首先，确保数据库服务器的CPU使用率确实是高的。可以使用操作系统提供的工具（如`top`、`htop`等）或数据库性能监控工具来验证。
2.  **检查数据库负载**: 查看数据库的当前负载情况，包括并发连接数、查询数量、事务处理数等。这可以帮助确认是否存在异常的数据库活动。
3.  **分析长时间运行的查询**: 使用数据库性能分析工具，如`EXPLAIN`语句、查询计划查看是否有复杂、低效率的查询在运行。优化这些查询可以减轻CPU负担。
4.  **检查索引使用情况**: 确保数据库表使用了适当的索引。没有或者不正确使用索引可能导致查询变得非常耗时，进而导致CPU使用率上升。
5.  **检查锁等待情况**: 死锁或者大量的锁等待会导致CPU被打满。确保应用程序和数据库使用了合适的锁策略，避免锁争用。
6.  **检查硬件资源**: 确保数据库服务器的硬件资源足够，包括CPU核数、内存、磁盘I/O等。不足的硬件资源可能导致CPU过载。
7.  **检查并发连接数**: 大量并发连接可能导致CPU过载。评估并优化应用程序连接池的设置，确保不会有过多的闲置连接。
8.  **监控长时间运行的进程**: 使用操作系统的工具来监控是否有长时间运行的进程占用了过多的CPU资源。这可能是恶意进程或者其他异常情况。
9.  **审查系统日志**: 检查数据库服务器的系统日志，查找异常、错误消息，这有助于找到可能的问题根源。
10.  **考虑数据库优化**: 如果排查过程中发现一些持续存在的性能问题，考虑数据库的整体优化，包括配置优化、硬件升级、数据库版本升级等。
11.  **性能测试**: 在排查过程结束后，可以进行性能测试，验证优化措施是否有效，是否解决了CPU被打满的问题。

总之，排查数据库CPU被打满的过程需要综合考虑多个因素，从数据库层面、应用程序层面和硬件层面分析，最终找到根本原因并采取相应措施来解决问题。

### 5、OOM问题排查过程

OOM（Out of Memory）问题是指系统内存不足，无法满足进程的内存需求，导致进程被操作系统终止的情况。下面是一般的OOM问题排查过程：

1.  **确认OOM错误**: 首先，确认系统中是否发生了OOM错误。可以查看系统日志（如/var/log/messages）或者使用命令`dmesg`来检查系统日志中是否有OOM相关的错误信息。
2.  **检查内存使用情况**: 使用系统监控工具（如top、htop）或者命令（如free、vmstat）来检查系统的内存使用情况。确认系统内存是否已经耗尽。
3.  **检查进程内存使用**: 确定哪个进程使用了大量的内存。可以使用top命令按内存使用排序，或者使用ps命令查看进程的内存占用情况。
4.  **检查内存泄漏**: 如果发现某个进程占用了大量内存，但是没有明显的原因，可能存在内存泄漏的情况。可以使用内存分析工具（如Valgrind）来检测和定位内存泄漏问题。
5.  **检查进程资源限制**: 确认进程的资源限制是否合理，包括内存限制（ulimit -a）和文件描述符限制（ulimit -n）。如果限制过低，可能导致进程无法获取足够的内存资源。
6.  **检查系统交换空间**: 确认系统是否启用了交换空间（swap），以及交换空间的大小。如果交换空间过小或者未启用，当内存不足时，系统无法将部分内存数据交换到磁盘，从而导致OOM错误。
7.  **检查程序日志**: 检查程序的日志文件，查找是否有与内存使用相关的错误或异常信息。这有助于定位程序中可能导致OOM的问题。
8.  **优化程序内存使用**: 根据具体情况，优化程序的内存使用方式。可以考虑使用内存池、减少内存分配次数、释放不再使用的内存等方法来降低内存占用。
9.  **调整系统配置**: 根据具体情况，可能需要调整系统的内核参数或者其他配置，以提高系统的内存管理和利用效率。
10.  **增加硬件资源**: 如果经过优化和调整后仍然无法解决OOM问题，可能需要考虑增加系统的硬件资源，如增加内存容量或者升级到更高性能的服务器。

总之，OOM问题的排查过程需要综合考虑多个因素，包括内存使用情况、进程资源限制、系统配置等，通过定位问题原因并采取相应措施来解决问题。

### 6、频繁FullGC问题排查

频繁的Full GC（Full Garbage Collection）问题通常是由于Java应用程序中的内存管理问题导致的。下面是一般的排查过程：

1.  **确认Full GC频率**: 首先，确认Full GC确实发生频繁。可以通过查看Java应用程序的GC日志或者性能监控工具来确定Full GC的发生频率和持续时间。
2.  **检查堆内存设置**: 确认Java应用程序的堆内存设置是否合理。堆内存过小可能导致频繁的垃圾回收，而堆内存过大可能导致Full GC时间过长。可以通过调整-Xmx和-Xms参数来适当调整堆内存大小。
3.  **分析GC日志**: 详细分析GC日志，查看Full GC发生的原因。GC日志中会提供关于垃圾回收的详细信息，包括每个GC阶段的时间、堆内存使用情况、对象分配速率等。通过分析GC日志可以确定Full GC的具体原因。
4.  **检查内存泄漏**: 频繁的Full GC可能是由于内存泄漏导致的。使用内存分析工具（如MAT、VisualVM）来检测和定位内存泄漏问题。分析内存快照可以查看对象的引用链，找出造成内存泄漏的代码或对象。
5.  **检查对象生命周期**: 确认应用程序中的对象生命周期是否合理。如果有大量长时间存活的对象，可能会导致频繁的Full GC。可以考虑优化对象的创建和销毁方式，减少对象的生命周期。
6.  **优化垃圾回收器参数**: 根据具体情况，可以调整垃圾回收器的参数来优化GC性能。不同的垃圾回收器有不同的参数可供调整，如新生代和老年代的比例、垃圾回收算法等。
7.  **减少对象分配**: 频繁的Full GC可能是由于过多的对象分配导致的。可以通过重用对象、使用对象池、减少临时对象的创建等方式来降低对象分配的频率。
8.  **检查外部资源释放**: 确保应用程序正确释放外部资源，如数据库连接、文件句柄等。未正确释放外部资源可能导致内存泄漏和频繁的Full GC。
9.  **增加堆内存或调整GC策略**: 如果经过优化后仍然无法解决频繁的Full GC问题，可以考虑增加堆内存大小或者尝试其他的GC策略，如G1 GC。
10.  **性能测试和监控**: 在排查过程结束后，进行性能测试和监控，验证优化措施是否有效，是否解决了频繁的Full GC问题。

总之，频繁的Full GC问题排查需要综合考虑堆内存设置、GC日志分析、内存泄漏、对象生命周期等因素，并采取相应的优化措施来减少Full GC的频率和持续时间。

### 7、Arthas统计方法耗时的原理是什么？

Arthas 是一款用于 Java 应用程序的诊断工具，可以实时地查看和修改应用程序的运行状态。其中一个功能就是统计方法的耗时，这个功能主要是通过对字节码的修改来实现的。

具体原理如下：

1.  **字节码修改**: Arthas 使用字节码增强技术，通过在类加载时修改字节码，在方法的入口和出口处插入计时代码。这使得 Arthas 能够在不修改源代码的情况下，动态地统计方法的执行时间。
2.  **方法耗时统计**: 当目标方法被调用时，Arthas 在方法入口处记录当前时间戳（start time），然后在方法退出时记录另一个时间戳（end time）。通过这两个时间戳的差值，就可以计算出方法的执行时间，从而实现方法耗时的统计。
3.  **展示和分析**: Arthas 收集到方法耗时的数据后，会将这些数据进行汇总并展示给用户。用户可以通过 Arthas 提供的命令或者 Web 控制台来查看方法的平均执行时间、最大执行时间、执行次数等信息，从而快速定位潜在的性能瓶颈。

需要注意的是，由于 Arthas 是通过字节码增强实现方法耗时的统计，所以在某些情况下可能会对应用程序的性能产生一定的影响，特别是当需要对大量方法进行耗时统计时。因此，在生产环境中，应该谨慎使用 Arthas 的耗时统计功能，避免过度的方法耗时统计对应用程序性能造成不必要的影响。

另外，Arthas 还提供了其他强大的功能，如实时查看方法参数、修改方法返回值等，可以帮助开发人员更方便地诊断和调试 Java 应用程序。

### 8、慢SQL问题排查

慢SQL问题是指在数据库中执行的SQL语句花费了过长的时间来完成。下面是一般的慢SQL问题排查过程：

1.  **确认慢SQL**: 首先，确认哪些SQL语句被认为是慢SQL。可以通过数据库的性能监控工具或日志来获取执行时间较长的SQL语句。
2.  **分析执行计划**: 对于慢SQL，分析其执行计划是非常重要的。执行计划描述了数据库是如何执行SQL语句的，包括使用的索引、表的访问方式等。通过执行计划可以确定是否存在索引缺失、全表扫描等性能问题。
3.  **检查索引使用**: 确认慢SQL是否使用了适当的索引。可以通过执行计划或数据库的索引统计信息来判断是否存在索引缺失、索引选择不当等问题。根据需要，可以创建、修改或删除索引来优化查询性能。
4.  **优化SQL语句**: 对于慢SQL，可以考虑对SQL语句进行优化。可以通过重写SQL语句、使用更合适的查询方式（如JOIN、子查询等）、避免使用不必要的函数或操作符等来提高查询性能。
5.  **检查表结构和数据量**: 确认表的结构是否合理，并检查表中的数据量是否过大。如果表结构不合理或数据量过大，可能会导致查询性能下降。可以考虑调整表结构、拆分大表、分区等方式来优化查询性能。
6.  **数据库优化**: 除了SQL语句本身，还可以考虑对数据库进行优化。例如，调整数据库的缓冲区大小、增加内存、优化数据库参数配置等，以提升数据库的整体性能。
7.  **使用数据库工具**: 使用数据库性能监控工具或查询分析工具可以更直观地分析慢SQL问题。这些工具可以提供更详细的性能指标、执行计划、索引建议等信息，帮助更准确地定位和解决慢SQL问题。
8.  **性能测试和监控**: 在优化慢SQL后，进行性能测试和监控，验证优化措施是否有效，是否解决了慢SQL问题。

总之，慢SQL问题排查需要综合考虑SQL语句本身、索引使用、表结构、数据库配置等多个因素，并采取相应的优化措施来提高查询性能。同时，定期监控数据库的性能，及时发现和解决慢SQL问题，以保证应用程序的正常运行和良好的性能。

### 9、Load飙高问题排查过程

有一个项目，平常都没事的，运行的都比较好，但每次在发布过程中，刚刚重启好机器经常会有cpu利用率和load飙高的现象，导致我们项目的RT变高，反馈有大量超时.

当服务器的负载（Load）飙高，表示服务器正在承受超过其处理能力的负载，导致性能下降或服务不可用。以下是一般的 Load 飙高问题排查过程：

1.  **确认负载情况**: 使用系统监控工具（如top、htop等）或性能监控平台，确认服务器的负载情况。负载通常由三个数字表示，分别是1分钟、5分钟和15分钟的平均负载。如果这些数字超过服务器的处理能力，说明负载过高。
2.  **检查系统资源使用**: 检查服务器的 CPU、内存、磁盘和网络等资源的使用情况。使用工具（如top、free、iostat等）来查看各个资源的使用情况，确定是否有资源瓶颈导致负载飙高。
3.  **查找高负载进程**: 使用系统监控工具或命令（如top、ps等）查找占用系统资源较多的进程。关注 CPU 使用率高的进程，以及可能导致高磁盘IO或网络流量的进程。
4.  **分析高负载进程**: 对于占用系统资源较多的进程，进一步分析其原因。可以查看进程的日志、配置文件、线程信息等，以确定是否存在异常情况、死循环、资源竞争等问题。
5.  **优化高负载进程**: 根据分析结果，对高负载进程进行优化。可能的优化措施包括改进代码逻辑、减少资源占用、增加缓存、调整线程池大小等。
6.  **扩展资源**: 如果负载过高是由于资源不足导致的，可以考虑扩展服务器资源。例如，增加 CPU 核心、扩大内存容量、使用更快的磁盘等。
7.  **监控和自动化**: 部署监控系统，实时监测服务器的负载情况，及时发现和解决负载飙高问题。可以设置警报机制，当负载超过一定阈值时，及时通知运维人员。
8.  **性能测试和调优**: 在优化措施实施后，进行性能测试和监控，验证是否解决了负载飙高问题，并持续监控服务器的性能，及时调整和优化。

需要注意的是，负载飙高可能由多种原因引起，可能是由于应用程序的问题，也可能是由于系统配置不当或硬件故障等。因此，在排查过程中需要综合考虑多个因素，并采取相应的措施来解决负载飙高问题。







#                                          人事面试

## 一、请介绍一下你自己

**回答提示：** 这是面试官100%会问的问题，一般人回答这个问题过于平常，只说姓名、年龄、爱好、所学专业等，如果你用一分钟来重复你的简历，那么，你的印象加分没有了！不妨坦诚自信地展现自我，重点突出与应聘职位相吻合的优势。你的相关能力和素质是企业最感兴趣的信息。因为，在许多情况下，在听取你的介绍时，面试官也会抓住他感兴趣的点深入询问。所以，在进行表述时，要力求以真实为基础，顾及表达的逻辑性和条理性，避免冗长而没有重点的叙述。一定要在最短的时间内激发起面试官对你的好感。

**回答范例：**

1、我叫XX，今年X岁，XXXX年毕业于XX大学。有3年的开发工作经验，我对技术有深厚的兴趣，专业知识面宽，责任心强，思路清晰，沟通力能好，精通.Net技术体系，熟悉MVC。平常有时间看看博客，并且自己也喜欢在CSDN上写技术类的文章，与博友一起讨论。谢谢！

2、如果跟人事自我介绍：您好！我叫\*\* *，（如果学校和专业好的话可以提一下，一般的话就算了。）我之前在XX公司做过两年JAVA开发工程师，在这两年当中大概接触过什么样类型的项目，（比如商城，金融等）今天看了咱们公司招聘的岗位需求跟我之前的工作内容挺相符的，而且咱们公司的业务也是我喜欢的类型，所以我今天过来面试。希望可以加入到咱们公司当中来。 3、如果是跟技术自我介绍：您好！我叫*\*\*，（如果学校和专业好的话可以提一下，一般的话就算了。）我之前在XX公司做过两年JAVA开发工程师，在这两年当中大概接触过什么样类型的项目，（比如商城，金融等）；在做这些项目的当中常用的一些技术点包括XX技术，（另外除了常用的技术还会一些其他的专业技能），今天看了咱们公司招聘的岗位需求跟我之前的工作内容挺相符的，所以我今天过来咱们公司面试，希望可以加入到咱们这个大家庭当中来。

## **二、为什么来**深圳找工作？

面试官对异地求职者90%都会问的问题，主要考察你是否稳定，个人经验能力之外，排在第一位的就是稳定性，如果不够稳定，那么其余都是空谈。

**回答范例：** 我来自湖南，湖南是一个农业大省，IT行业还不是很发达，我是学计算机专业的，也很喜欢这个行业，深圳在国内IT行业发展是最快的，所以我想来这里谋求发展，学习更多的新技术，能够带来自我的提升。

**注意：** 不要说以前公司有多么不好。也不要说哪个哥们混的很不错，羡慕才来深圳。因为企业招人想要的都是能够长期工作的人，可能哪个哥们哪天在别的地方又混的更好了，你是不是还要跳槽？所以，只要说来学习更多新技术和管理经验就够了。

## 三、你为什么离开原来的公司？

**回答提示：** 最重要的是：应聘者要使找招聘单位相信，应聘者在过往的单位的“离职原因”在此家招聘单位里不存在。避免把“离职原因”说得太详细、太具体。不能掺杂主观的负面感受，如“太辛苦”、“人际关系复杂”、“管理太混乱”、“公司不重视人才”、“公司排斥我们某某的员工”等。但也不能躲闪、回避，如“想换换环境”、“个人原因”等。不能涉及自己负面的人格特征，如不诚实、懒惰、缺乏责任感、不随和等。尽量使解释的理由为应聘者个人形象添彩。

**回答范例：** 如“我离职是因为这家公司倒闭；我在公司工作了三年多，有较深的感情；从去年始，由于市场形势突变，公司的局面急转直下；到眼下这一步我觉得很遗憾，但还要面对显示，重新寻找能发挥我能力的舞台。”同一个面试问题并非只有一个答案，而同一个答案并不是在任何面试场合都有效，关键在应聘者掌握了规律后，对面试的具体情况进行把握，有意识地揣摩面试官提出问题的心理背景，然后投其所好。

分析：除非是薪资太低，或者是最初的工作，否则不要用薪资作为理由。“求发展”也被考官听得太多，离职理由要根据每个人的真实离职理由来设计，但是在回答时一定要表现得真诚。离职原因没有定式，要根据自己的情况以及应聘公司的情况灵活的去说，大概方向就是：合同到期，距离，技术，发展，公司经营不好，其他。

## 四、你最大的缺点是什么？

被面试官问的概率很大，也是HR的杀手锏和狠招，这个问题最难回答，通常面试官不希望听到求职直接回答的缺点是什么，如果求职者说自己小心眼、脾气大、工作效率低，企业肯定不会录用你。不要自作聪明地回答“我最大的缺点就是过于追求完美”，有的人以为这样回答会显得自己比较出色，但事实上，他已经岌岌可危了。面试官喜欢求职者从自己的优点说起，中间加一些小缺点，最后再把问题转到优点上，突出优点的部分，面试官喜欢聪明的求职者。

**回答范例：** 这个问题好难回答啊！我想想……（亲和力表现，也缓解了自己的紧张情绪）

我的缺点是比较执着，比如在技术方面比较爱钻研，有的时候会为一个技术问题加班到深夜。还有就是，工作比较按部就班，总是按照项目经管的要求完成任务。另外的缺点是，总在息的工作范围内有创新意识，并没有扩展给其他同事。这些问题我想我可以进入公司后以最短的时间来解决，我的学习能力很强，我相信可以很快融入公司的企业文化，进入工作状态。我想就这些吧。

## 五、你未来3-5年的职业规划是怎样的？

大部分面试官司都会问你是否有职业规划，这个问题的背后是了解你的求职动机和对自己中长期职业发展的思考。在回答这个问题之前，要对自己有个清晰的认识，知道自己想往哪个方向发展以及未来有什么计划，要给面试官一种积极向上，好学上进，有追求，有规划的感觉，面试官喜欢有规划的求职者。

**回答范例：** 我希望从现在开始，1-2年之内能够在我目前申请的这个职位上沉淀下来，通过不断的努力后，最好能有晋升，希望3-5年内可以做到（架构师、算法工程师、建模工程师或者做管理）。同时我也希望自己能够在企业的平台上得到进一步的职业能力提升。

## 六、你对薪资的要求？

如果你对薪酬的要求太低，那显然贬低自己的能力；如果你对薪酬的要求太高，那又会显得你分量过重，公司受用不起。一些雇主通常都事先对求职的职位定下开支预算，因而他们第一次提出的价钱往往是他们所能给予的最高价钱，他们问你只不过想证实一下这笔钱是否足以引起你对该工作的兴趣。

**回答范例一：** 我对工资没有硬性要求，我相信贵公司在处理我的问题上会友善合理。我注重的是找对工作机会，所以只要条件公平，我则不会计较太多。

如果你必须自己说出具体数目，那就不要说一个宽泛的范围，不要说10000-13000之间，那样你将只会得到最低限底的数字，也就是10000。最好给出一个具体的数字。

## 七、什么时候能入职？

大多数企业会关心就职时间，最好是回答“如果被录用的话，到职日可按公司的规定上班”，如果还未辞去上一个工作，但上班时间又太近，似乎有些强人所难，因为交接至少要一个月的时间，应进一步说明原因，录取公司应该会通融的。

## 八、介绍一个你认为最熟悉的项目（项目经理）

这个问题在技术面试时常被问到，问这个问题的意图是想考察你的成长路径和编程习惯，因为，你最熟悉的项目往往是你成长最快的项目，那个成长最快的项目往往会给你今后的编程习惯留下很多痕迹。所以，通过你对熟悉项目的描述，有经验的他会很快锁定你技术成长中的缺陷和闪光点，从而判断是否能够“为我所用”。

你最好拿出一个自己最擅长技术的那个项目进行介绍，他听完你的介绍后，会接下来进行提问，这样他所有问的问题，你都成竹在胸了。

切忌拿自己参与很少的项目来介绍，一旦他深入的询问很可能你会答非所问，反而造成更严重的影响。你大强以和他谈谈在那个项目中获得的经验，这样会引起此君的共鸣，有可能的话，说出一些你自己的小技巧，他会很高兴，同时这场面试也会很轻松，拿到Offer基本没问题了。

## 九、如果公司录用你，你将怎样开展工作？

很多企业在招聘开发人员时很看重是否能够尽快上手，所以回答这个问题时要“实打实”的回答，在回答中最好强调能够“尽快”投入开发工作中，这样领导就放心了，会觉得你不是一个只会盲目工作的人，而是一个按部就班，稳打稳扎的人。

**回答范例：** 我对咱们公司的大体情况只有一个大概了解，在这个职位的工作性质仅仅是我自己的一个理解。作为这个职位而言，我想我首先要对本公司的主营业务要有一个了解，了解公司的业务组成部分、业务的发展方向、我们面向的客户性质等。第二我要了解所属部门在公司中的地位，以及部门的工作目标，从而确定自身的工作努力方向。第三，了解我参与项目的开发方式，架构方式，紧密配合领导工作，尽快投入具体的开发工作中。这就是我开展工作的计划。

## 十、你还有什么问题问我吗？

这个问题看上去可有可无，其实很关键，面试官不喜欢说“没有问题”的人，没有问题就是自寻死路，没有问题传达出你对公司缺乏兴趣，而只是来寻找一笔薪水。其实在面试过程中谦虚礼貌的问面试官怎么称呼，该部门工作中的信息，如项目情况，开发技术再或者说贵公司的晋升机制是什么样的等。表现出一种很积极主动的状态是非常讨巧的。也可以更多的了解到自己来的工作环境。企业很欢迎这样的求职者，因为体现出你对学习的热情和对公司的忠诚度以及你的上进心。这个要分析面试官的身份，如果是普通技术面试官，可以问问对方目前项目的规划，使用的技术情况，还有就是您在这边工作多久了，是否能分享一些您在这边的工作体会。如果是HR的话，可以问问公司的企业文化，工资评定是否跟绩效挂钩，公司是否定期组织员工活动、团建等等，如果是公司CEO或者是CTO的话，可以问问团队的组成和公司前景之类的。或者告诉面试官关于公司的部分情况通过查看公司网站，还有面试基本上了解了，比较喜欢咱们公司这个平台和氛围，希望有机会能加入一起共事，如果您这边觉得我合适的话，最快什么时间能给我回复。

## **十一、社保问题**

如果上家公司写的是外地公司的话，之前是否上过社保深圳这边是查不到的，而且都要重新上。如果上家写的深圳公司，之前确实没有上过的话，就说之前公司规模小，五险一金一直没有上，但是签了自动放弃的协议，公司也给一部分补偿金，金额大概1000左右。如果之前你在深圳上过一段时间的社保，跟现在写的工作经历对不上的话，就说之前公司不给上，有一段时间自己通过关系找了一家公司挂靠了一段时间。面试的时候如果HR问你之前在深圳是否上过社保，只要说是或者否就可以，不用主动说太多。对方问的话再解释。

## **十二、上家公司薪资构成，及到手多少钱**

网上找税收计算器，把上家薪资输入自动算出扣税多少，再加上社保补偿金，就是你最后到手的工资，不用跟面试官说的特详细，只要说个大概就好。

## **十三、你有没有在工作中遇到过你无论如何都难以解决的问题？你的态度如何？**

工作中难免会有些问题难以被彻底的解决，在这样的情况下，我会思考这样几个问题：我是否已经尽了全力，是否还有什么方法或什么人能够帮助我解决问题？我是否已经全面的思考过问题的方方面面，还是钻在死胡同里出不来？我是否能在目前情况下改善问题，哪怕只是较小程度的改善？有时一些小小的改善积累起来可能最终就能够解决问题。

我认为遇到问题的态度切忌慌乱，往往欲速则不达，因此要冷静下来思考。另外就是切记不停的抱怨，不停的抱怨不但会给人留下负面印象，甚至因为消极的态度错过了解决问题的最后机会。

点评：该求职者首先表现了他不会轻易放弃解决问题的态度，懂得从各个角度去思考问题，并且会努力到最后一刻。在表述自己遇到问题的态度方面，该求职者也表现的非常完美，冷静、不抱怨并积极处理问题是所有面试官都会欣赏的态度。

## **十四、压力面试：**

随着企业竞争的激烈，员工的压力也越来越大，因此企业希望寻找到能够接受挑战、承担责任并能够抵抗压力的高素质人才。因此压力面试越来越多地应用到面试中。面试官会制造一种具有压力的紧张气氛，采用的方式包括：

1、打击求职者的自信心。对求职者的回答表示不满意，希望得到更佳的答案，并且始终不给于正面的反馈。

2、对于求职者的回答步步紧逼，不断的追问。求职者回答中的任何细节都会被不断的追问，细节上有任何不相符之处都可能引起质疑。

3、突然提出出乎意料的问题，或是非常难以回答的问题，并用沉默的方式等待求职者给出回答。

其实，压力面试只是一种特殊形式的行为面试，无需感到恐慌，所需要做的只是冷静、冷静

再冷静。无论对方提出的问题有多刁难，要保持冷静的应答，如果遇到实在无法继续回答的情况，可以将皮球踢回给面试官，例如面对微笑的反问：我在这个方面确实并不清楚或者接触的少，非常希望能够得到您的指导，或者您遇到这种情况该怎么处理。在压力面试中，面试官需要考察的是求职者面对压力的处理能力，而不仅是那些不合理问题的答案。有的面试官故意出一些难题，打击你的自信心，让你在要薪资的时候不敢多要。因此，放松心态，做足准备面对即可。

## 十五、**电话面试：**

1、避免没有重音、没有语音语调，这样会让听者变得非常的沉闷，甚至错过所需要留意的内容。

2、由于没有目光的接触以及肢体语言等辅助沟通手段，因此求职者必须把自己的回答尽可能整理的比较有逻辑，条理清晰，事例具体，否则很难给面试官留下深刻的印象。

3、由于电话面试常常应用于初期审核阶段，如果不能够较快抓住面试官的注意，面试官可能未必会花太多的时间去了解你，因此需要力求尽快地抓住面试官的注意。

## **十六、你对加班的看法？**

实际上好多公司问这个问题，并不证明一定要加班，只是想测试你是否愿意为公司奉献。

回答范例：如果是工作需要我会义不容辞加班，我现在单身，没有任何家庭负担，可以全身心的投入工作。但同时，我也会提高工作效率，减少不必要的加班。

## **十七、你朋友对你的评价？**

**回答提示：** 想从侧面了解一下你的性格及与人相处的问题。

**回答样本一：** 我的朋友都说我是一个可以信赖的人。因为，我一旦答应别人的事情，就一定会做到。如果我做不到，我就不会轻易许诺。

**回答样本二：** 我觉的我是一个比较随和的人，与不同的人都可以友好相处。在我与人相处时，我总是能站在别人的角度考虑问题。

## **十八、如果通过这次面试我们单位录用了你，但工作一段时间却发现你根本不适合这个职位，你怎么办？**

**回答提示：** 一段时间发现工作不适合我，有两种情况：

1、如果你确实热爱这个职业，那你就要不断学习，虚心向领导和同事学习业务知识和处事经验，了解这个职业的精神内涵和职业要求，力争减少差距；

2、你觉得这个职业可有可无，那还是趁早换个职业，去发现适合你的，你热爱的职业，那样你的发展前途也会大点，对单位和个人都有好处。

## **十九、在完成某项工作时，你认为领导要求的方式不是最好的，自己还有更好的方法，你应该怎么做？**

**回答提示：** ①.原则上我会尊重和服从领导的工作安排，同时私底下找机会以请教的口吻，婉转地表达自己的想法，看看领导是否能改变想法。②如果领导没有采纳我的建议，我也同样会按领导的要求认真地去完成这项工作。③.还有一种情况，假如领导要求的方式违背原则，我会坚决提出反对意见，如领导仍固执己见，我会毫不犹豫地再向上级领导反映。

## **二十、如果你的工作出现失误，给本公司造成经济损失，你认为该怎么办？**

**回答提示：** ①我本意是为公司努力工作，如果造成经济损失，我认为首要的问题是想方设法去弥补或挽回经济损失。如果我无能力负责，希望单位帮助解决。②分清责任，各负其责，如果是我的责任，我甘愿受罚；如果是一个我负责的团队中别人的失误，也不能幸灾乐祸，作为一个团队，需要互相提携共同完成工作，安慰同事并且帮助同事查找原因总结经验。

③总结经验教训，一个人的一生不可能不犯错误，重要的是能从自己的或者是别人的错误中吸取经验教训，并在今后的工作中避免发生同类的错误。检讨自己的工作方法、分析问题的深度和力度是否不够，以致出现了本可以避免的错误。

## **二十一、如果你做的一项工作受到上级领导的表扬，但你主管领导却说是他做的，你该怎样？**

**回答提示：** 我首先不会找那位上级领导说明这件事，我会主动找我的主管领导来沟通，因为沟通是解决人际关系的最好办法，但结果会有两种：①我的主管领导认识到自己的错误，我想我会视具体情况决定是否原谅他。②他更加变本加厉的来威胁我，那我会毫不犹豫地找我的上级领导反映此事，因为他这样做会造成负面影响，对今后的工作不利。

## **二十二、谈谈你对跳槽的看法？**

**回答提示：** ①正常的“跳槽”能促进人才合理流动，应该支持。②频繁的跳槽对单位和个人双方都不利，应该反对。

## **二十三、工作中你难以和同事、上司相处，你该怎么办？**

**回答提示：** ①我会服从领导的指挥，配合同事的工作。②我会从自身找原因，仔细分析是不是自己工作做得不好让领导不满意，同事看不惯。还要看看是不是为人处世方面做得不好，如果是这样的话 我会努力改正。③如果我找不到原因，我会找机会跟他们沟通，请他们指出我的不足，有问题就及时改正。④作为优秀的员工，应该时刻以大局为重，即使在一段时间内，领导和同事对我不理解，我也会做好本职工作，虚心向他们学习，我相信，他们会看见我在努力，总有一天会对我微笑的。

## **二十四、假设你在某单位工作，成绩比较突出，得到领导的肯定。但同时你发现同事们越来越孤立你，你怎么看这个问题？你准备怎么办？**

**回答提示：** ①成绩比较突出，得到领导的肯定是件好事情，以后更加努力。②检讨一下自己是不是对工作的热心度超过同事间交往的热心了，加强同事间的交往及共同的兴趣爱好。③工作中，切勿伤害别人的自尊心。④不再领导前拨弄是非。

## **二十五、你对于我们公司了解多少？**

**回答提示：** 在去公司面试前上网查一下该公司主营业务。如回答：贵公司有意改变策略，加强与国外大厂的OEM合作，自有品牌的部分则透过5海外经销商。

## **二十六、请说出你选择这份工作的动机？**

**回答提示：** 这是想知道面试者对这份工作的热忱及理解度，并筛选因一时兴起而来应试的人，如果是无经验者，可以强调“就算职种不同，也希望有机会发挥之前的经验”。

## **二十七、你最擅长的技术方向是什么？**

**回答提示：** 说和你要应聘的职位相关的课程，表现一下自己的热诚没有什么坏处。

## **二十八、你能为我们公司带来什么呢？**

**回答提示：** 技术、能力、人脉。

## **二十九、最能概括你自己的三个词是什么？**

**回答提示：** 我经常用的三个词是：适应能力强，有责任心和做事有始终，结合具体例子向主考官解释，

## **三十、你的业余爱好是什么？**

**回答提示：** 找一些富于团体合作精神的，这里有一个真实的故事：有人被否决掉，因为他的爱好是深海潜水。主考官说：因为这是一项单人活动，我不敢肯定他能否适应团体工作。多说团体合作，爱浏览技术网站、博客、书籍。最好提前想好最近在看那本书，看到了哪个部分。

## **三十一、作为被面试者给我打一下分？**

**回答提示：** 试着列出四个优点和一个非常非常非常小的缺点（可以抱怨一下设施，没有明确责任人的缺点是不会有人介意的）。

## **三十二、你怎么理解你应聘的职位？**

**回答提示：** 把岗位职责和任务及工作态度阐述一下。

## **三十三、喜欢这份工作的哪一点？**

**回答提示：** 相信其实大家心中一定都有答案了吧！每个人的价值观不同，自然评断的标准也会不同，但是，在回答面试官这个问题时可不能太直接就把自己心理的话说出来，尤其是薪资方面的问题，不过一些无伤大雅的回答是不错的考虑，如交通方便，工作性质及内容颇能符合自己的兴趣等等都是不错的答案，不过如果这时自己能仔细思考出这份工作的与众不同之处，相信在面试上会大大加分。

## **三十四、说说你对行业、技术发展趋势的看法？**

**回答提示：** 企业对这个问题很感兴趣，只有有备而来的求职者能够过关。求职者可以直接在网上查找对你所申请的行业部门的信息，只有深入了解才能产生独特的见解。企业认为最聪明的求职者是对所面试的公司预先了解很多，包括公司各个部门，发展情况，在面试回答问题的时候可以提到所了解的情况，企业欢迎进入企业的人是“知己”，而不是“盲人”。

## **三十五、说你的家庭？**

**回答提示：** 企业面试时询问家庭问题不是非要知道求职者家庭的情况，探究隐私，企业不喜欢探究个人隐私，而是要了解家庭背景对求职者的塑造和影响。企业希望听到的重点也在于家庭对求职者的积极影响。企业最喜欢听到的是：我很爱我的家庭，我的家庭一向很和睦，虽然我的父亲和母亲都是普通人，但是从小，我就看到我父亲起早贪黑，每天工作特别勤劳，他的行动无形中培养了我认真负责的态度和勤劳的精神。我母亲为人善良，对人热情，特别乐于助人，所以在单位人缘很好，她的一言一行也一直在教导我做人的道理。企业相信，和睦的家庭关系对一个人的成长有潜移默化的影响。

## **三十六、就你申请的这个职位，你认为你还欠缺什么？**

**回答提示：** 企业喜欢问求职者弱点，但精明的求职者一般不直接回答。他们希望看到这样的求职者：继续重复自己的优势，然后说：“对于这个职位和我的能力来说，我相信自己是可以胜任的，只是缺乏经验，这个问题我想我可以进入公司以后以最短的时间来解决，我的学习能力很强，我相信可以很快融入公司的企业文化，进入工作状态。”企业喜欢能够巧妙地躲过难题的求职者。

## **三十七、你欣赏哪种性格的人？**

**回答提示：** 诚实、不死板而且容易相处的人、有“实际行动”的人。

## **三十八、你通常如何处理別人的批评？**

**回答提示：** ①沈默是金，不必说什么，否则情况更糟，不过我会接受建设性的批评。②我会等大家冷靜下来再讨论。

## **三十九、你为什么愿意到我们公司来工作？**

**回答提示：** 对于这个问题，你要格外小心，如果你已经对该单位作了研究，你可以回答一些详细的原因，像“公司本身的高技术开发环境很吸引我。”、“我同公司出生在同样的时代，我希望能够进入一家与我共同成长的公司。”、“你们公司一直都稳定发展，在近几年来在市场上很有竞争力。”、“我认为贵公司能够给我提供一个与众不同的发展道路。”这都显示出你已经做了一些调查，也说明你对自己的未来有了较为具体的远景规划。

## **四十、你和别人发生过争执吗？你是怎样解决的？**

**回答提示：** 这是面试中最险恶的问题，其实是考官布下的一个陷阱，千万不要说任何人的过错，应知成功解决矛盾是一个协作团体中成员所必备的能力。假如你工作在一个服务行业，这个问题简直成了最重要的一个环节。你是否能获得这份工作，将取决于这个问题的回答。考官希望看到你是成熟且乐于奉献的。他们通过这个问题了解你的成熟度和处世能力。在没有外界干涉的情况下，通过妥协的方式来解决才是正确答案。

## **四十一、你做过的哪件事最令自己感到骄傲？**

**回答提示：** 这是考官给你的一个机会，让你展示自己把握命运的能力。这会体现你潜在的领导能力以及你被提升的可能性。假如你应聘于一个服务性质的单位，你很可能会被邀请去午餐。记住：你的前途取决于你的知识、你的社交能力和综合表现。

## **四十二、对这项工作，你有哪些可预见的困难？**

**回答提示：** ①不宜直接说出具体的困难，否则可能令对方怀疑应聘者不行。②可以尝试迂回战术，说出应聘者对困难所持有的态度——工作中出现一些困难是正常的，也是难免的，但是只要有坚忍不拔的毅力、良好的合作精神以及事前周密而充分的准备，任何困难都是可以克服。

**分析：** 一般问这个问题，面试者的希望就比较大了，因为已经在谈工作细节，但常规思路中的回答，又被面试官“骗”了。当面试官询问这个问题的时候，有两个目的。第一，看看应聘者是不是在行，说出的困难是不是在这个职位中一般都不可避免的问题。第二，是想看一下应聘者解决困难的手法对不对，及公司能否提供这样的资源。而不是想了解应聘者对困难的态度。

## **四十三、怎样对待自己的失敗？**

**回答提示：** 我们大家生来都不是十全十美的，我相信我有第二个机会改正我的错误。

### **四十四、什么会让你有成就感？**

**回答提示：** 为贵公司竭力效劳，尽我所能，完成一个项目。

### **四十五、眼下你生活中最重要的是什么？**

**回答提示：** 对我来说，能在这个领域找到工作是最重要的，能在贵公司任职对我说最重要。

### **四十六、与上级意见不一是，你将怎么办？**

**回答提示：** ①一般可以这样回答“我会给上级以必要的解释和提醒，在这种情况下，我会服从上级的意见。”②如果面试你的是总经理，而你所应聘的职位另有一位经理，且这位经理当时不在场，可以这样回答：“对于非原则性问题，我会服从上级的意见，对于涉及公司利益的重大问题，我希望能向更高层领导反映。”

**分析：** 这个问题的标准答案是思路①，如果用②的回答，必死无疑。你没有摸清楚改公司的内部情况，先想打小报告，这样的人没有人敢要。

### **四十七、你工作经验欠缺，如何能胜任这项工作？**

**常规思路：** ①如果招聘单位对应聘者提出这个问题，说明招聘公司并不真正在乎“经验”，关键看应聘者怎样回答。②对这个问题的回答最好要体现出应聘者的诚恳、机智、果敢及敬业。③如“在项目经验方面的确会有所欠缺，但我有较强的责任心、适应能力和学习能力，而且比较勤奋，在上家公司无论遇到什么困难都能想办法完成各项工作，从中获取的经验也令我受益非浅。请贵公司放心，我一定能胜任这个职位。”

**点评：** 这个问题思路中的答案尚可，突出自己的吃苦能力和适应性以及学习能力（不是学习成绩）为好。

### **四十八、你希望与什么样的上级共事？**

**回答提示：** ①通过应聘者对上级的“希望”可以判断出应聘者对自我要求的意识，这既上一个陷阱，又是一次机会。②最好回避对上级具体的希望，多谈对自己的要求。③如“做为刚步入社会的新人，我应该多要求自己尽快熟悉环境、适应环境，而不应该对环境提出什么要求，只要能发挥我的专长就可以了。

**分析：** 这个问题比较好的回答是，希望我的上级能够在工作中对我多指导，对我工作中的错误能够立即指出。总之，从上级指导这个方面谈，不会有大的纰漏。

### **四十九、谈谈如何适应办公室工作的新环境？**

**回答提示：** ①办公室里每个人有各自的岗位与职责，不得擅离岗位。②根据领导指示和工作安排，制定工作计划，提前预备，并按计划完成。③多请示并及时汇报，遇到不明白的要虚心请教。④抓间隙时间，多学习，努力提高自己的政治素质和业务水平。

### **五十、为了做好你工作份外之事，你该怎样获得他人的支持和帮助？**

**回答提示：** 每个公司都在不断变化发展的过程中，你当然希望你的员工也是这样。你希望得到那些希望并欢迎变化的人，因为这些人明白，为了公司的发展，变化是公司日常生活中重要组成部分。这样的员工往往很容易适应公司的变化，并会对变化做出积极的响应。

### **五十一、如果你在这次面试中没有被录用，你怎么打算？**

**回答提示：** 现在的社会是一个竞争的社会，从这次面试中也可看出这一点，有竞争就必然有优劣，有成功必定就会有失败。往往成功的背后有许多的困难和挫折，如果这次失败了也仅仅是一次而已，只有经过经验经历的积累才能塑造出一个完全的成功者。我会从以下几个方面来正确看待这次失败：①要敢于面对，面对这次失败不气馁，接受已经失去了这次机会就不会回头这个现实，从心理意志和精神上体现出对这次失败的抵抗力。要有自信，相信自己经历了这次之后经过努力一定能行，能够超越自我。②善于反思，对于这次面试经验要认真总结，思考剖析，能够从自身的角度找差距。正确对待自己，实事求是地评价自己，辩证的看待自己的长短得失，做一个明白人。③走出阴影，要克服这一次失败带给自己的心理压力，时刻牢记自己弱点，防患于未然，加强学习，提高自身素质。④再接再厉，能进入像贵公司这样的平台一直是我的梦想，以后如果有机会我仍然后再次参加竞争。

### **五十二、谈谈你过去做过的成功案例？**

**回答提示：** 举一个你最有把握的例子，把来龙去脉说清楚，而不要说了很多却没有重点。切忌夸大其词，把别人的功劳到说成自己的，很多主管为了确保要用的人是最适合的，会打电话向你的前一个主管征询对你的看法及意见，所以如果说谎，是很容易穿梆的。

### **五十三、谈谈你过去的工作经验中，最令你挫折的事情？**

**回答提示：** 可以在网上查查其他人在开发过程中会出现哪些问题，最后是怎么解决的。

**分析：** 借此了解你对挫折的容忍度及调解方式。

**分析：** 虽然不会有人心甘情愿的加班，但依旧要表现出高配合度的诚意。

### **五十四、为什么我们要在众多的面试者中选择你？**

**回答提示：** 根据我对贵公司的了解，以及我在这份工作上所累积的专业、经验及人脉，相信正是贵公司所找寻的人才。而我在工作态度、ＥＱ上，也有圆融、成熟的一面，和主管、同事都能合作愉快。

**分析：** 别过度吹嘘自己的能力，或信口开河地乱开支票，例如一定会为该公司带来多少钱的业务等，这样很容易给人一种爱说大话、不切实际的感觉。

### **五十五、你并非毕业于名牌院校？**

**回答提示：** 是否毕业于名牌院校不重要，重要的是有能力完成您交给我的工作，我想我更适合贵公司这个职位。

### **五十六、怎样看待学历和能力？**

**回答提示：** 学历我想只要是大学专科的学历，就表明觉得我具备了根本的学习能力。剩下的，你是学士也好，还是博士也好，对于这一点的讨论，不是看你学了多少知识，而是看你在这个领域上发挥了什么，也就是所说的能力问题。一个人工作能力的高低直接决定其职场命运，而学历的高低只是进入一个企业的敲门砖，如果贵公司把学历卡在博士上，我就无法进入贵公司，当然这不一定只是我个人的损失，如果一个专科生都能完成的工作，您又何必非要招聘一位博士生呢？

### **五十七、工作中学习到了些什么？**

**回答提示：** 这是针对转职者提出的问题，建议此时可以配合面试工作的特点作为主要依据来回答，如业务工作需要与人沟通，便可举出之前工作与人沟通的例子，经历了哪些困难，学习到哪些经验，把握这些要点做陈述，就可以轻易过关了。

### **五十八、想过创业吗？**

**回答提示：** 这个问题可以显示你的冲劲，但如果你的回答是“有”的话，千万小心，下一个问题可能就是：那么为什么你不这样做呢？

### **五十九、除了本公司外，还应聘了哪些公司？**

**回答提示：** 很奇怪，这是相当多公司会问的问题，其用意是要概略知道应徵者的求职志向，所以这并非绝对是负面答案，就算不便说出公司名称，也应回答“类似的公司（互联网）”，如果应聘的其他公司是不同业界，容易让人产生无法信任的感觉。

### 六十、面试注意事项：

1，在面试官面前千万不要抖脚，手脚不要动来动去，不能有小动作。

2，在面试过程中，千万不要跟面试官去争论，说话太冲，太能说、抢话说、乱说都不好，遇到难题，先思考一下，切记心浮气燥，表达时口气温和，谦虚。

3，如果面试过程中都不错，谈的也很好，之后却没有给Offer，完全是自己意料之外的情况，这个很有可能，或许是因为公司有了其他的人选，不用介意，更不要沮丧。

4，在面试过程中，切忌问关于公司计划、行业机密等相关的东西，不要打探公司的内幕，机密敏感性的问题不要问东问西。

5，千万要注意仪容仪表，要有礼貌，最好不要有口吃，口头表达，逻辑思维很重要，不要让面试官觉得你很幼稚，太过小孩子气，显的不够稳重踏实。

6，在去面试之前，要熟悉自己的简历，特别是工作经历，准备好关于一些离职原因、职业规划方面的问题的回答方式。

7，在面试过程中，80%的面试官会让做自我介绍，所以提前要准备一下，说出的内容既要和简历相符，又要有重点有突出的地方，不能像背简历一样。

8，面试完后，如果等待的时间较长，没有回应，就可能没有什么希望了，自己可以打电话去了解情况。

9，在面试过程中，谈到薪资的时候，如果没有说明是税后工资就是税前，假如是税前6000，这里面就包括了公司给交的公积金，还有其他五险要交的费用，拿到手差不多4000左右。







#                                       